# Testing Checklist for OOP Systems

- **Book:** Object-Oriented Thinking by Vaysfeld
- **Role:** Tester
- **Concept:** Systematic Testing for OOP Code
- **Generated:** 2026-04-25T16:45:00Z
- **Gate:** APPLY-VALID PASSED (0.86)

---

## Phase 1: Pre-Testing Checklist

### Class Design Review

- [ ] **Single Responsibility** [concept: single-responsibility]
  - [ ] Class has only one reason to change
  - [ ] Class doesn't handle multiple concerns (validation + persistence)
  - [ ] If class name contains "And" or "Or", consider splitting
  - [ ] All methods relate to same responsibility

- [ ] **Encapsulation** [concept: encapsulation]
  - [ ] Private fields are not directly accessible
  - [ ] Access modifiers are appropriate (private > protected > public)
  - [ ] Getters/setters validate state changes
  - [ ] Internal state cannot be corrupted from outside

- [ ] **Inheritance** [concept: inheritance]
  - [ ] Inheritance hierarchy is shallow (≤ 3 levels)
  - [ ] Parent-child relationship is "is-a" (not "has-a")
  - [ ] Child doesn't violate parent's contract (LSP)
  - [ ] Abstract methods are documented

- [ ] **Interface Contracts** [concept: interface]
  - [ ] Interface defines clear contract
  - [ ] All implementations satisfy contract
  - [ ] Interface methods are cohesive (belong together)
  - [ ] Interface is focused (not kitchen-sink)

### Testability Review

- [ ] **Dependency Injection** [concept: dependency-inversion]
  - [ ] All dependencies are constructor-injected
  - [ ] No hard-coded `new` statements for dependencies
  - [ ] No static utility method calls (or they're pure functions)
  - [ ] No ServiceLocator or global state

- [ ] **Mockability**
  - [ ] External dependencies implement interfaces
  - [ ] Can mock all external services (DB, API, email)
  - [ ] No final classes/methods (unless absolutely necessary)
  - [ ] Methods are overrideable

- [ ] **State Visibility**
  - [ ] Object state is observable through public interface
  - [ ] Can verify state after operations
  - [ ] Debugging aids available (toString, equals, logging)
  - [ ] No hidden internal state

### Code Quality Review

- [ ] **No Code Smells**
  - [ ] No God Objects (classes too large)
  - [ ] No Duplicate Code (refactor into shared method)
  - [ ] No Data Clumps (group related fields into classes)
  - [ ] No Long Parameter Lists (use builder or object parameter)

- [ ] **Documentation**
  - [ ] All public methods have documentation
  - [ ] Complex logic has inline comments
  - [ ] Assumptions are documented
  - [ ] Failure scenarios are documented

---

## Phase 2: Test Design Checklist

### Unit Test Planning

- [ ] **Test Organization**
  - [ ] One test class per class being tested
  - [ ] Test class named `ClassName​Test` or `ClassNameTests`
  - [ ] Test file in `src/test/java` (parallel structure)
  - [ ] Tests grouped by method or scenario

- [ ] **Test Naming**
  - [ ] Test method names describe what is being tested
  - [ ] Format: `test<Method><Scenario>()` or `should<Behavior>When<Condition>()`
  - [ ] Examples: `testWithdrawValidAmount()`, `shouldThrowExceptionWhenNegativeBalance()`
  - [ ] Avoid: `test1()`, `test2()`, `testOK()`

- [ ] **Encapsulation Tests**
  - [ ] Verify private fields cannot be directly accessed
  - [ ] Test all setter validations
  - [ ] Test immutable fields are not writable
  - [ ] Test state consistency after each mutation

```
Example:
- TC-001: Setter rejects invalid values
- TC-002: Private field cannot be modified directly  
- TC-003: State remains consistent
```

- [ ] **Inheritance Tests**
  - [ ] Parent methods work on child instances
  - [ ] Child overrides behave correctly
  - [ ] LSP violation detection (child breaks parent contract)
  - [ ] Super class method called if needed
  - [ ] Abstract methods are implemented

```
Example:
- TC-009: Child inherits parent methods correctly
- TC-010: Override respects LSP
- TC-011: Super call in override executes
```

- [ ] **Polymorphism Tests**
  - [ ] Dynamic dispatch calls correct method
  - [ ] All implementations of interface work
  - [ ] Polymorphic collections work correctly
  - [ ] Type checking optional but optimizable

```
Example:
- TC-016: Polymorphic method dispatches correctly
- TC-017: Collections of polymorphic objects
- TC-018: Interface implementations verified
```

- [ ] **Edge Case Coverage**
  - [ ] Boundary values (0, 1, -1, max, min)
  - [ ] Empty collections
  - [ ] Null references
  - [ ] Invalid inputs
  - [ ] State transitions
  - [ ] Concurrent access (if applicable)

```
Example for age validation:
- Boundary: -1, 0, 1, 150, 151
- Empty: age = null
- Invalid: age = -50, age = 200
```

### Integration Test Planning

- [ ] **Component Interaction**
  - [ ] Multiple classes work together correctly
  - [ ] Data flows correctly between components
  - [ ] Composition chains work as designed
  - [ ] Inheritance hierarchies work end-to-end

- [ ] **Contract Verification**
  - [ ] All implementations satisfy interface contract
  - [ ] Contract enforced across different scenarios
  - [ ] No contract violations detected

- [ ] **Error Handling**
  - [ ] Failures propagate correctly
  - [ ] Exceptions are caught and re-thrown appropriately
  - [ ] State remains consistent after errors

### E2E Test Planning

- [ ] **Critical Paths**
  - [ ] Happy path scenarios covered
  - [ ] Main workflows validated end-to-end
  - [ ] User stories verified
  - [ ] No more than 10 E2E tests

- [ ] **Realistic Data**
  - [ ] Uses realistic test data
  - [ ] Doesn't mock everything (actual databases if possible)
  - [ ] Tests real scenarios, not edge cases

---

## Phase 3: Test Implementation Checklist

### AAA Pattern (Arrange-Act-Assert)

```java
@Test
public void testSomething() {
    // ARRANGE - Set up test data and mocks
    UserRepository mockRepo = mock(UserRepository.class);
    when(mockRepo.findById(1)).thenReturn(new User("John"));
    UserService service = new UserService(mockRepo);
    
    // ACT - Execute the method being tested
    User result = service.getUser(1);
    
    // ASSERT - Verify the result
    assertEquals("John", result.getName());
    verify(mockRepo).findById(1);
}
```

- [ ] Clear Arrange phase
  - [ ] All test data set up
  - [ ] All mocks created and configured
  - [ ] System under test instantiated
  - [ ] Arrange code doesn't have side effects

- [ ] Single Act phase
  - [ ] Only one method call in Act
  - [ ] One logical action (even if multiple lines)
  - [ ] If multiple actions needed, test is unfocused

- [ ] Clear Assert phase
  - [ ] At least one assertion
  - [ ] Assertions verify the main behavior
  - [ ] Verify mock interactions if using mocks
  - [ ] No assertions in Arrange

### Mocking Best Practices

- [ ] **Mock External Dependencies**
  - [ ] Mock all external services (DB, API, email)
  - [ ] Don't mock the class being tested
  - [ ] Don't mock simple value objects
  - [ ] Mock at integration points

- [ ] **Verify Mock Behavior**
  - [ ] `verify(mock).methodName()` called at least once
  - [ ] `verify(mock, times(3)).methodName()` called specific times
  - [ ] `verify(mock, never()).methodName()` not called
  - [ ] `verify(mock, never()).anotherMethod()` verify what wasn't called

- [ ] **Mock Return Values**
  - [ ] `when(mock.method()).thenReturn(value)`
  - [ ] `when(mock.method()).thenThrow(exception)`
  - [ ] `when(mock.method()).thenAnswer(invocation -> ...)`
  - [ ] Configure all expected calls

### Assertion Best Practices

- [ ] **Use Specific Assertions**
  - [ ] `assertEquals(expected, actual)` for values
  - [ ] `assertTrue(condition)` for boolean
  - [ ] `assertNull(value)` / `assertNotNull(value)` for nulls
  - [ ] `assertThrows(Exception.class, () -> method())` for exceptions
  - [ ] `assertIterableEquals(expected, actual)` for collections

- [ ] **Assertion Messages**
  - [ ] Every assertion has a message explaining failure
  - [ ] Message describes expected vs actual
  - [ ] Example: `assertEquals(100, balance, "Balance should be 100 after withdrawal of 100")`

- [ ] **Collection Assertions**
  - [ ] `assertTrue(collection.contains(item))`
  - [ ] `assertEquals(expectedSize, collection.size())`
  - [ ] `assertIterableEquals(expectedList, actualList)`
  - [ ] `assertTrue(collection.isEmpty())`

---

## Phase 4: Code Coverage Checklist

### Coverage Targets

- [ ] **Line Coverage** ≥ 85%
  - [ ] Run coverage tool: `./mvn clean test jacoco:report`
  - [ ] Check coverage report
  - [ ] Investigate uncovered lines (why not tested?)
  - [ ] Acceptable uncovered: generated code, fallback error handling

- [ ] **Branch Coverage** ≥ 85%
  - [ ] All if-branches tested (true and false)
  - [ ] All switch cases tested
  - [ ] Exception paths tested
  - [ ] Ternary operators tested both ways

- [ ] **Statement Coverage** ≥ 85%
  - [ ] All executable statements covered
  - [ ] Loop iterations tested
  - [ ] All method calls included
  - [ ] Method exits tested (return, exception)

### Coverage Hotspots

- [ ] **Critical Paths**
  - [ ] 100% coverage for security code
  - [ ] 100% coverage for payment code
  - [ ] 100% coverage for data validation
  - [ ] 95%+ coverage for business logic

- [ ] **Low-Risk Code**
  - [ ] 50%+ coverage for utility functions
  - [ ] 70%+ coverage for UI code
  - [ ] 70%+ coverage for logging/monitoring
  - [ ] Minimal coverage for simple getters/setters

---

## Phase 5: Test Execution Checklist

### Local Test Run

- [ ] **Build and Compile**
  - [ ] Code compiles without errors: `./mvn clean compile`
  - [ ] Tests compile without errors: `./mvn test-compile`
  - [ ] No deprecation warnings (or acceptable)
  - [ ] No import errors

- [ ] **Run All Tests**
  - [ ] All unit tests pass: `./mvn test`
  - [ ] All integration tests pass: `./mvn verify`
  - [ ] Build time acceptable (< 2 minutes)
  - [ ] No skipped tests (unless intentional)

- [ ] **Test Results**
  - [ ] All tests pass
  - [ ] No failed tests
  - [ ] No errors in test output
  - [ ] Stack traces reviewed (if any)

### Continuous Integration

- [ ] **CI Pipeline Passes**
  - [ ] Code compiles
  - [ ] All tests pass
  - [ ] Code coverage maintained/improved
  - [ ] No regressions introduced

- [ ] **Code Quality Checks**
  - [ ] SonarQube/code analysis passes
  - [ ] No new critical issues
  - [ ] No new security vulnerabilities
  - [ ] Maintainability index acceptable

- [ ] **Performance**
  - [ ] Test suite runs in < 5 minutes
  - [ ] No performance regressions
  - [ ] Database queries optimized (use H2 in-memory)
  - [ ] No resource leaks

---

## Phase 6: Regression Testing Checklist

### Bug Fix Verification

- [ ] **Test First**
  - [ ] Write failing test that reproduces bug
  - [ ] Test fails before fix applied
  - [ ] Bug is confirmed by test

- [ ] **Fix Implementation**
  - [ ] Minimal fix applied (no scope creep)
  - [ ] Fix makes failing test pass
  - [ ] No new tests broken
  - [ ] Code review approved fix

- [ ] **Regression Prevention**
  - [ ] Test added to prevent regression
  - [ ] Test will fail if bug reintroduced
  - [ ] Test stays in suite permanently
  - [ ] Similar tests added for related scenarios

### Related Features

- [ ] **Smoke Tests** (quick validation)
  - [ ] Happy path still works
  - [ ] Related features not broken
  - [ ] No new exceptions thrown
  - [ ] Performance not degraded

- [ ] **Downstream Impact**
  - [ ] Dependent features tested
  - [ ] Integration points validated
  - [ ] API contracts honored
  - [ ] Data consistency verified

---

## Phase 7: Code Review for Testability Checklist

### Review Criteria

When reviewing code, check:

- [ ] **Test Coverage**
  - [ ] At least one test per method
  - [ ] Happy path and error cases covered
  - [ ] Edge cases considered
  - [ ] No uncovered branches

- [ ] **Test Quality**
  - [ ] Tests verify behavior, not implementation
  - [ ] Tests are focused (test one thing)
  - [ ] Tests are readable
  - [ ] Tests are maintainable

- [ ] **Testability**
  - [ ] Code is testable (dependencies injectable)
  - [ ] No hard-coded dependencies
  - [ ] No global state
  - [ ] No static method calls to external services

- [ ] **Mocking**
  - [ ] Appropriate use of mocks
  - [ ] Mocks configured correctly
  - [ ] Mock interactions verified
  - [ ] No over-mocking

- [ ] **Naming**
  - [ ] Test names describe what they test
  - [ ] Variable names are clear
  - [ ] Method names are descriptive
  - [ ] Assertion messages are helpful

### Review Comments

Good review comments:

```
✓ "Test clearly verifies encapsulation by checking that balance cannot be set directly"

✓ "Good use of @ParameterizedTest to verify all payment methods satisfy interface contract"

✓ "Tests cover both success and failure scenarios [concept: polymorphism]"

✗ "Test is testing implementation details, not behavior - consider refactoring"

✗ "Missing edge case: what if balance is exactly zero?"

✗ "Mock is over-configured - only configure what your test needs"
```

---

## Phase 8: Documentation Checklist

### Test Documentation

- [ ] **README.md**
  - [ ] How to run tests: `mvn test`
  - [ ] How to generate coverage: `mvn jacoco:report`
  - [ ] Where coverage report is: `target/site/jacoco/index.html`
  - [ ] Coverage targets documented

- [ ] **Test Class Documentation**
  - [ ] Each test class has javadoc explaining purpose
  - [ ] Setup/teardown documented if non-obvious
  - [ ] External dependencies documented
  - [ ] Test data sources documented

- [ ] **Individual Test Documentation**
  - [ ] Javadoc for complex test methods
  - [ ] AAA sections commented if non-obvious
  - [ ] Why specific assertions chosen documented
  - [ ] Related concepts referenced [concept: name]

### Continuous Integration Documentation

- [ ] **Test Execution Documentation**
  - [ ] Where tests run (local, CI, etc.)
  - [ ] How long tests take
  - [ ] What to do if tests fail
  - [ ] Who to contact for test failures

- [ ] **Coverage Documentation**
  - [ ] Coverage targets per component
  - [ ] How coverage is tracked
  - [ ] What to do if coverage drops
  - [ ] Acceptable uncovered code documented

---

## Phase 9: Performance Checklist

### Test Performance

- [ ] **Unit Tests**
  - [ ] Each test < 100ms
  - [ ] Entire suite < 5 minutes
  - [ ] No database calls
  - [ ] No network calls
  - [ ] All dependencies mocked

- [ ] **Integration Tests**
  - [ ] Each test < 1 second
  - [ ] Entire suite < 2 minutes (excluding E2E)
  - [ ] Use in-memory database (H2)
  - [ ] Minimize I/O operations
  - [ ] Clean up resources

- [ ] **E2E Tests**
  - [ ] Each test < 10 seconds
  - [ ] Entire suite < 5 minutes
  - [ ] Reasonable for CI environment
  - [ ] Can be run on demand

### Performance Optimization

- [ ] **Database**
  - [ ] Use in-memory H2 for tests
  - [ ] Use transactional rollback (avoid slow cleanup)
  - [ ] Reuse database state where possible
  - [ ] Batch inserts for large datasets

- [ ] **Mocking**
  - [ ] Mock external APIs (don't make real calls)
  - [ ] Spy on dependencies to speed up tests
  - [ ] Cache mock responses
  - [ ] Use static mock configurations

- [ ] **Test Structure**
  - [ ] Parallel test execution enabled
  - [ ] No shared state between tests
  - [ ] Minimal setup/teardown
  - [ ] No unnecessary object creation

---

## Phase 10: Continuous Improvement Checklist

### Metrics

- [ ] **Track Coverage**
  - [ ] Coverage baseline established
  - [ ] Coverage tracked over time
  - [ ] Trend is improving (not decreasing)
  - [ ] Goals are being met

- [ ] **Track Test Flakiness**
  - [ ] Flaky tests identified
  - [ ] Flaky tests fixed or removed
  - [ ] Build confidence in tests
  - [ ] No tests that randomly fail

- [ ] **Track Test Maintenance**
  - [ ] Tests break less frequently than code
  - [ ] Test failures are real (not false positives)
  - [ ] Easy to maintain test suite
  - [ ] Easy to add new tests

### Retrospective

- [ ] **Team Practices**
  - [ ] TDD practiced consistently
  - [ ] Tests reviewed in code review
  - [ ] Test failures addressed quickly
  - [ ] Coverage goals discussed

- [ ] **Improvements**
  - [ ] What testing practices work well?
  - [ ] What's difficult about testing?
  - [ ] What patterns are reused?
  - [ ] What's causing the most bugs?

- [ ] **Knowledge Sharing**
  - [ ] Testing best practices documented
  - [ ] Anti-patterns documented
  - [ ] Examples shared with team
  - [ ] New developers trained

---

## Quick Summary Checklist

### Before Writing Tests
- [ ] Class is properly designed
- [ ] Dependencies are injectable
- [ ] No hard-coded external dependencies
- [ ] Access modifiers are correct
- [ ] Single responsibility maintained

### While Writing Tests
- [ ] Use AAA pattern (Arrange-Act-Assert)
- [ ] Test names describe what's tested
- [ ] Mock external dependencies
- [ ] Cover happy path and error cases
- [ ] Test edge cases and boundaries

### After Writing Tests
- [ ] All tests pass
- [ ] Coverage ≥ 85%
- [ ] Tests are readable and maintainable
- [ ] CI pipeline passes
- [ ] No regressions introduced

### Regression Prevention
- [ ] Bug reproduced by failing test
- [ ] Fix makes test pass
- [ ] Test added to prevent recurrence
- [ ] Related scenarios tested

### Continuous Improvement
- [ ] Coverage tracked and maintained
- [ ] Flaky tests identified and fixed
- [ ] Testing practices improved
- [ ] Knowledge shared with team
