# Testable Design Patterns for OOP

- **Book:** Object-Oriented Thinking by Vaysfeld
- **Role:** Tester
- **Concept:** Making OOP Code Testable
- **Generated:** 2026-04-25T16:45:00Z
- **Gate:** APPLY-VALID PASSED (0.87)

---

## What Makes Code Testable?

[concept: testable-design]

Code is testable when:

1. **Dependencies are injectable** - Can pass mocks for external services
2. **Responsibilities are separated** - Each class has one reason to test
3. **State is encapsulated** - Can verify object state through public interface
4. **Behavior is predictable** - Same input always produces same output (no hidden state)
5. **Failures are explicit** - Exceptions are thrown, not silently ignored

---

## The Testability Spectrum

```
LEAST TESTABLE                          MOST TESTABLE
   ↓                                        ↓
Hard-coded deps ────→ Factories ────→ Constructor Injection ────→ Interfaces
Static methods ──────→ Singletons ────→ Dependency objects
Global state ────────→ Context obj ────→ Explicit parameters
No interfaces ───────→ Concrete types ────────────────────────────→ Abstractions
```

---

## Pattern 1: Constructor Injection [concept: dependency-inversion]

### Problem: Hard-Coded Dependencies Make Testing Impossible

```java
// UNTESTABLE ❌
public class OrderService {
    private DatabaseConnection connection;
    private EmailService emailService;
    
    public OrderService() {
        this.connection = new DatabaseConnection("localhost");  // Hard-coded!
        this.emailService = new RealEmailService();  // Can't mock!
    }
}
```

**Why it's untestable:**
- Can't inject mock database
- Every test executes real email sends
- Tests are slow and brittle
- Can't test database failure scenarios

### Solution: Inject Dependencies Through Constructor

```java
// TESTABLE ✓
public class OrderService {
    private DatabaseConnection connection;
    private EmailService emailService;
    
    public OrderService(DatabaseConnection connection, EmailService emailService) {
        this.connection = connection;
        this.emailService = emailService;
    }
}
```

### Testing It

```java
@Test
public void testOrderServiceWithMocks() {
    // Arrange - Inject mocks
    DatabaseConnection mockDB = mock(DatabaseConnection.class);
    EmailService mockEmail = mock(EmailService.class);
    OrderService service = new OrderService(mockDB, mockEmail);
    
    // Act
    Order order = new Order("item1", 100);
    service.processOrder(order);
    
    // Assert
    verify(mockDB).save(order);
    verify(mockEmail).sendConfirmation(order);
}
```

### Trade-offs

| Aspect | Benefit |
|--------|---------|
| **Testability** | ✓ Can inject mocks |
| **Flexibility** | ✓ Can swap implementations |
| **Clarity** | ✓ Dependencies explicit |
| **Complexity** | ✗ More constructor parameters |
| **Legacy code** | ✗ Hard to retrofit |

### When to Use

- New code with clear dependencies
- Classes that call external services
- Classes that need different behavior in test vs production

---

## Pattern 2: Extract Interface [concept: interface]

### Problem: Can't Mock Concrete Classes

```java
// UNTESTABLE ❌
public class PaymentService {
    private RealPaymentGateway gateway;  // Concrete class!
    
    public PaymentService() {
        this.gateway = new RealPaymentGateway();
    }
    
    public boolean processPayment(double amount) {
        return gateway.charge(amount);  // Can't mock - calls real API
    }
}
```

**Why it's untestable:**
- Can't mock RealPaymentGateway
- Tests make real API calls (slow, expensive)
- Can't test failure scenarios
- Coupled to specific implementation

### Solution: Extract Interface, Depend on Abstraction

```java
// TESTABLE ✓

// 1. Define interface
public interface PaymentGateway {
    boolean charge(double amount);
    boolean refund(double transactionId);
}

// 2. Implement real version
public class RealPaymentGateway implements PaymentGateway {
    @Override
    public boolean charge(double amount) {
        // Real implementation - calls actual payment API
    }
}

// 3. Depend on interface, not implementation
public class PaymentService {
    private PaymentGateway gateway;  // Interface, not concrete!
    
    public PaymentService(PaymentGateway gateway) {
        this.gateway = gateway;
    }
    
    public boolean processPayment(double amount) {
        return gateway.charge(amount);
    }
}
```

### Testing It

```java
@Test
public void testPaymentServiceSuccess() {
    // Arrange - Mock the interface
    PaymentGateway mockGateway = mock(PaymentGateway.class);
    when(mockGateway.charge(100)).thenReturn(true);
    PaymentService service = new PaymentService(mockGateway);
    
    // Act
    boolean result = service.processPayment(100);
    
    // Assert
    assert(result == true);
}

@Test
public void testPaymentServiceFailure() {
    // Arrange - Mock failure scenario
    PaymentGateway mockGateway = mock(PaymentGateway.class);
    when(mockGateway.charge(100)).thenReturn(false);
    PaymentService service = new PaymentService(mockGateway);
    
    // Act
    boolean result = service.processPayment(100);
    
    // Assert
    assert(result == false);
}
```

### Benefits

| Benefit | Why |
|---------|-----|
| **Mockable** | Can mock PaymentGateway interface |
| **Testable failures** | Can simulate gateway down, timeout, etc. |
| **Fast tests** | No real API calls |
| **Swappable** | Can use different gateway implementations |
| **Loosely coupled** | Service doesn't know about RealPaymentGateway |

---

## Pattern 3: Separate Concerns (Single Responsibility) [concept: single-responsibility]

### Problem: God Classes Do Too Much

```java
// UNTESTABLE ❌
public class OrderProcessor {
    private Database db;
    private EmailService email;
    private PaymentGateway payment;
    private Logger logger;
    
    public void processOrder(Order order) {
        // Validation logic
        if (order.getCustomer() == null) throw new Exception("No customer");
        if (order.getItems().isEmpty()) throw new Exception("No items");
        
        // Payment logic
        boolean paid = payment.charge(order.getTotal());
        if (!paid) throw new Exception("Payment failed");
        
        // Database logic
        db.saveOrder(order);
        db.updateInventory(order.getItems());
        
        // Email logic
        email.sendConfirmation(order);
        
        // Logging
        logger.log("Order processed: " + order.getId());
    }
}
```

**Why it's untestable:**
- Testing one aspect requires setting up all dependencies
- Hard to test validation without triggering email/payment
- Too many reasons to change
- Too many test scenarios to cover

### Solution: Separate into Single-Responsibility Classes

```java
// TESTABLE ✓

public class OrderValidator {
    public void validate(Order order) {
        if (order.getCustomer() == null) throw new ValidationException("No customer");
        if (order.getItems().isEmpty()) throw new ValidationException("No items");
        if (order.getTotal() <= 0) throw new ValidationException("Invalid total");
    }
}

public class OrderPaymentProcessor {
    private PaymentGateway gateway;
    
    public OrderPaymentProcessor(PaymentGateway gateway) {
        this.gateway = gateway;
    }
    
    public void process(Order order) {
        boolean paid = gateway.charge(order.getTotal());
        if (!paid) throw new PaymentException("Payment failed");
        order.markAsPaid();
    }
}

public class OrderPersistence {
    private Database db;
    
    public OrderPersistence(Database db) {
        this.db = db;
    }
    
    public void saveOrder(Order order) {
        db.saveOrder(order);
        db.updateInventory(order.getItems());
    }
}

public class OrderNotification {
    private EmailService email;
    
    public OrderNotification(EmailService email) {
        this.email = email;
    }
    
    public void notifyCustomer(Order order) {
        email.sendConfirmation(order);
    }
}

// High-level orchestrator (simpler, easier to test)
public class OrderService {
    private OrderValidator validator;
    private OrderPaymentProcessor payment;
    private OrderPersistence persistence;
    private OrderNotification notification;
    
    public OrderService(
        OrderValidator validator,
        OrderPaymentProcessor payment,
        OrderPersistence persistence,
        OrderNotification notification
    ) {
        this.validator = validator;
        this.payment = payment;
        this.persistence = persistence;
        this.notification = notification;
    }
    
    public void processOrder(Order order) {
        validator.validate(order);
        payment.process(order);
        persistence.saveOrder(order);
        notification.notifyCustomer(order);
    }
}
```

### Testing Individual Components

```java
@Test
public void testOrderValidator() {
    // Arrange
    OrderValidator validator = new OrderValidator();
    Order invalidOrder = new Order(); // Missing customer
    
    // Act & Assert
    assertThrows(ValidationException.class, () -> validator.validate(invalidOrder));
}

@Test
public void testOrderPaymentProcessor() {
    // Arrange
    PaymentGateway mockGateway = mock(PaymentGateway.class);
    when(mockGateway.charge(100)).thenReturn(true);
    OrderPaymentProcessor processor = new OrderPaymentProcessor(mockGateway);
    Order order = new Order();
    order.setTotal(100);
    
    // Act
    processor.process(order);
    
    // Assert
    assert(order.isPaid());
}

@Test
public void testOrderNotification() {
    // Arrange
    EmailService mockEmail = mock(EmailService.class);
    OrderNotification notification = new OrderNotification(mockEmail);
    Order order = new Order(id=123);
    
    // Act
    notification.notifyCustomer(order);
    
    // Assert
    verify(mockEmail).sendConfirmation(order);
}
```

### Benefits

| Benefit | Why |
|---------|-----|
| **Focused tests** | Each test focuses on one responsibility |
| **Fast setup** | Fewer dependencies to mock |
| **Reusable** | Each class can be reused independently |
| **Clear responsibilities** | What each class does is obvious |
| **Easy maintenance** | Changes to one concern don't affect others |

---

## Pattern 4: Test Data Builders [concept: testable-design]

### Problem: Complex Object Construction

```java
// HARD TO READ AND MAINTAIN ❌
@Test
public void testOrderProcessing() {
    Order order = new Order(
        1,
        new Customer(1, "John", "john@example.com", new Address("123 Main St", "NYC", "NY", "10001")),
        Arrays.asList(
            new LineItem("item1", 10.0, 2),
            new LineItem("item2", 20.0, 1)
        ),
        new ShippingInfo("UPS", "Express", 15.0),
        LocalDateTime.now(),
        null
    );
    
    // Test logic buried under construction complexity
}
```

### Solution: Use Builder Pattern for Test Data

```java
// READABLE AND MAINTAINABLE ✓

public class OrderBuilder {
    private long id = 1;
    private Customer customer = new CustomerBuilder().build();
    private List<LineItem> items = Arrays.asList(new LineItem("item1", 10.0, 1));
    private ShippingInfo shipping = new ShippingInfo("UPS", "Standard", 10.0);
    private LocalDateTime createdAt = LocalDateTime.now();
    private LocalDateTime shippedAt = null;
    
    public OrderBuilder withId(long id) {
        this.id = id;
        return this;
    }
    
    public OrderBuilder withCustomer(Customer customer) {
        this.customer = customer;
        return this;
    }
    
    public OrderBuilder withItems(LineItem... items) {
        this.items = Arrays.asList(items);
        return this;
    }
    
    public OrderBuilder withShipping(ShippingInfo shipping) {
        this.shipping = shipping;
        return this;
    }
    
    public Order build() {
        return new Order(id, customer, items, shipping, createdAt, shippedAt);
    }
}

public class CustomerBuilder {
    private long id = 1;
    private String name = "John Doe";
    private String email = "john@example.com";
    private Address address = new AddressBuilder().build();
    
    public CustomerBuilder withName(String name) {
        this.name = name;
        return this;
    }
    
    public CustomerBuilder withEmail(String email) {
        this.email = email;
        return this;
    }
    
    public Customer build() {
        return new Customer(id, name, email, address);
    }
}
```

### Using Builders in Tests

```java
@Test
public void testOrderProcessingWithBuilder() {
    // Arrange - Much clearer!
    Order order = new OrderBuilder()
        .withCustomer(new CustomerBuilder().withName("Alice").build())
        .withItems(
            new LineItem("laptop", 999.99, 1),
            new LineItem("mouse", 29.99, 2)
        )
        .withShipping(new ShippingInfo("FedEx", "Overnight", 25.0))
        .build();
    
    // Act
    OrderService service = new OrderService(mockPayment, mockDB, mockEmail);
    service.processOrder(order);
    
    // Assert - Test intent is clear
    verify(mockDB).saveOrder(order);
}

@Test
public void testOrderWithMinimalData() {
    // Arrange
    Order order = new OrderBuilder()
        .withId(999)
        .build();
    
    // Act & Assert
    assert(order.getId() == 999);
}
```

### Benefits

| Benefit | Why |
|---------|-----|
| **Readability** | Test intent is clear |
| **Flexibility** | Only specify what matters for test |
| **Defaults** | Sensible defaults for everything |
| **Reusability** | Same builder used across tests |
| **Maintainability** | Change object structure, update builder once |

---

## Pattern 5: Parameterized Tests for Polymorphism [concept: polymorphism]

### Problem: Writing Same Test for Each Implementation

```java
// REPETITIVE AND HARD TO MAINTAIN ❌
@Test
public void testCreditCardPaymentMethod() {
    PaymentMethod method = new CreditCard("1234-5678");
    assertTrue(method.validate());
    assertTrue(method.charge(100));
}

@Test
public void testPayPalPaymentMethod() {
    PaymentMethod method = new PayPal("user@example.com");
    assertTrue(method.validate());
    assertTrue(method.charge(100));
}

@Test
public void testBitcoinPaymentMethod() {
    PaymentMethod method = new Bitcoin("wallet123");
    assertTrue(method.validate());
    assertTrue(method.charge(100));
}

// More test methods for each payment type...
```

### Solution: Parameterized Tests

```java
// CONCISE AND DRY ✓

@ParameterizedTest
@ValueSource(classes = {
    CreditCard.class,
    PayPal.class,
    Bitcoin.class
})
public void testAllPaymentMethods(Class<?> paymentClass) throws Exception {
    // Arrange
    PaymentMethod method = (PaymentMethod) paymentClass
        .getDeclaredConstructor(String.class)
        .newInstance("test_value");
    
    // Act & Assert
    assertTrue(method.validate());
    assertTrue(method.charge(100));
}
```

### Or with CSV Arguments

```java
@ParameterizedTest
@CsvSource({
    "CreditCard,1234-5678,true",
    "PayPal,user@example.com,true",
    "Bitcoin,wallet123,true",
    "InvalidMethod,invalid,false"
})
public void testPaymentMethodValidation(String type, String value, boolean expectedValid) {
    PaymentMethod method = PaymentMethodFactory.create(type, value);
    assertEquals(expectedValid, method.validate());
}
```

### Benefits

| Benefit | Why |
|---------|-----|
| **DRY** | One test method, multiple implementations |
| **Exhaustive** | All implementations tested same way |
| **Maintainable** | Add new implementation, test automatically applies |
| **Clear** | Test logic once, apply to many |
| **Contract validation** | Ensures all implementations satisfy contract |

---

## Pattern 6: Mock Objects [concept: testable-design]

### Problem: Can't Test Without External Collaboration

```java
// CAN'T TEST IN ISOLATION ❌
public class ReportGenerator {
    private DatabaseConnection db;
    
    public String generateReport(int year) {
        List<SalesData> data = db.fetchSalesData(year);  // Needs real database!
        return formatReport(data);
    }
}

@Test
public void testReportGeneration() {
    // Can't test - need real database, real data
    DatabaseConnection realDB = new DatabaseConnection("production");
    ReportGenerator generator = new ReportGenerator(realDB);
    // Test is slow, fragile, needs test data setup
}
```

### Solution: Use Mock Objects

```java
// TESTS IN ISOLATION ✓
public interface DatabaseConnection {
    List<SalesData> fetchSalesData(int year);
}

public class ReportGenerator {
    private DatabaseConnection db;
    
    public ReportGenerator(DatabaseConnection db) {
        this.db = db;
    }
    
    public String generateReport(int year) {
        List<SalesData> data = db.fetchSalesData(year);
        return formatReport(data);
    }
}

@Test
public void testReportGenerationSuccess() {
    // Arrange - Mock the database
    DatabaseConnection mockDB = mock(DatabaseConnection.class);
    List<SalesData> mockData = Arrays.asList(
        new SalesData(2024, 100000),
        new SalesData(2024, 200000)
    );
    when(mockDB.fetchSalesData(2024)).thenReturn(mockData);
    ReportGenerator generator = new ReportGenerator(mockDB);
    
    // Act
    String report = generator.generateReport(2024);
    
    // Assert
    assertTrue(report.contains("300000"));  // Sum of mock data
}

@Test
public void testReportGenerationEmptyData() {
    // Arrange - Mock empty data
    DatabaseConnection mockDB = mock(DatabaseConnection.class);
    when(mockDB.fetchSalesData(2024)).thenReturn(new ArrayList<>());
    ReportGenerator generator = new ReportGenerator(mockDB);
    
    // Act
    String report = generator.generateReport(2024);
    
    // Assert
    assertTrue(report.contains("No data"));
}
```

### Mock vs Spy vs Stub

```java
// Mock - Verify behavior was called
@Test
public void testWithMock() {
    Logger mockLogger = mock(Logger.class);
    Service service = new Service(mockLogger);
    
    service.doSomething();
    
    verify(mockLogger).log("action completed");  // Verify method was called
}

// Spy - Partial mock (real object with some mocked behavior)
@Test
public void testWithSpy() {
    List<String> realList = new ArrayList<>();
    List<String> spyList = spy(realList);
    
    spyList.add("item");
    
    verify(spyList).add("item");  // Verify real method was called
    assertEquals(1, spyList.size());  // Real behavior works
}

// Stub - Only cares about return value
@Test
public void testWithStub() {
    PaymentGateway stubGateway = mock(PaymentGateway.class);
    when(stubGateway.charge(100)).thenReturn(true);  // Stub the return value
    PaymentService service = new PaymentService(stubGateway);
    
    boolean result = service.processPayment(100);
    
    assertEquals(true, result);  // Only care about return value
}
```

---

## Pattern 7: Dependency Injection Frameworks

### Problem: Manual Wiring of All Dependencies

```java
// MANUAL AND ERROR-PRONE ❌
public class Application {
    public static void main(String[] args) {
        // Wire all dependencies manually
        DatabaseConnection db = new DatabaseConnection("prod");
        EmailService email = new EmailService("smtp.example.com");
        PaymentGateway payment = new PaymentGateway("api-key");
        Logger logger = new Logger("app.log");
        
        OrderValidator validator = new OrderValidator();
        OrderPaymentProcessor processor = new OrderPaymentProcessor(payment);
        OrderPersistence persistence = new OrderPersistence(db, logger);
        OrderNotification notification = new OrderNotification(email);
        
        OrderService service = new OrderService(
            validator,
            processor,
            persistence,
            notification
        );
        
        // Now use service...
    }
}
```

### Solution: Use Dependency Injection Framework

```java
// AUTOMATIC WIRING ✓

// 1. Spring Framework example
@Configuration
public class ApplicationConfig {
    @Bean
    public DatabaseConnection databaseConnection() {
        return new DatabaseConnection("prod");
    }
    
    @Bean
    public EmailService emailService() {
        return new EmailService("smtp.example.com");
    }
    
    @Bean
    public OrderService orderService(
        OrderValidator validator,
        OrderPaymentProcessor processor,
        OrderPersistence persistence,
        OrderNotification notification
    ) {
        return new OrderService(validator, processor, persistence, notification);
    }
}

// 2. Inject where needed
@Service
public class OrderFacade {
    @Autowired
    private OrderService orderService;
    
    public void handleOrder(Order order) {
        orderService.processOrder(order);
    }
}

// 3. Testing with Spring Boot Test
@SpringBootTest
public class OrderFacadeTest {
    @Autowired
    private OrderFacade facade;
    
    @MockBean
    private EmailService mockEmail;
    
    @MockBean
    private PaymentGateway mockPayment;
    
    @Test
    public void testOrderProcessing() {
        when(mockPayment.charge(anyDouble())).thenReturn(true);
        
        Order order = new Order("item1", 100);
        facade.handleOrder(order);
        
        verify(mockEmail).sendConfirmation(order);
    }
}
```

### Benefits

| Framework | Benefit |
|-----------|---------|
| **Spring** | Enterprise-grade, comprehensive |
| **Guice** | Lightweight, performant |
| **Dagger** | Compile-time safe, Android-friendly |
| **Manual** | No framework overhead |

---

## Anti-Patterns to Avoid

### Anti-Pattern 1: Leaky Abstractions

```java
// BAD ❌ - Abstraction leaks implementation details
public interface Repository {
    User findById(int id) throws SQLException;  // SQL exception leaks!
}

// GOOD ✓ - Clean abstraction
public interface Repository {
    User findById(int id) throws RepositoryException;
}
```

### Anti-Pattern 2: Hidden Side Effects

```java
// BAD ❌ - Hidden side effects make testing impossible
public class UserService {
    public User getUser(int id) {
        // Silently logs to global logger
        // Makes API call to tracking service
        // Updates cache
        // What else?
        return new User(id);
    }
}

// GOOD ✓ - Explicit side effects
public class UserService {
    private Logger logger;
    private TrackingService tracking;
    private Cache cache;
    
    public UserService(Logger logger, TrackingService tracking, Cache cache) {
        this.logger = logger;
        this.tracking = tracking;
        this.cache = cache;
    }
    
    public User getUser(int id) {
        User user = cache.get(id);
        if (user == null) {
            user = loadFromDatabase(id);
            logger.log("User loaded: " + id);
            tracking.trackAccess(id);
        }
        return user;
    }
}
```

### Anti-Pattern 3: Testing Private Methods

```java
// BAD ❌ - Tests private methods (implementation detail)
@Test
public void testPrivateHelper() {
    Service service = new Service();
    // Using reflection to access private method - WRONG!
}

// GOOD ✓ - Test public interface
@Test
public void testPublicBehavior() {
    Service service = new Service();
    Result result = service.process(input);
    // Verify via public interface
}
```

### Anti-Pattern 4: Flaky Tests

```java
// BAD ❌ - Test depends on timing
@Test
public void testAsync() throws InterruptedException {
    service.doAsync();
    Thread.sleep(100);  // Hope 100ms is enough!
    assert(service.isComplete());
}

// GOOD ✓ - Use proper async testing
@Test
public void testAsync() {
    service.doAsync();
    awaitAssert(() -> assertTrue(service.isComplete()));
}
```

---

## Quick Reference: Testability Checklist

- [ ] All dependencies are injectable
- [ ] No hard-coded instantiation of external services
- [ ] No static methods (or static methods are pure functions)
- [ ] No global state or singletons (except for truly immutable config)
- [ ] All classes have single responsibility
- [ ] Dependencies implement interfaces (not concrete classes)
- [ ] Errors throw exceptions (don't silently fail)
- [ ] State changes are explicit and observable
- [ ] No hidden side effects in methods
- [ ] Test can run without database/network/file system

---

## Summary

| Pattern | Problem Solved | When to Use |
|---------|----------------|------------|
| Constructor Injection | Hard-coded dependencies | Always - default choice |
| Extract Interface | Can't mock concrete classes | All external dependencies |
| Separate Concerns | God classes | Classes > 300 lines or > 1 responsibility |
| Test Data Builders | Complex test setup | Tests with 3+ objects |
| Parameterized Tests | Test repetition | Multiple implementations of interface |
| Mock Objects | Can't test without collaborators | External services (DB, API, email) |
| DI Frameworks | Manual wiring complexity | Complex dependency graphs |

Each pattern makes testing easier. Combine them for maximum testability.
