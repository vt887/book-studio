# Test Examples: Concrete Code for OOP Testing

- **Book:** Object-Oriented Thinking by Vaysfeld
- **Role:** Tester
- **Concept:** Practical Test Implementation Examples
- **Generated:** 2026-04-25T16:45:00Z
- **Gate:** APPLY-VALID PASSED (0.88)

Language: **Java with JUnit 5 & Mockito** (adaptable to other frameworks)

---

## Example 1: Encapsulation Testing [concept: encapsulation]

### Class Being Tested

```java
public class BankAccount {
    private double balance;
    private String accountNumber;
    
    public BankAccount(double initialBalance) {
        if (initialBalance < 0) {
            throw new IllegalArgumentException("Initial balance cannot be negative");
        }
        this.balance = initialBalance;
    }
    
    public double getBalance() {
        return balance;
    }
    
    public void deposit(double amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("Deposit amount must be positive");
        }
        balance += amount;
    }
    
    public void withdraw(double amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("Withdrawal amount must be positive");
        }
        if (amount > balance) {
            throw new InsufficientFundsException("Insufficient balance");
        }
        balance -= amount;
    }
}
```

### Test Cases

```java
@DisplayName("BankAccount Encapsulation Tests")
class BankAccountTest {
    
    private BankAccount account;
    
    @BeforeEach
    void setUp() {
        account = new BankAccount(1000);
    }
    
    @Nested
    @DisplayName("Constructor Tests")
    class ConstructorTests {
        
        @Test
        @DisplayName("Should initialize account with positive balance")
        void testConstructorValidBalance() {
            // Arrange & Act
            BankAccount newAccount = new BankAccount(500);
            
            // Assert
            assertEquals(500, newAccount.getBalance());
        }
        
        @Test
        @DisplayName("Should reject negative initial balance")
        void testConstructorNegativeBalance() {
            // Arrange, Act & Assert
            IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> new BankAccount(-100),
                "Constructor should reject negative balance"
            );
            
            assertTrue(exception.getMessage().contains("negative"));
        }
        
        @Test
        @DisplayName("Should initialize with zero balance")
        void testConstructorZeroBalance() {
            // Arrange & Act
            BankAccount newAccount = new BankAccount(0);
            
            // Assert
            assertEquals(0, newAccount.getBalance());
        }
    }
    
    @Nested
    @DisplayName("Deposit Tests")
    class DepositTests {
        
        @Test
        @DisplayName("Should increase balance for valid deposit")
        void testValidDeposit() {
            // Arrange
            double initialBalance = account.getBalance();
            double depositAmount = 200;
            
            // Act
            account.deposit(depositAmount);
            
            // Assert
            assertEquals(
                initialBalance + depositAmount,
                account.getBalance(),
                "Balance should increase by deposit amount"
            );
        }
        
        @Test
        @DisplayName("Should reject zero or negative deposits")
        void testInvalidDeposit() {
            // Arrange
            double initialBalance = account.getBalance();
            
            // Act & Assert - Zero deposit
            assertThrows(
                IllegalArgumentException.class,
                () -> account.deposit(0),
                "Should reject zero deposit"
            );
            
            // Verify balance unchanged
            assertEquals(initialBalance, account.getBalance());
            
            // Act & Assert - Negative deposit
            assertThrows(
                IllegalArgumentException.class,
                () -> account.deposit(-100),
                "Should reject negative deposit"
            );
            
            // Verify balance still unchanged
            assertEquals(initialBalance, account.getBalance());
        }
        
        @ParameterizedTest
        @ValueSource(doubles = { 1, 10, 100, 1000, 99999.99 })
        @DisplayName("Should accept various positive deposit amounts")
        void testMultipleDepositAmounts(double amount) {
            // Arrange
            double initialBalance = account.getBalance();
            
            // Act
            account.deposit(amount);
            
            // Assert
            assertEquals(initialBalance + amount, account.getBalance());
        }
    }
    
    @Nested
    @DisplayName("Withdrawal Tests")
    class WithdrawalTests {
        
        @Test
        @DisplayName("Should decrease balance for valid withdrawal")
        void testValidWithdrawal() {
            // Arrange
            double initialBalance = account.getBalance();
            double withdrawAmount = 200;
            
            // Act
            account.withdraw(withdrawAmount);
            
            // Assert
            assertEquals(
                initialBalance - withdrawAmount,
                account.getBalance(),
                "Balance should decrease by withdrawal amount"
            );
        }
        
        @Test
        @DisplayName("Should reject withdrawal exceeding balance")
        void testInsufficientFunds() {
            // Arrange
            double balance = account.getBalance();
            double tooMuch = balance + 1;
            
            // Act & Assert
            InsufficientFundsException exception = assertThrows(
                InsufficientFundsException.class,
                () -> account.withdraw(tooMuch),
                "Should reject withdrawal exceeding balance"
            );
            
            // Verify balance unchanged
            assertEquals(balance, account.getBalance());
            assertTrue(exception.getMessage().contains("Insufficient"));
        }
        
        @Test
        @DisplayName("Should allow withdrawal of exact balance")
        void testWithdrawExactBalance() {
            // Arrange
            double balance = account.getBalance();
            
            // Act
            account.withdraw(balance);
            
            // Assert
            assertEquals(0, account.getBalance());
        }
        
        @Test
        @DisplayName("Should maintain non-negative balance invariant")
        void testBalanceNeverNegative() {
            // Arrange - Multiple operations
            account.deposit(500);
            account.withdraw(200);
            double currentBalance = account.getBalance();
            
            // Act & Assert - Try to violate invariant
            assertThrows(
                InsufficientFundsException.class,
                () -> account.withdraw(currentBalance + 1),
                "Balance should never become negative"
            );
            
            // Verify invariant maintained
            assertTrue(account.getBalance() >= 0);
        }
    }
}
```

---

## Example 2: Inheritance Testing [concept: inheritance]

### Class Hierarchy

```java
public abstract class PaymentMethod {
    protected String identifier;
    
    public PaymentMethod(String identifier) {
        this.identifier = identifier;
    }
    
    abstract boolean validate();
    abstract PaymentResult process(double amount);
    abstract String getMethodType();
}

public class CreditCard extends PaymentMethod {
    private String cardNumber;
    
    public CreditCard(String cardNumber) {
        super(cardNumber);
        this.cardNumber = cardNumber;
    }
    
    @Override
    boolean validate() {
        return cardNumber != null && cardNumber.length() == 16;
    }
    
    @Override
    PaymentResult process(double amount) {
        if (!validate()) {
            return PaymentResult.failed("Invalid card");
        }
        // Process payment
        return PaymentResult.success("CC-TX-123");
    }
    
    @Override
    String getMethodType() {
        return "Credit Card";
    }
}

public class PayPal extends PaymentMethod {
    private String email;
    
    public PayPal(String email) {
        super(email);
        this.email = email;
    }
    
    @Override
    boolean validate() {
        return email != null && email.contains("@");
    }
    
    @Override
    PaymentResult process(double amount) {
        if (!validate()) {
            return PaymentResult.failed("Invalid email");
        }
        return PaymentResult.success("PP-TX-456");
    }
    
    @Override
    String getMethodType() {
        return "PayPal";
    }
}

public class PaymentResult {
    private boolean success;
    private String transactionId;
    private String errorMessage;
    
    // Getters and factory methods...
}
```

### Test Cases

```java
@DisplayName("PaymentMethod Inheritance Tests")
class PaymentMethodTest {
    
    @Nested
    @DisplayName("CreditCard Tests")
    class CreditCardTests {
        
        private CreditCard card;
        
        @BeforeEach
        void setUp() {
            card = new CreditCard("1234567890123456");
        }
        
        @Test
        @DisplayName("Should inherit from PaymentMethod")
        void testInheritance() {
            // Assert
            assertInstanceOf(PaymentMethod.class, card);
        }
        
        @Test
        @DisplayName("Should validate valid card")
        void testValidCardValidation() {
            // Act & Assert
            assertTrue(card.validate());
        }
        
        @Test
        @DisplayName("Should reject invalid card")
        void testInvalidCardValidation() {
            // Arrange
            CreditCard invalidCard = new CreditCard("123");  // Too short
            
            // Act & Assert
            assertFalse(invalidCard.validate());
        }
        
        @Test
        @DisplayName("Should process payment successfully")
        void testProcessPayment() {
            // Act
            PaymentResult result = card.process(100);
            
            // Assert
            assertTrue(result.isSuccess());
            assertNotNull(result.getTransactionId());
        }
        
        @Test
        @DisplayName("Should return correct method type")
        void testGetMethodType() {
            // Act & Assert
            assertEquals("Credit Card", card.getMethodType());
        }
    }
    
    @Nested
    @DisplayName("Liskov Substitution Principle (LSP) Tests")
    class LSPTests {
        
        @ParameterizedTest
        @DisplayName("All PaymentMethods satisfy same validation contract")
        @MethodSource("providePaymentMethods")
        void testValidationContract(PaymentMethod method) {
            // Act
            boolean isValid = method.validate();
            
            // Assert - validate() returns boolean
            assertInstanceOf(Boolean.class, isValid);
        }
        
        @ParameterizedTest
        @DisplayName("All PaymentMethods can process payments")
        @MethodSource("providePaymentMethods")
        void testProcessingContract(PaymentMethod method) {
            // Act
            PaymentResult result = method.process(100);
            
            // Assert - process() returns PaymentResult
            assertNotNull(result);
            assertTrue(
                result.isSuccess() || !result.isSuccess(),
                "Result should indicate success or failure"
            );
        }
        
        @ParameterizedTest
        @DisplayName("All PaymentMethods return method type")
        @MethodSource("providePaymentMethods")
        void testMethodTypeContract(PaymentMethod method) {
            // Act
            String methodType = method.getMethodType();
            
            // Assert - getMethodType() returns non-null String
            assertNotNull(methodType);
            assertTrue(methodType.length() > 0);
        }
        
        static Stream<PaymentMethod> providePaymentMethods() {
            return Stream.of(
                new CreditCard("1234567890123456"),
                new PayPal("user@example.com")
            );
        }
    }
}
```

---

## Example 3: Polymorphism Testing [concept: polymorphism]

### Test Data Builders

```java
@DisplayName("Polymorphism with Factories and Builders")
class PaymentServiceTest {
    
    // Build test data easily
    static class PaymentMethodBuilder {
        private PaymentMethod method;
        
        static PaymentMethodBuilder creditCard() {
            PaymentMethodBuilder builder = new PaymentMethodBuilder();
            builder.method = new CreditCard("1234567890123456");
            return builder;
        }
        
        static PaymentMethodBuilder paypal() {
            PaymentMethodBuilder builder = new PaymentMethodBuilder();
            builder.method = new PayPal("user@example.com");
            return builder;
        }
        
        PaymentMethod build() {
            return method;
        }
    }
    
    @Nested
    @DisplayName("Polymorphic Collections")
    class PolymorphicCollectionsTests {
        
        @Test
        @DisplayName("Should process multiple payment methods")
        void testProcessMultipleMethods() {
            // Arrange
            List<PaymentMethod> methods = Arrays.asList(
                PaymentMethodBuilder.creditCard().build(),
                PaymentMethodBuilder.paypal().build()
            );
            PaymentProcessor processor = new PaymentProcessor();
            
            // Act & Assert
            for (PaymentMethod method : methods) {
                PaymentResult result = processor.process(method, 100);
                
                // All should work regardless of type
                assertNotNull(result);
            }
        }
    }
    
    @Nested
    @DisplayName("Parameterized Polymorphism Tests")
    class ParameterizedPolymorphismTests {
        
        @ParameterizedTest
        @DisplayName("All payment methods should handle amounts correctly")
        @CsvSource({
            "1234567890123456,1",
            "1234567890123456,100",
            "1234567890123456,9999.99",
            "user@example.com,1",
            "user@example.com,100",
            "user@example.com,9999.99"
        })
        void testPaymentProcessing(String identifier, double amount) {
            // Arrange
            PaymentMethod method;
            if (identifier.contains("@")) {
                method = new PayPal(identifier);
            } else {
                method = new CreditCard(identifier);
            }
            PaymentProcessor processor = new PaymentProcessor();
            
            // Act
            PaymentResult result = processor.process(method, amount);
            
            // Assert - Works for all types with all amounts
            assertNotNull(result);
        }
    }
}
```

---

## Example 4: Mocking and Dependency Injection [concept: dependency-inversion]

### Service Class with Dependencies

```java
public class OrderService {
    private PaymentProcessor paymentProcessor;
    private EmailService emailService;
    private OrderRepository orderRepository;
    
    public OrderService(
        PaymentProcessor paymentProcessor,
        EmailService emailService,
        OrderRepository orderRepository
    ) {
        this.paymentProcessor = paymentProcessor;
        this.emailService = emailService;
        this.orderRepository = orderRepository;
    }
    
    public OrderResult createOrder(Order order) {
        // Validate
        if (order.getItems().isEmpty()) {
            throw new IllegalArgumentException("Order must have items");
        }
        
        // Process payment
        PaymentResult paymentResult = paymentProcessor.process(order.getPaymentMethod(), order.getTotal());
        
        if (!paymentResult.isSuccess()) {
            return OrderResult.failed("Payment failed");
        }
        
        // Save order
        orderRepository.save(order);
        
        // Send confirmation email
        emailService.sendOrderConfirmation(order);
        
        return OrderResult.success(order.getId());
    }
}
```

### Test with Mocks

```java
@DisplayName("OrderService with Mocks")
class OrderServiceTest {
    
    private OrderService orderService;
    private PaymentProcessor mockPaymentProcessor;
    private EmailService mockEmailService;
    private OrderRepository mockOrderRepository;
    
    @BeforeEach
    void setUp() {
        mockPaymentProcessor = mock(PaymentProcessor.class);
        mockEmailService = mock(EmailService.class);
        mockOrderRepository = mock(OrderRepository.class);
        
        orderService = new OrderService(
            mockPaymentProcessor,
            mockEmailService,
            mockOrderRepository
        );
    }
    
    @Nested
    @DisplayName("Successful Order Creation")
    class SuccessfulOrderTests {
        
        @Test
        @DisplayName("Should process payment and save order")
        void testSuccessfulOrderCreation() {
            // Arrange
            Order order = buildTestOrder();
            PaymentMethod paymentMethod = new CreditCard("1234567890123456");
            PaymentResult paymentResult = PaymentResult.success("TX-123");
            
            when(mockPaymentProcessor.process(paymentMethod, 100.0))
                .thenReturn(paymentResult);
            
            // Act
            OrderResult result = orderService.createOrder(order);
            
            // Assert
            assertTrue(result.isSuccess());
            
            // Verify interactions
            verify(mockPaymentProcessor).process(paymentMethod, 100.0);
            verify(mockOrderRepository).save(order);
            verify(mockEmailService).sendOrderConfirmation(order);
        }
    }
    
    @Nested
    @DisplayName("Payment Failure Scenarios")
    class PaymentFailureTests {
        
        @Test
        @DisplayName("Should not save order if payment fails")
        void testOrderNotSavedOnPaymentFailure() {
            // Arrange
            Order order = buildTestOrder();
            PaymentMethod paymentMethod = new CreditCard("invalid");
            PaymentResult paymentFailure = PaymentResult.failed("Invalid card");
            
            when(mockPaymentProcessor.process(paymentMethod, 100.0))
                .thenReturn(paymentFailure);
            
            // Act
            OrderResult result = orderService.createOrder(order);
            
            // Assert
            assertFalse(result.isSuccess());
            
            // Verify order was NOT saved
            verify(mockOrderRepository, never()).save(any());
            // Email should NOT be sent
            verify(mockEmailService, never()).sendOrderConfirmation(any());
        }
        
        @Test
        @DisplayName("Should handle payment processor exception")
        void testHandlePaymentProcessorException() {
            // Arrange
            Order order = buildTestOrder();
            
            when(mockPaymentProcessor.process(any(), anyDouble()))
                .thenThrow(new RuntimeException("Payment gateway down"));
            
            // Act & Assert
            assertThrows(
                RuntimeException.class,
                () -> orderService.createOrder(order)
            );
        }
    }
    
    private Order buildTestOrder() {
        Order order = new Order();
        order.addItem(new OrderItem("Laptop", 100.0));
        return order;
    }
}
```

---

## Example 5: State Management Testing [concept: state-management]

### State Machine Class

```java
public class OrderStateMachine {
    enum State { PENDING, PAID, SHIPPED, DELIVERED }
    
    private State currentState;
    
    public OrderStateMachine() {
        this.currentState = State.PENDING;
    }
    
    public void pay() {
        if (currentState != State.PENDING) {
            throw new InvalidStateTransitionException(
                "Can only pay pending orders"
            );
        }
        currentState = State.PAID;
    }
    
    public void ship() {
        if (currentState != State.PAID) {
            throw new InvalidStateTransitionException(
                "Can only ship paid orders"
            );
        }
        currentState = State.SHIPPED;
    }
    
    public void deliver() {
        if (currentState != State.SHIPPED) {
            throw new InvalidStateTransitionException(
                "Can only deliver shipped orders"
            );
        }
        currentState = State.DELIVERED;
    }
    
    public State getState() {
        return currentState;
    }
}
```

### Test Cases

```java
@DisplayName("Order State Machine Tests")
class OrderStateMachineTest {
    
    private OrderStateMachine order;
    
    @BeforeEach
    void setUp() {
        order = new OrderStateMachine();
    }
    
    @Nested
    @DisplayName("Valid State Transitions")
    class ValidTransitionsTests {
        
        @Test
        @DisplayName("Should transition through all valid states")
        void testValidPath() {
            // Arrange & Act & Assert
            assertEquals(State.PENDING, order.getState());
            
            order.pay();
            assertEquals(State.PAID, order.getState());
            
            order.ship();
            assertEquals(State.SHIPPED, order.getState());
            
            order.deliver();
            assertEquals(State.DELIVERED, order.getState());
        }
    }
    
    @Nested
    @DisplayName("Invalid State Transitions")
    class InvalidTransitionsTests {
        
        @Test
        @DisplayName("Should not allow skipping states")
        void testCannotSkipStates() {
            // Arrange & Act & Assert
            assertThrows(
                InvalidStateTransitionException.class,
                () -> order.ship(),  // Cannot ship before paying
                "Should not allow transition from PENDING to SHIPPED"
            );
        }
        
        @Test
        @DisplayName("Should not allow backward transitions")
        void testCannotGoBackward() {
            // Arrange
            order.pay();
            
            // Act & Assert
            assertThrows(
                InvalidStateTransitionException.class,
                () -> order.pay(),  // Cannot pay twice
                "Should not allow transition from PAID to PENDING"
            );
        }
        
        @Test
        @DisplayName("Should not allow duplicate transitions")
        void testCannotDuplicateTransitions() {
            // Arrange
            order.pay();
            order.ship();
            order.deliver();
            
            // Act & Assert - Already delivered
            assertThrows(
                InvalidStateTransitionException.class,
                () -> order.deliver(),
                "Cannot deliver twice"
            );
        }
    }
}
```

---

## Example 6: Exception Testing [concept: error-handling]

### Methods with Error Handling

```java
public class UserValidator {
    public void validateEmail(String email) {
        if (email == null) {
            throw new NullPointerException("Email cannot be null");
        }
        if (email.isEmpty()) {
            throw new ValidationException("Email cannot be empty");
        }
        if (!email.contains("@")) {
            throw new ValidationException("Email must contain @");
        }
    }
    
    public void validateAge(int age) {
        if (age < 0) {
            throw new ValidationException("Age cannot be negative");
        }
        if (age > 150) {
            throw new ValidationException("Age cannot exceed 150");
        }
    }
}
```

### Exception Tests

```java
@DisplayName("Exception Handling Tests")
class ExceptionHandlingTest {
    
    private UserValidator validator;
    
    @BeforeEach
    void setUp() {
        validator = new UserValidator();
    }
    
    @Nested
    @DisplayName("Email Validation Exceptions")
    class EmailExceptionTests {
        
        @Test
        @DisplayName("Should throw NullPointerException for null email")
        void testNullEmailThrowsNPE() {
            // Act & Assert
            NullPointerException exception = assertThrows(
                NullPointerException.class,
                () -> validator.validateEmail(null),
                "Should throw NPE for null email"
            );
            
            assertTrue(exception.getMessage().contains("null"));
        }
        
        @Test
        @DisplayName("Should throw ValidationException for empty email")
        void testEmptyEmailThrowsValidationException() {
            // Act & Assert
            ValidationException exception = assertThrows(
                ValidationException.class,
                () -> validator.validateEmail(""),
                "Should throw ValidationException for empty"
            );
            
            assertTrue(exception.getMessage().contains("empty"));
        }
        
        @ParameterizedTest
        @ValueSource(strings = { "invalid", "user@", "@example.com" })
        @DisplayName("Should reject invalid email formats")
        void testInvalidEmailFormats(String email) {
            // Act & Assert
            assertThrows(
                ValidationException.class,
                () -> validator.validateEmail(email)
            );
        }
    }
    
    @Nested
    @DisplayName("Age Validation Exceptions")
    class AgeExceptionTests {
        
        @ParameterizedTest
        @ValueSource(ints = { -1, -100, -999 })
        @DisplayName("Should reject negative ages")
        void testNegativeAgeRejected(int age) {
            // Act & Assert
            assertThrows(
                ValidationException.class,
                () -> validator.validateAge(age)
            );
        }
        
        @ParameterizedTest
        @ValueSource(ints = { 151, 200, 999 })
        @DisplayName("Should reject ages over 150")
        void testExcessiveAgeRejected(int age) {
            // Act & Assert
            assertThrows(
                ValidationException.class,
                () -> validator.validateAge(age)
            );
        }
        
        @ParameterizedTest
        @ValueSource(ints = { 0, 1, 18, 65, 150 })
        @DisplayName("Should accept valid ages")
        void testValidAgesAccepted(int age) {
            // Act & Assert - Should NOT throw
            assertDoesNotThrow(() -> validator.validateAge(age));
        }
    }
}
```

---

## Example 7: Integration Test with Test Fixtures

### Test Fixture Setup

```java
@DisplayName("Integration Tests with Test Fixtures")
@ExtendWith(SpringExtension.class)
@SpringBootTest
class OrderIntegrationTest {
    
    @Autowired
    private OrderService orderService;
    
    @MockBean
    private ExternalPaymentGateway externalGateway;
    
    private Order testOrder;
    
    @BeforeEach
    void setUp() {
        testOrder = createTestOrder();
        configureExternalGatewayMock();
    }
    
    private Order createTestOrder() {
        Order order = new Order();
        order.addItem(new OrderItem("Widget", 50.00));
        order.addItem(new OrderItem("Gadget", 25.00));
        return order;
    }
    
    private void configureExternalGatewayMock() {
        when(externalGateway.charge(anyString(), anyDouble()))
            .thenReturn(true);
    }
    
    @Test
    @DisplayName("Should process order end-to-end")
    void testOrderProcessing() {
        // Act
        OrderResult result = orderService.createOrder(testOrder);
        
        // Assert
        assertTrue(result.isSuccess());
        
        // Verify external gateway was called
        verify(externalGateway).charge(anyString(), eq(75.00));
    }
}
```

---

## Testing Framework Quick Reference

### JUnit 5 Annotations

```java
@Test                           // Mark as test method
@DisplayName("Description")     // Custom test name
@BeforeEach                     // Run before each test
@AfterEach                      // Run after each test
@BeforeAll                      // Run once before all tests
@AfterAll                       // Run once after all tests
@Nested                         // Group related tests
@ParameterizedTest              // Run with multiple parameters
@ValueSource                    // Provide parameter values
@CsvSource                      // CSV parameter values
```

### Mockito Methods

```java
mock(Class)                     // Create mock
when(mock.method()).thenReturn()  // Stub return value
verify(mock).method()           // Verify method called
spy(object)                     // Partial mock
argumentCaptor()                // Capture arguments
```

### Assertions

```java
assertEquals(expected, actual)  // Value equality
assertTrue(condition)           // Boolean true
assertFalse(condition)          // Boolean false
assertNull(value)               // Is null
assertNotNull(value)            // Is not null
assertThrows(Exception, code)   // Throws exception
assertDoesNotThrow(code)        // Doesn't throw
```

---

## Summary

These examples demonstrate:

1. **Encapsulation Testing**: Verify state protection and validation
2. **Inheritance Testing**: Verify parent-child contracts and LSP
3. **Polymorphism Testing**: Use parameterized tests for multiple implementations
4. **Mocking**: Inject mocks for external dependencies
5. **State Management**: Test valid state transitions
6. **Exception Handling**: Verify correct exceptions thrown
7. **Integration Testing**: Test multiple components working together

All examples follow the **AAA pattern** (Arrange-Act-Assert) and use best practices for testable OOP code.
