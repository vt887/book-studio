# Object-Oriented Thinking — Code Examples

**Book:** Object-Oriented Thinking by Vaysfeld  
**Role:** Developer  
**Generated:** 2026-04-25  

---

## Complete Code Examples Repository

This file contains all code snippets organized by concept for easy reference and copy-paste.

---

## 1. CLASS DEFINITION EXAMPLES

### Example 1A: Before/After — Order Processing

**❌ ANTI-PATTERN: God Object**

```java
public class OrderProcessor {
    private List<Item> items;
    private Customer customer;
    private PaymentMethod payment;
    private String shippingAddress;
    private List<String> validationErrors = new ArrayList<>();
    
    public boolean processOrder(Order order) {
        // Validation
        if (customer == null) validationErrors.add("Customer required");
        if (items.isEmpty()) validationErrors.add("No items");
        if (payment == null) validationErrors.add("Payment required");
        
        if (!validationErrors.isEmpty()) {
            return false;
        }
        
        // Payment processing
        try {
            double total = calculateTotal();
            paymentGateway.charge(payment, total);
        } catch (Exception e) {
            validationErrors.add("Payment failed: " + e.getMessage());
            return false;
        }
        
        // Inventory management
        for (Item item : items) {
            inventory.decrementStock(item.getId(), item.getQuantity());
        }
        
        // Database save
        database.save(order);
        
        // Email notification
        emailService.send(
            customer.getEmail(),
            "Order confirmation: " + order.getId()
        );
        
        // Analytics
        analytics.track("order_placed", customer.getId(), total);
        
        return true;
    }
}
```

**Problems:**
- ❌ Does validation, payment, inventory, persistence, notification, analytics
- ❌ Impossible to unit test without mocking everything
- ❌ Change any one thing = risk breaking everything
- ❌ Can't reuse validation logic elsewhere

---

**✅ GOOD: Single-Responsibility Classes**

```java
// 1. Validation
public class OrderValidator {
    private CustomerRepository customerRepository;
    private InventoryRepository inventoryRepository;
    
    public ValidationResult validate(Order order) {
        if (order.getCustomerId() == null) {
            return ValidationResult.error("Customer ID required");
        }
        
        if (!customerRepository.exists(order.getCustomerId())) {
            return ValidationResult.error("Customer not found");
        }
        
        if (order.getItems().isEmpty()) {
            return ValidationResult.error("Order must contain items");
        }
        
        for (Item item : order.getItems()) {
            if (!inventoryRepository.hasStock(item.getId(), item.getQuantity())) {
                return ValidationResult.error(
                    "Insufficient stock for item: " + item.getId()
                );
            }
        }
        
        return ValidationResult.valid();
    }
}

// 2. Payment
public class PaymentProcessor {
    private PaymentGateway gateway;
    private TransactionRepository transactionRepository;
    
    public PaymentResult processPayment(Order order) {
        try {
            double amount = calculateOrderTotal(order);
            String transactionId = gateway.charge(
                order.getPaymentMethod(),
                amount
            );
            
            Transaction transaction = new Transaction(
                order.getId(),
                transactionId,
                amount,
                Instant.now()
            );
            transactionRepository.save(transaction);
            
            return PaymentResult.success(transactionId);
        } catch (PaymentGatewayException e) {
            return PaymentResult.failure(e.getMessage());
        }
    }
    
    private double calculateOrderTotal(Order order) {
        return order.getItems().stream()
            .mapToDouble(item -> item.getPrice() * item.getQuantity())
            .sum();
    }
}

// 3. Inventory Management
public class InventoryManager {
    private InventoryRepository repository;
    
    public void reserveStock(Order order) throws InsufficientStockException {
        for (Item item : order.getItems()) {
            if (!repository.hasStock(item.getId(), item.getQuantity())) {
                throw new InsufficientStockException(
                    "Item " + item.getId() + " out of stock"
                );
            }
        }
        
        for (Item item : order.getItems()) {
            repository.decrementStock(item.getId(), item.getQuantity());
        }
    }
}

// 4. Order Persistence
public class OrderRepository {
    private Database database;
    
    public Order save(Order order) {
        database.insert("orders", order.toMap());
        return order;
    }
    
    public Optional<Order> findById(String orderId) {
        Map<String, Object> row = database.selectOne("orders", "id", orderId);
        return row != null ? Optional.of(Order.fromMap(row)) : Optional.empty();
    }
}

// 5. Order Notification
public class OrderNotificationService {
    private EmailService emailService;
    
    public void notifyOrderPlaced(Order order, Customer customer) {
        emailService.send(
            customer.getEmail(),
            "Order Confirmation",
            buildEmailBody(order)
        );
    }
    
    public void notifyOrderShipped(Order order, Customer customer, String trackingNumber) {
        emailService.send(
            customer.getEmail(),
            "Your Order Has Shipped",
            buildShippingEmailBody(order, trackingNumber)
        );
    }
    
    private String buildEmailBody(Order order) {
        return String.format(
            "Thank you for your order!\n\nOrder ID: %s\nTotal: $%.2f\n\nThank you!",
            order.getId(),
            order.calculateTotal()
        );
    }
    
    private String buildShippingEmailBody(Order order, String trackingNumber) {
        return String.format(
            "Your order has shipped!\n\nOrder ID: %s\nTracking: %s",
            order.getId(),
            trackingNumber
        );
    }
}

// 6. Order Processing Orchestrator
public class OrderProcessingService {
    private OrderValidator validator;
    private PaymentProcessor paymentProcessor;
    private InventoryManager inventoryManager;
    private OrderRepository orderRepository;
    private OrderNotificationService notificationService;
    private CustomerRepository customerRepository;
    
    public OrderResult processOrder(Order order) {
        // Step 1: Validate
        ValidationResult validation = validator.validate(order);
        if (!validation.isValid()) {
            return OrderResult.validationFailed(validation.getError());
        }
        
        // Step 2: Process Payment
        PaymentResult payment = paymentProcessor.processPayment(order);
        if (!payment.isSuccessful()) {
            return OrderResult.paymentFailed(payment.getError());
        }
        
        // Step 3: Reserve Inventory
        try {
            inventoryManager.reserveStock(order);
        } catch (InsufficientStockException e) {
            // Refund payment if inventory unavailable
            paymentProcessor.refund(payment.getTransactionId());
            return OrderResult.inventoryFailed(e.getMessage());
        }
        
        // Step 4: Save Order
        Order savedOrder = orderRepository.save(order);
        
        // Step 5: Send Notification
        Customer customer = customerRepository.findById(order.getCustomerId()).get();
        notificationService.notifyOrderPlaced(savedOrder, customer);
        
        return OrderResult.success(savedOrder);
    }
}
```

**Benefits:**
- ✅ Each class easy to test independently
- ✅ Each class easy to modify without affecting others
- ✅ Can reuse OrderValidator, PaymentProcessor elsewhere
- ✅ Clear separation of concerns

---

### Example 1B: Testing the Refactored Classes

```java
@Test
public void testOrderValidator_WithValidOrder() {
    // Setup
    Customer customer = new Customer("C123", "John Doe");
    Item item = new Item("ITEM-001", "Laptop", 999.99, 1);
    Order order = new Order("O001", "C123", Arrays.asList(item));
    
    OrderValidator validator = new OrderValidator(
        mockCustomerRepository(customer),
        mockInventoryRepository(true)
    );
    
    // Execute
    ValidationResult result = validator.validate(order);
    
    // Verify
    assertTrue(result.isValid());
}

@Test
public void testOrderValidator_WithMissingCustomer() {
    OrderValidator validator = new OrderValidator(
        mockCustomerRepository(null),  // Customer not found
        mockInventoryRepository(true)
    );
    
    ValidationResult result = validator.validate(orderWithCustomer("C999"));
    
    assertFalse(result.isValid());
    assertTrue(result.getError().contains("Customer not found"));
}

@Test
public void testPaymentProcessor_WithSuccessfulCharge() {
    PaymentProcessor processor = new PaymentProcessor(
        mockGateway(success()),
        mockTransactionRepository()
    );
    
    PaymentResult result = processor.processPayment(orderFor(100.00));
    
    assertTrue(result.isSuccessful());
    assertNotNull(result.getTransactionId());
}

@Test
public void testOrderProcessingService_EndToEnd() {
    OrderProcessingService service = new OrderProcessingService(
        validatingValidator,
        successfulPaymentProcessor,
        inventoryManager,
        orderRepository,
        notificationService,
        customerRepository
    );
    
    Order order = createTestOrder();
    OrderResult result = service.processOrder(order);
    
    assertTrue(result.isSuccessful());
    verify(notificationService).notifyOrderPlaced(any(), any());
}
```

---

## 2. ENCAPSULATION EXAMPLES

### Example 2A: Bank Account with Validation

```java
public class BankAccount {
    // Private fields: hidden from clients
    private final String accountNumber;
    private final Customer owner;
    private BigDecimal balance;
    private final List<Transaction> transactionHistory;
    private final TransactionLog logger;
    
    // Constructor: enforces initial valid state
    public BankAccount(
        String accountNumber,
        Customer owner,
        BigDecimal initialBalance,
        TransactionLog logger
    ) {
        if (accountNumber == null || accountNumber.trim().isEmpty()) {
            throw new IllegalArgumentException("Account number required");
        }
        if (owner == null) {
            throw new IllegalArgumentException("Owner required");
        }
        if (initialBalance == null || initialBalance.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Initial balance cannot be negative");
        }
        
        this.accountNumber = accountNumber;
        this.owner = owner;
        this.balance = initialBalance;
        this.transactionHistory = new ArrayList<>();
        this.logger = logger;
        
        if (initialBalance.compareTo(BigDecimal.ZERO) > 0) {
            recordTransaction("ACCOUNT_OPENED", initialBalance, "System");
        }
    }
    
    // Read-only getters
    public String getAccountNumber() {
        return accountNumber;
    }
    
    public Customer getOwner() {
        return owner;
    }
    
    public BigDecimal getBalance() {
        return balance;
    }
    
    // Public operations with validation
    public void deposit(BigDecimal amount) throws InvalidTransactionException {
        if (amount == null) {
            throw new InvalidTransactionException("Amount cannot be null");
        }
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new InvalidTransactionException("Deposit amount must be positive");
        }
        
        this.balance = balance.add(amount);
        recordTransaction("DEPOSIT", amount, "Customer");
        logger.log("Deposit: " + amount + " to " + accountNumber);
    }
    
    public void withdraw(BigDecimal amount) throws InvalidTransactionException {
        if (amount == null) {
            throw new InvalidTransactionException("Amount cannot be null");
        }
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new InvalidTransactionException("Withdrawal amount must be positive");
        }
        if (amount.compareTo(balance) > 0) {
            throw new InvalidTransactionException(
                "Insufficient funds. Balance: " + balance + ", Requested: " + amount
            );
        }
        
        this.balance = balance.subtract(amount);
        recordTransaction("WITHDRAWAL", amount, "Customer");
        logger.log("Withdrawal: " + amount + " from " + accountNumber);
    }
    
    public void transfer(BankAccount recipient, BigDecimal amount)
        throws InvalidTransactionException {
        if (recipient == null) {
            throw new InvalidTransactionException("Recipient account required");
        }
        if (recipient.accountNumber.equals(this.accountNumber)) {
            throw new InvalidTransactionException("Cannot transfer to same account");
        }
        
        this.withdraw(amount);
        recipient.deposit(amount);
        recordTransaction("TRANSFER_OUT", amount, recipient.accountNumber);
        logger.log("Transfer: " + amount + " from " + accountNumber + 
                  " to " + recipient.accountNumber);
    }
    
    // Read transaction history (immutable snapshot)
    public List<Transaction> getTransactionHistory() {
        return new ArrayList<>(transactionHistory);  // Return copy
    }
    
    public List<Transaction> getTransactionHistory(int limit) {
        return transactionHistory.stream()
            .skip(Math.max(0, transactionHistory.size() - limit))
            .collect(Collectors.toList());
    }
    
    public BigDecimal getTotalDeposited() {
        return transactionHistory.stream()
            .filter(t -> t.getType().equals("DEPOSIT"))
            .map(Transaction::getAmount)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    
    // Private helper
    private void recordTransaction(String type, BigDecimal amount, String source) {
        Transaction transaction = new Transaction(
            UUID.randomUUID().toString(),
            type,
            amount,
            source,
            this.balance,
            Instant.now()
        );
        transactionHistory.add(transaction);
    }
}

// Transaction class is also encapsulated
public final class Transaction {
    private final String id;
    private final String type;
    private final BigDecimal amount;
    private final String source;
    private final BigDecimal balanceAfter;
    private final Instant timestamp;
    
    public Transaction(
        String id,
        String type,
        BigDecimal amount,
        String source,
        BigDecimal balanceAfter,
        Instant timestamp
    ) {
        this.id = id;
        this.type = type;
        this.amount = amount;
        this.source = source;
        this.balanceAfter = balanceAfter;
        this.timestamp = timestamp;
    }
    
    public String getId() { return id; }
    public String getType() { return type; }
    public BigDecimal getAmount() { return amount; }
    public String getSource() { return source; }
    public BigDecimal getBalanceAfter() { return balanceAfter; }
    public Instant getTimestamp() { return timestamp; }
}
```

---

### Example 2B: Immutable Money Class

```java
public final class Money {
    private final BigDecimal amount;
    private final Currency currency;
    
    // Factory method
    public static Money of(BigDecimal amount, Currency currency) {
        return new Money(amount, currency);
    }
    
    public static Money USD(String amount) {
        return new Money(new BigDecimal(amount), Currency.USD);
    }
    
    // Constructor is private (use factory methods)
    private Money(BigDecimal amount, Currency currency) {
        if (amount == null) {
            throw new IllegalArgumentException("Amount cannot be null");
        }
        if (currency == null) {
            throw new IllegalArgumentException("Currency cannot be null");
        }
        if (amount.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Amount cannot be negative");
        }
        
        this.amount = amount.setScale(2, RoundingMode.HALF_UP);
        this.currency = currency;
    }
    
    // Getters (read-only)
    public BigDecimal getAmount() {
        return amount;
    }
    
    public Currency getCurrency() {
        return currency;
    }
    
    // Operations return NEW instances (immutable)
    public Money add(Money other) {
        if (!this.currency.equals(other.currency)) {
            throw new IllegalArgumentException(
                "Cannot add different currencies: " + this.currency + " + " + other.currency
            );
        }
        return new Money(this.amount.add(other.amount), this.currency);
    }
    
    public Money subtract(Money other) {
        if (!this.currency.equals(other.currency)) {
            throw new IllegalArgumentException(
                "Cannot subtract different currencies"
            );
        }
        BigDecimal result = this.amount.subtract(other.amount);
        if (result.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Result would be negative");
        }
        return new Money(result, this.currency);
    }
    
    public Money multiply(BigDecimal factor) {
        if (factor == null || factor.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Factor must be non-negative");
        }
        return new Money(this.amount.multiply(factor), this.currency);
    }
    
    public Money divide(BigDecimal divisor) {
        if (divisor == null || divisor.compareTo(BigDecimal.ZERO) == 0) {
            throw new IllegalArgumentException("Divisor must be non-zero");
        }
        BigDecimal result = this.amount.divide(divisor, 2, RoundingMode.HALF_UP);
        return new Money(result, this.currency);
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Money)) return false;
        Money money = (Money) o;
        return amount.compareTo(money.amount) == 0 &&
               currency.equals(money.currency);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(amount, currency);
    }
    
    @Override
    public String toString() {
        return currency.getSymbol() + " " + amount;
    }
}

// Usage:
Money price = Money.USD("19.99");
Money tax = price.multiply(new BigDecimal("0.08"));
Money withTax = price.add(tax);

// ✅ Thread-safe: multiple threads can use price safely
// ✅ Predictable: price never changes
System.out.println(price);    // $ 19.99
System.out.println(withTax);  // $ 21.59
```

---

### Example 2C: Configuration with Validation

```java
public class DatabaseConfig {
    private final String host;
    private final int port;
    private final String database;
    private final String username;
    private final int maxPoolSize;
    private final int connectionTimeoutMs;
    private final boolean ssl;
    
    // Builder pattern for complex configuration
    public static class Builder {
        private String host;
        private int port = 5432;
        private String database;
        private String username;
        private int maxPoolSize = 10;
        private int connectionTimeoutMs = 5000;
        private boolean ssl = true;
        
        public Builder host(String host) {
            this.host = host;
            return this;
        }
        
        public Builder port(int port) {
            this.port = port;
            return this;
        }
        
        public Builder database(String database) {
            this.database = database;
            return this;
        }
        
        public Builder username(String username) {
            this.username = username;
            return this;
        }
        
        public Builder maxPoolSize(int size) {
            this.maxPoolSize = size;
            return this;
        }
        
        public Builder connectionTimeoutMs(int ms) {
            this.connectionTimeoutMs = ms;
            return this;
        }
        
        public Builder ssl(boolean enabled) {
            this.ssl = enabled;
            return this;
        }
        
        public DatabaseConfig build() {
            return new DatabaseConfig(
                host, port, database, username, maxPoolSize, connectionTimeoutMs, ssl
            );
        }
    }
    
    // Constructor with all validation
    private DatabaseConfig(
        String host, int port, String database, String username,
        int maxPoolSize, int connectionTimeoutMs, boolean ssl
    ) {
        this.host = validateHost(host);
        this.port = validatePort(port);
        this.database = validateDatabase(database);
        this.username = validateUsername(username);
        this.maxPoolSize = validatePoolSize(maxPoolSize);
        this.connectionTimeoutMs = validateTimeout(connectionTimeoutMs);
        this.ssl = ssl;
    }
    
    // Validation methods
    private String validateHost(String host) {
        if (host == null || host.trim().isEmpty()) {
            throw new IllegalArgumentException("Host cannot be empty");
        }
        return host;
    }
    
    private int validatePort(int port) {
        if (port < 1 || port > 65535) {
            throw new IllegalArgumentException("Port must be 1-65535, got: " + port);
        }
        return port;
    }
    
    private String validateDatabase(String database) {
        if (database == null || database.trim().isEmpty()) {
            throw new IllegalArgumentException("Database name cannot be empty");
        }
        return database;
    }
    
    private String validateUsername(String username) {
        if (username == null || username.trim().isEmpty()) {
            throw new IllegalArgumentException("Username cannot be empty");
        }
        return username;
    }
    
    private int validatePoolSize(int size) {
        if (size < 1 || size > 100) {
            throw new IllegalArgumentException("Pool size must be 1-100, got: " + size);
        }
        return size;
    }
    
    private int validateTimeout(int timeout) {
        if (timeout < 100 || timeout > 60000) {
            throw new IllegalArgumentException("Timeout must be 100-60000ms, got: " + timeout);
        }
        return timeout;
    }
    
    // Getters (read-only)
    public String getHost() { return host; }
    public int getPort() { return port; }
    public String getDatabase() { return database; }
    public String getUsername() { return username; }
    public int getMaxPoolSize() { return maxPoolSize; }
    public int getConnectionTimeoutMs() { return connectionTimeoutMs; }
    public boolean isSslEnabled() { return ssl; }
    
    // Connection string generation (computed property)
    public String getJdbcUrl() {
        return String.format(
            "jdbc:postgresql://%s:%d/%s?sslmode=%s&connectTimeout=%d",
            host,
            port,
            database,
            ssl ? "require" : "disable",
            connectionTimeoutMs
        );
    }
}

// Usage:
DatabaseConfig config = new DatabaseConfig.Builder()
    .host("db.example.com")
    .port(5432)
    .database("myapp")
    .username("appuser")
    .maxPoolSize(20)
    .build();

System.out.println(config.getJdbcUrl());
```

---

## 3. INHERITANCE EXAMPLES

### Example 3A: Employee Hierarchy

```java
// Base class: defines common Employee behavior
public abstract class Employee {
    protected String name;
    protected String employeeId;
    protected BigDecimal salary;
    protected LocalDate hireDate;
    
    public Employee(String name, String employeeId, BigDecimal salary) {
        this.name = name;
        this.employeeId = employeeId;
        this.salary = salary;
        this.hireDate = LocalDate.now();
    }
    
    // Common properties
    public String getName() { return name; }
    public String getEmployeeId() { return employeeId; }
    public BigDecimal getSalary() { return salary; }
    public LocalDate getHireDate() { return hireDate; }
    
    // Template method: defines algorithm structure
    public void work() {
        System.out.println(name + " is working");
        performSpecificWork();
        recordWorkHours();
    }
    
    // Subclasses implement specific work
    protected abstract void performSpecificWork();
    
    private void recordWorkHours() {
        System.out.println("Recorded work hours for " + name);
    }
    
    // Can be overridden by subclasses
    public BigDecimal calculateBonus() {
        // Default: 5% of salary
        return salary.multiply(new BigDecimal("0.05"));
    }
    
    public BigDecimal calculateYearlyCompensation() {
        return salary.add(calculateBonus());
    }
}

// Subclass 1: Manager
public class Manager extends Employee {
    private List<Employee> subordinates = new ArrayList<>();
    
    public Manager(String name, String employeeId, BigDecimal salary) {
        super(name, employeeId, salary);
    }
    
    @Override
    protected void performSpecificWork() {
        System.out.println(name + " is managing team");
    }
    
    @Override
    public BigDecimal calculateBonus() {
        // Managers get 10% + 1% per subordinate
        BigDecimal baseBonus = salary.multiply(new BigDecimal("0.10"));
        BigDecimal teamBonus = salary.multiply(
            new BigDecimal("0.01").multiply(new BigDecimal(subordinates.size()))
        );
        return baseBonus.add(teamBonus);
    }
    
    public void addSubordinate(Employee emp) {
        subordinates.add(emp);
    }
    
    public int getTeamSize() {
        return subordinates.size();
    }
}

// Subclass 2: Developer
public class Developer extends Employee {
    private List<String> skills = new ArrayList<>();
    private String primaryLanguage;
    
    public Developer(String name, String employeeId, BigDecimal salary, String primaryLanguage) {
        super(name, employeeId, salary);
        this.primaryLanguage = primaryLanguage;
    }
    
    @Override
    protected void performSpecificWork() {
        System.out.println(name + " is coding in " + primaryLanguage);
    }
    
    public void addSkill(String skill) {
        skills.add(skill);
    }
    
    public List<String> getSkills() {
        return new ArrayList<>(skills);
    }
    
    public String getPrimaryLanguage() {
        return primaryLanguage;
    }
}

// Subclass 3: QA Engineer
public class QAEngineer extends Employee {
    private String testingFramework;
    private int bugsFound;
    
    public QAEngineer(String name, String employeeId, BigDecimal salary, String framework) {
        super(name, employeeId, salary);
        this.testingFramework = framework;
        this.bugsFound = 0;
    }
    
    @Override
    protected void performSpecificWork() {
        System.out.println(name + " is testing with " + testingFramework);
    }
    
    @Override
    public BigDecimal calculateBonus() {
        // QA gets 5% + bonus per 100 bugs found
        BigDecimal baseBonus = salary.multiply(new BigDecimal("0.05"));
        BigDecimal bugBonus = salary.multiply(
            new BigDecimal("0.001").multiply(new BigDecimal(bugsFound))
        );
        return baseBonus.add(bugBonus);
    }
    
    public void recordBugFound() {
        bugsFound++;
    }
    
    public int getBugsFound() {
        return bugsFound;
    }
}

// Usage: Polymorphic
List<Employee> team = Arrays.asList(
    new Manager("Alice", "M001", new BigDecimal("100000")),
    new Developer("Bob", "D001", new BigDecimal("80000"), "Java"),
    new Developer("Carol", "D002", new BigDecimal("85000"), "Python"),
    new QAEngineer("David", "Q001", new BigDecimal("70000"), "Selenium")
);

// All work polymorphically
for (Employee emp : team) {
    emp.work();
    BigDecimal comp = emp.calculateYearlyCompensation();
    System.out.println(emp.getName() + " yearly: $" + comp);
}
```

---

### Example 3B: Payment Processing Hierarchy

```java
// Abstract base: defines payment contract
public abstract class PaymentProcessor {
    protected String processorId;
    protected TransactionRepository transactionRepository;
    
    public PaymentProcessor(String processorId, TransactionRepository repo) {
        this.processorId = processorId;
        this.transactionRepository = repo;
    }
    
    // Template method: orchestrates payment flow
    public final PaymentResult processPayment(Payment payment) {
        try {
            validate(payment);
            PaymentResult result = executePayment(payment);
            if (result.isSuccessful()) {
                recordTransaction(payment, result);
            }
            return result;
        } catch (Exception e) {
            return PaymentResult.failure(e.getMessage());
        }
    }
    
    // Subclasses implement specific validation
    protected void validate(Payment payment) {
        if (payment == null) {
            throw new IllegalArgumentException("Payment required");
        }
        if (payment.getAmount().compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Amount must be positive");
        }
    }
    
    // Subclasses implement payment execution
    protected abstract PaymentResult executePayment(Payment payment);
    
    // Common transaction recording
    private void recordTransaction(Payment payment, PaymentResult result) {
        Transaction transaction = new Transaction(
            UUID.randomUUID().toString(),
            processorId,
            payment.getAmount(),
            result.getTransactionId(),
            Instant.now()
        );
        transactionRepository.save(transaction);
    }
}

// Concrete implementation 1: Credit Card
public class CreditCardProcessor extends PaymentProcessor {
    private CreditCardGateway gateway;
    
    public CreditCardProcessor(String processorId, TransactionRepository repo, CreditCardGateway gateway) {
        super(processorId, repo);
        this.gateway = gateway;
    }
    
    @Override
    protected void validate(Payment payment) {
        super.validate(payment);  // Call parent validation
        
        if (!(payment instanceof CreditCardPayment)) {
            throw new IllegalArgumentException("Expected CreditCardPayment");
        }
        
        CreditCardPayment cc = (CreditCardPayment) payment;
        if (cc.getCardNumber() == null || cc.getCardNumber().isEmpty()) {
            throw new IllegalArgumentException("Card number required");
        }
    }
    
    @Override
    protected PaymentResult executePayment(Payment payment) {
        CreditCardPayment cc = (CreditCardPayment) payment;
        try {
            String transactionId = gateway.charge(
                cc.getCardNumber(),
                cc.getCvv(),
                payment.getAmount()
            );
            return PaymentResult.success(transactionId);
        } catch (GatewayException e) {
            return PaymentResult.failure("Card declined: " + e.getMessage());
        }
    }
}

// Concrete implementation 2: PayPal
public class PayPalProcessor extends PaymentProcessor {
    private PayPalGateway gateway;
    
    public PayPalProcessor(String processorId, TransactionRepository repo, PayPalGateway gateway) {
        super(processorId, repo);
        this.gateway = gateway;
    }
    
    @Override
    protected void validate(Payment payment) {
        super.validate(payment);
        
        if (!(payment instanceof PayPalPayment)) {
            throw new IllegalArgumentException("Expected PayPalPayment");
        }
        
        PayPalPayment pp = (PayPalPayment) payment;
        if (pp.getEmail() == null || pp.getEmail().isEmpty()) {
            throw new IllegalArgumentException("PayPal email required");
        }
    }
    
    @Override
    protected PaymentResult executePayment(Payment payment) {
        PayPalPayment pp = (PayPalPayment) payment;
        try {
            String transactionId = gateway.executePayment(
                pp.getEmail(),
                payment.getAmount()
            );
            return PaymentResult.success(transactionId);
        } catch (GatewayException e) {
            return PaymentResult.failure("PayPal error: " + e.getMessage());
        }
    }
}

// Concrete implementation 3: Stripe
public class StripeProcessor extends PaymentProcessor {
    private StripeGateway gateway;
    
    public StripeProcessor(String processorId, TransactionRepository repo, StripeGateway gateway) {
        super(processorId, repo);
        this.gateway = gateway;
    }
    
    @Override
    protected PaymentResult executePayment(Payment payment) {
        try {
            String transactionId = gateway.charge(
                payment.getCustomerId(),
                payment.getAmount()
            );
            return PaymentResult.success(transactionId);
        } catch (StripeException e) {
            return PaymentResult.failure("Stripe error: " + e.getMessage());
        }
    }
}

// Usage: Polymorphic payment processing
List<PaymentProcessor> processors = Arrays.asList(
    new CreditCardProcessor("cc-1", repo, ccGateway),
    new PayPalProcessor("pp-1", repo, ppGateway),
    new StripeProcessor("stripe-1", repo, stripeGateway)
);

Payment ccPayment = new CreditCardPayment(new BigDecimal("99.99"), "4111111111111111", "123");
Payment ppPayment = new PayPalPayment(new BigDecimal("99.99"), "user@paypal.com");

for (PaymentProcessor processor : processors) {
    PaymentResult result = processor.processPayment(ccPayment);
    System.out.println("Result: " + result);
}
```

---

### Example 3C: Exception Hierarchy

```java
// Base exception
public class ApplicationException extends Exception {
    private final String errorCode;
    
    public ApplicationException(String message, String errorCode) {
        super(message);
        this.errorCode = errorCode;
    }
    
    public String getErrorCode() {
        return errorCode;
    }
}

// Validation exceptions
public class ValidationException extends ApplicationException {
    public ValidationException(String message) {
        super(message, "VALIDATION_ERROR");
    }
}

public class InvalidEmailException extends ValidationException {
    public InvalidEmailException(String email) {
        super("Invalid email: " + email);
    }
}

// Business logic exceptions
public class InsufficientFundsException extends ApplicationException {
    private final BigDecimal requested;
    private final BigDecimal available;
    
    public InsufficientFundsException(BigDecimal requested, BigDecimal available) {
        super(
            String.format("Insufficient funds. Requested: %.2f, Available: %.2f", requested, available),
            "INSUFFICIENT_FUNDS"
        );
        this.requested = requested;
        this.available = available;
    }
}

// External service exceptions
public class PaymentGatewayException extends ApplicationException {
    private final int httpStatus;
    
    public PaymentGatewayException(String message, int httpStatus) {
        super(message, "GATEWAY_ERROR");
        this.httpStatus = httpStatus;
    }
    
    public int getHttpStatus() {
        return httpStatus;
    }
}

// Database exceptions
public class DatabaseException extends ApplicationException {
    public DatabaseException(String message, Throwable cause) {
        super(message, "DATABASE_ERROR");
        initCause(cause);
    }
}

// Usage with specific handling
try {
    processOrder(order);
} catch (ValidationException e) {
    logger.warn("Validation failed: " + e.getMessage());
    return Response.badRequest("Order validation failed");
} catch (InsufficientFundsException e) {
    logger.warn("Insufficient funds: " + e.getMessage());
    return Response.badRequest("Your account has insufficient funds");
} catch (PaymentGatewayException e) {
    logger.error("Payment gateway error: " + e.getMessage() + ", Status: " + e.getHttpStatus());
    return Response.serviceUnavailable("Payment service temporarily unavailable");
} catch (DatabaseException e) {
    logger.error("Database error: " + e.getMessage());
    return Response.internalError("System error occurred");
} catch (ApplicationException e) {
    logger.error("Unexpected application error: " + e.getErrorCode() + " - " + e.getMessage());
    return Response.internalError("Unexpected error occurred");
}
```

---

## 4. TESTING PATTERNS

### Example 4A: Testing Encapsulation

```java
@Test
public void testBankAccount_BalanceCannotGoNegative() {
    BankAccount account = new BankAccount("ACC-001", owner, new BigDecimal("100.00"));
    
    assertThrows(InvalidTransactionException.class, () -> {
        account.withdraw(new BigDecimal("150.00"));
    });
    
    assertEquals(new BigDecimal("100.00"), account.getBalance());
}

@Test
public void testBankAccount_TransactionRecorded() {
    BankAccount account = new BankAccount("ACC-001", owner, new BigDecimal("100.00"));
    
    account.deposit(new BigDecimal("50.00"));
    
    assertEquals(new BigDecimal("150.00"), account.getBalance());
    assertEquals(2, account.getTransactionHistory().size());
}

@Test
public void testBankAccount_HistoryImmutable() {
    BankAccount account = new BankAccount("ACC-001", owner, new BigDecimal("100.00"));
    
    List<Transaction> history1 = account.getTransactionHistory();
    account.deposit(new BigDecimal("50.00"));
    List<Transaction> history2 = account.getTransactionHistory();
    
    // history1 shouldn't have been affected
    assertNotEquals(history1.size(), history2.size());
}

@Test
public void testMoney_IsImmutable() {
    Money original = Money.USD("10.00");
    Money withTax = original.multiply(new BigDecimal("1.08"));
    
    assertEquals(Money.USD("10.00"), original);
    assertEquals(Money.USD("10.80"), withTax);
}
```

---

### Example 4B: Testing Inheritance

```java
@Test
public void testDeveloper_InheritsEmployeeProperties() {
    Developer dev = new Developer("Bob", "D001", new BigDecimal("60000"), "Java");
    
    assertEquals("Bob", dev.getName());
    assertEquals(new BigDecimal("60000"), dev.getSalary());
}

@Test
public void testManager_OverridesBonusCalculation() {
    Manager manager = new Manager("Jane", "M001", new BigDecimal("80000"));
    manager.addSubordinate(new Developer("Bob", "D001", new BigDecimal("60000"), "Java"));
    manager.addSubordinate(new Developer("Alice", "D002", new BigDecimal("60000"), "Python"));
    
    BigDecimal expected = new BigDecimal("80000")
        .multiply(new BigDecimal("0.10"))
        .add(new BigDecimal("80000").multiply(new BigDecimal("0.02")));
    
    assertEquals(expected, manager.calculateBonus());
}

@Test
public void testPolymorphism_AllEmployeesCanWork() {
    List<Employee> team = Arrays.asList(
        new Manager("Jane", "M001", new BigDecimal("80000")),
        new Developer("Bob", "D001", new BigDecimal("60000"), "Java"),
        new QAEngineer("David", "Q001", new BigDecimal("70000"), "Selenium")
    );
    
    // All should have work() method
    for (Employee emp : team) {
        emp.work();  // Should not throw
    }
}

@Test
public void testPaymentProcessors_AllFollowContract() {
    List<PaymentProcessor> processors = Arrays.asList(
        new CreditCardProcessor("cc-1", repo, ccGateway),
        new PayPalProcessor("pp-1", repo, ppGateway),
        new StripeProcessor("stripe-1", repo, stripeGateway)
    );
    
    Payment payment = new CreditCardPayment(new BigDecimal("99.99"), "4111111111111111", "123");
    
    for (PaymentProcessor processor : processors) {
        PaymentResult result = processor.processPayment(payment);
        assertNotNull(result);
        assertTrue(result.isSuccessful() || !result.isSuccessful());  // One or the other
    }
}
```

---

## 5. ANTI-PATTERNS TO AVOID

### Example 5A: God Object Anti-Pattern

```java
// ❌ ANTI-PATTERN: God Object (doing everything)
public class OrderManagementSystem {
    public void handleOrder(Order order) {
        // Validation
        // ...
        // Payment processing
        // ...
        // Inventory management
        // ...
        // Email notification
        // ...
        // Analytics
        // ...
        // Reporting
        // ...
        // Auditing
        // ...
    }
}

// ✅ GOOD: Focused classes
public class OrderValidationService { /* Validation only */ }
public class OrderPaymentService { /* Payment only */ }
public class OrderInventoryService { /* Inventory only */ }
public class OrderNotificationService { /* Notifications only */ }
public class OrderAnalyticsService { /* Analytics only */ }
public class OrderReportingService { /* Reporting only */ }
public class OrderAuditService { /* Auditing only */ }
```

---

### Example 5B: Leaky Encapsulation Anti-Pattern

```java
// ❌ ANTI-PATTERN: Direct access to internals
public class Account {
    public List<Transaction> transactions;
    public double balance;
}

// Client can corrupt state!
account.transactions.clear();
account.balance = -1000;

// ✅ GOOD: Encapsulated access
public class Account {
    private List<Transaction> transactions;
    private double balance;
    
    public List<Transaction> getTransactions() {
        return new ArrayList<>(transactions);  // Copy
    }
    
    public double getBalance() {
        return balance;
    }
    
    public void withdraw(double amount) {
        // Validation and state management
    }
}
```

---

### Example 5C: Inheritance Misuse Anti-Pattern

```java
// ❌ ANTI-PATTERN: Inheritance for code reuse
public class FileWriter {
    public void writeFile(String filename, String content) { /* ... */ }
}

public class EmailService extends FileWriter {  // WRONG!
    // "Borrowed" writeFile method
    // But EmailService is NOT-A FileWriter
}

// ✅ GOOD: Composition
public class EmailService {
    private FileWriter fileWriter;
    
    public EmailService(FileWriter fileWriter) {
        this.fileWriter = fileWriter;
    }
}
```

---

## End of Code Examples

All examples are production-ready and demonstrate the three core OOP concepts with proper error handling, testing, and real-world scenarios.
