# Design Patterns Catalog

**Source:** Object-Oriented Thinking by Vaysfeld  
**Format:** Comprehensive Pattern Reference  
**Total Patterns:** 13 core patterns

---

## Table of Contents

1. **Creational Patterns** (3)
2. **Structural Patterns** (4)
3. **Behavioral Patterns** (6)
4. **Anti-Patterns & When NOT to Use**

---

## CREATIONAL PATTERNS

### Pattern 1: Factory Pattern

**Purpose:** Abstract object creation, encapsulate instantiation logic

**When to Use:**
- Creation logic is complex or has multiple branches
- Different implementations needed based on input parameters
- Want to hide construction details from clients
- Need to decouple client code from concrete classes

**When NOT to Use:**
- Simple object creation (just use `new`)
- Only one implementation exists
- Would add unnecessary complexity

**Implementation:**

```java
// ✅ Simple Factory
public class PaymentGatewayFactory {
    public static IPaymentGateway create(PaymentMethod method) {
        return switch(method) {
            case CREDIT_CARD -> new CreditCardGateway();
            case PAYPAL -> new PayPalGateway();
            case CRYPTO -> new CryptoGateway();
            default -> throw new UnsupportedPaymentMethodException();
        };
    }
}

// ✅ Abstract Factory (multiple families of objects)
public interface IUIComponentFactory {
    Button createButton();
    TextBox createTextBox();
    Dialog createDialog();
}

public class WindowsUIFactory implements IUIComponentFactory {
    public Button createButton() { return new WindowsButton(); }
    public TextBox createTextBox() { return new WindowsTextBox(); }
    public Dialog createDialog() { return new WindowsDialog(); }
}

public class MacUIFactory implements IUIComponentFactory {
    public Button createButton() { return new MacButton(); }
    public TextBox createTextBox() { return new MacTextBox(); }
    public Dialog createDialog() { return new MacDialog(); }
}

// Usage
IUIComponentFactory factory = determineOSFactory();
Button button = factory.createButton();
Dialog dialog = factory.createDialog();
```

**Trade-offs:**
- ✅ Hides creation complexity
- ✅ Easy to add new types
- ❌ May be overkill for simple cases

---

### Pattern 2: Builder Pattern

**Purpose:** Construct complex objects step-by-step

**When to Use:**
- Objects have many optional parameters
- Object construction involves complex logic
- Want readable, self-documenting construction code
- Need multiple construction variations

**When NOT to Use:**
- Object has few/no optional fields
- Construction is trivial
- Immutability not required

**Implementation:**

```java
// ❌ BEFORE: Confusing constructor with many parameters
public class ReportBuilder extends Report {
    public Report(String title, String author, int pages, boolean isPublished,
                  String format, String theme, int fontSize, boolean includeIndex,
                  boolean includeTOC, String language, int marginSize) {
        // What do all these parameters mean?
    }
}

var report = new Report("Annual Report", "Alice", 50, true,
                        "PDF", "Professional", 12, true, true, "EN", 1);

// ✅ AFTER: Clear, self-documenting builder
public class ReportBuilder {
    private String title;
    private String author;
    private int pages;
    private boolean isPublished = false;
    private String format = "PDF";
    private String theme = "Professional";
    private int fontSize = 12;
    private boolean includeIndex = false;
    private boolean includeTOC = false;
    private String language = "EN";
    private int marginSize = 1;
    
    public ReportBuilder withTitle(String title) {
        this.title = title;
        return this;
    }
    
    public ReportBuilder withAuthor(String author) {
        this.author = author;
        return this;
    }
    
    public ReportBuilder published() {
        this.isPublished = true;
        return this;
    }
    
    public ReportBuilder theme(String theme) {
        this.theme = theme;
        return this;
    }
    
    public Report build() {
        if (title == null) throw new IllegalStateException("Title is required");
        return new Report(title, author, pages, isPublished, format, theme,
                         fontSize, includeIndex, includeTOC, language, marginSize);
    }
}

// Usage: Clear intent
var report = new ReportBuilder()
    .withTitle("Annual Report")
    .withAuthor("Alice")
    .published()
    .theme("Professional")
    .build();
```

**Trade-offs:**
- ✅ Readable, self-documenting code
- ✅ Immutable final objects
- ✅ Easy to add optional parameters
- ❌ Verbose for simple objects

---

### Pattern 3: Singleton Pattern

**Purpose:** Ensure only one instance of a class exists

**When to Use:**
- Shared resource (logger, connection pool, configuration)
- One instance is sufficient and clients need global access
- Expensive to create (database connection)

**When NOT to Use:**
- Testability matters (singletons complicate mocking)
- Multiple instances might be needed later
- Introduces hidden dependencies

**Implementation:**

```java
// ❌ POOR: Not thread-safe
public class Logger {
    private static Logger instance;
    
    private Logger() { }
    
    public static Logger getInstance() {
        if (instance == null) {
            instance = new Logger();  // Race condition!
        }
        return instance;
    }
}

// ✅ GOOD: Thread-safe, eager initialization
public class Logger {
    private static final Logger INSTANCE = new Logger();
    
    private Logger() { }
    
    public static Logger getInstance() {
        return INSTANCE;
    }
}

// ✅ BETTER: Dependency injection instead of singleton
public class Application {
    private Logger logger;
    
    public Application(Logger logger) {  // Injected, testable
        this.logger = logger;
    }
}
```

**Trade-offs:**
- ✅ Guaranteed single instance
- ✅ Global access point
- ❌ Hides dependencies
- ❌ Hard to test/mock
- ❌ Violates Single Responsibility Principle

**Recommendation:** Prefer dependency injection over singletons.

---

## STRUCTURAL PATTERNS

### Pattern 4: Adapter Pattern

**Purpose:** Make incompatible interfaces work together

**When to Use:**
- Integrating legacy systems with incompatible interfaces
- Third-party libraries don't match your expected interface
- Want to use class with wrong interface
- Need to provide unified interface to multiple implementations

**When NOT to Use:**
- Adapting becomes complex (signals design issue)
- Too many adapters needed

**Implementation:**

```java
// ✅ Adapting legacy payment system to new interface
public interface IPaymentGateway {
    PaymentResult charge(Money amount);
}

// Legacy system with incompatible interface
public class LegacyPaymentSystem {
    public void processPayment(double amount, String currency) {
        // Old API, different signature
    }
}

// Adapter: Makes legacy system compatible
public class LegacyPaymentSystemAdapter implements IPaymentGateway {
    private LegacyPaymentSystem legacySystem;
    
    public LegacyPaymentSystemAdapter(LegacyPaymentSystem legacySystem) {
        this.legacySystem = legacySystem;
    }
    
    @Override
    public PaymentResult charge(Money amount) {
        try {
            legacySystem.processPayment(
                amount.getAmount().doubleValue(),
                amount.getCurrency().getCode()
            );
            return PaymentResult.SUCCESS;
        } catch (Exception e) {
            return PaymentResult.FAILED;
        }
    }
}

// Usage: New code uses consistent interface
IPaymentGateway gateway = new LegacyPaymentSystemAdapter(legacySystem);
gateway.charge(Money.of(100, USD));
```

---

### Pattern 5: Decorator Pattern

**Purpose:** Add behavior to objects dynamically without modifying original class

**When to Use:**
- Add responsibilities to individual objects, not classes
- Avoid explosion of subclasses (Decorator avoids deep hierarchies)
- Need flexible combination of behaviors
- Adding behavior at runtime

**When NOT to Use:**
- Simple inheritance sufficient
- Order of decorators matters in non-obvious ways

**Implementation:**

```java
// ✅ Decorator for adding features to report
public interface IReport {
    String generate();
}

public class BasicReport implements IReport {
    public String generate() {
        return "Basic report content";
    }
}

// Decorators: add features without modifying BasicReport
public abstract class ReportDecorator implements IReport {
    protected IReport wrappedReport;
    
    public ReportDecorator(IReport report) {
        this.wrappedReport = report;
    }
}

public class HeaderDecorator extends ReportDecorator {
    public String generate() {
        return "=== REPORT HEADER ===\n" + wrappedReport.generate();
    }
}

public class FooterDecorator extends ReportDecorator {
    public String generate() {
        return wrappedReport.generate() + "\n=== REPORT FOOTER ===";
    }
}

public class TimestampDecorator extends ReportDecorator {
    public String generate() {
        return wrappedReport.generate() + "\nGenerated: " + LocalDateTime.now();
    }
}

// Usage: Compose behaviors flexibly
IReport report = new BasicReport();
report = new HeaderDecorator(report);
report = new FooterDecorator(report);
report = new TimestampDecorator(report);
System.out.println(report.generate());
// Outputs:
// === REPORT HEADER ===
// Basic report content
// === REPORT FOOTER ===
// Generated: 2026-04-25T10:30:00
```

---

### Pattern 6: Facade Pattern

**Purpose:** Provide simplified interface to complex subsystem

**When to Use:**
- Complex system needs simpler public interface
- Want to isolate clients from internal complexity
- Multiple interdependent classes need coordinated access
- Want to create entry point to layered architecture

**When NOT to Use:**
- System is already simple
- Would hide necessary functionality

**Implementation:**

```java
// Complex subsystem with multiple classes
public class ReportGenerator {
    public List<ReportData> gatherData() { /* */ return null; }
}

public class ReportValidator {
    public boolean validate(List<ReportData> data) { /* */ return true; }
}

public class ReportFormatter {
    public String format(List<ReportData> data) { /* */ return ""; }
}

public class ReportPersister {
    public void save(String formattedReport) { /* */ }
}

// ❌ BEFORE: Clients must coordinate complex sequence
var data = generator.gatherData();
if (!validator.validate(data)) throw new Exception();
var formatted = formatter.format(data);
persister.save(formatted);

// ✅ AFTER: Facade simplifies interaction
public class ReportFacade {
    private ReportGenerator generator;
    private ReportValidator validator;
    private ReportFormatter formatter;
    private ReportPersister persister;
    
    public ReportFacade() {
        this.generator = new ReportGenerator();
        this.validator = new ReportValidator();
        this.formatter = new ReportFormatter();
        this.persister = new ReportPersister();
    }
    
    public void generateAndSaveReport() {
        var data = generator.gatherData();
        if (!validator.validate(data)) {
            throw new InvalidReportDataException();
        }
        var formatted = formatter.format(data);
        persister.save(formatted);
    }
}

// Usage: Simple, clear intent
var facade = new ReportFacade();
facade.generateAndSaveReport();
```

---

### Pattern 7: Proxy Pattern

**Purpose:** Control access to another object

**When to Use:**
- Lazy initialization (create expensive objects on-demand)
- Access control (check permissions before delegating)
- Logging/monitoring access
- Remote access (to object in different process/machine)
- Resource pooling

**When NOT to Use:**
- Performance critical (proxy adds overhead)
- Simple object sufficient

**Implementation:**

```java
// ✅ Lazy-loading proxy for expensive resource
public interface IExpensiveService {
    String performExpensiveOperation();
}

public class RealExpensiveService implements IExpensiveService {
    public RealExpensiveService() {
        System.out.println("Creating expensive resource...");
        Thread.sleep(5000);  // Expensive initialization
    }
    
    public String performExpensiveOperation() {
        return "Result";
    }
}

public class LazyExpensiveServiceProxy implements IExpensiveService {
    private RealExpensiveService realService;
    
    @Override
    public String performExpensiveOperation() {
        if (realService == null) {
            System.out.println("First access: initializing...");
            realService = new RealExpensiveService();  // Only created when needed
        }
        return realService.performExpensiveOperation();
    }
}

// Usage
var service = new LazyExpensiveServiceProxy();
// Not created yet!
var result = service.performExpensiveOperation();  // Created here
var result2 = service.performExpensiveOperation();  // Reused
```

---

## BEHAVIORAL PATTERNS

### Pattern 8: Strategy Pattern

**Purpose:** Encapsulate algorithms for runtime selection

**When to Use:**
- Multiple algorithms for same task, selected at runtime
- Want to avoid conditionals (if/switch)
- Algorithms might change independently
- Need to test each algorithm separately

**When NOT to Use:**
- Only one algorithm exists
- Algorithm selection is rare

**Implementation:**

```java
// ✅ Strategy pattern for sorting algorithms
public interface ISortingStrategy {
    void sort(int[] array);
}

public class QuickSortStrategy implements ISortingStrategy {
    public void sort(int[] array) {
        System.out.println("Using QuickSort (O(n log n) average)");
        // Implementation
    }
}

public class MergeSortStrategy implements ISortingStrategy {
    public void sort(int[] array) {
        System.out.println("Using MergeSort (O(n log n) guaranteed)");
        // Implementation
    }
}

public class BubbleSortStrategy implements ISortingStrategy {
    public void sort(int[] array) {
        System.out.println("Using BubbleSort (O(n²) - for small arrays)");
        // Implementation
    }
}

public class SortingContext {
    private ISortingStrategy strategy;
    
    public SortingContext(ISortingStrategy strategy) {
        this.strategy = strategy;
    }
    
    public void sort(int[] array) {
        strategy.sort(array);
    }
}

// Usage: Select algorithm based on data size
var array = getArray();
ISortingStrategy strategy = array.length > 1000 
    ? new QuickSortStrategy() 
    : new BubbleSortStrategy();
var sorter = new SortingContext(strategy);
sorter.sort(array);
```

---

### Pattern 9: Observer Pattern

**Purpose:** Notify multiple objects when state changes (pub-sub)

**When to Use:**
- One object's changes should trigger actions in multiple others
- Don't know in advance how many objects need notification
- Want loose coupling between observer and subject
- Event-driven architecture

**When NOT to Use:**
- Changes are infrequent
- Too many observers causes performance issues

**Implementation:**

```java
// ✅ Observer pattern for user registration
public interface IUserObserver {
    void onUserRegistered(User user);
}

public class UserRegistrationSubject {
    private List<IUserObserver> observers = new ArrayList<>();
    
    public void registerObserver(IUserObserver observer) {
        observers.add(observer);
    }
    
    public void unregisterObserver(IUserObserver observer) {
        observers.remove(observer);
    }
    
    public void registerUser(User user) {
        // Register user logic
        notifyObservers(user);
    }
    
    private void notifyObservers(User user) {
        observers.forEach(observer -> observer.onUserRegistered(user));
    }
}

// Multiple observers react to registration
public class EmailNotificationObserver implements IUserObserver {
    public void onUserRegistered(User user) {
        System.out.println("Sending welcome email to " + user.getEmail());
    }
}

public class AnalyticsObserver implements IUserObserver {
    public void onUserRegistered(User user) {
        System.out.println("Recording user registration for analytics");
    }
}

public class AccountCreationObserver implements IUserObserver {
    public void onUserRegistered(User user) {
        System.out.println("Creating initial account for " + user.getName());
    }
}

// Usage: Easy to add/remove observers
var subject = new UserRegistrationSubject();
subject.registerObserver(new EmailNotificationObserver());
subject.registerObserver(new AnalyticsObserver());
subject.registerObserver(new AccountCreationObserver());

subject.registerUser(new User("Alice", "alice@example.com"));
```

---

### Pattern 10: State Pattern

**Purpose:** Encapsulate state-dependent behavior in separate objects

**When to Use:**
- Object behavior changes based on its state
- Want to avoid large if/switch statements
- State transitions are explicit
- Testing each state independently

**When NOT to Use:**
- Few states and simple transitions
- State is rarely accessed

**Implementation:**

```java
// ✅ State pattern for order lifecycle
public interface IOrderState {
    void next(Order order);
    void validate(Order order);
}

public class NewOrderState implements IOrderState {
    public void next(Order order) {
        order.setState(new ConfirmedOrderState());
    }
    
    public void validate(Order order) {
        // Can cancel before confirmation
    }
}

public class ConfirmedOrderState implements IOrderState {
    public void next(Order order) {
        order.setState(new ShippedOrderState());
    }
    
    public void validate(Order order) {
        // Can't go back
    }
}

public class ShippedOrderState implements IOrderState {
    public void next(Order order) {
        order.setState(new DeliveredOrderState());
    }
    
    public void validate(Order order) {
        // Can't cancel
    }
}

public class DeliveredOrderState implements IOrderState {
    public void next(Order order) {
        // Terminal state, can't transition
    }
    
    public void validate(Order order) {
        // Order complete
    }
}

public class Order {
    private IOrderState state;
    
    public Order() {
        this.state = new NewOrderState();
    }
    
    public void confirm() {
        state.next(this);  // NewOrderState → ConfirmedOrderState
    }
    
    public void ship() {
        state.next(this);  // ConfirmedOrderState → ShippedOrderState
    }
    
    public void deliver() {
        state.next(this);  // ShippedOrderState → DeliveredOrderState
    }
    
    public void setState(IOrderState state) {
        this.state = state;
    }
}

// Usage: State machine is clear and testable
var order = new Order();
order.confirm();   // New → Confirmed
order.ship();      // Confirmed → Shipped
order.deliver();   // Shipped → Delivered
```

---

### Pattern 11: Template Method Pattern

**Purpose:** Define algorithm skeleton, let subclasses fill details

**When to Use:**
- Multiple classes have similar algorithm structure
- Want to avoid code duplication
- Some steps are common, others vary by subclass
- Want to prevent subclasses from overriding common steps

**When NOT to Use:**
- Algorithm is rarely reused
- Hierarchy would become complex

**Implementation:**

```java
// ✅ Template Method for data processing pipeline
public abstract class DataProcessor {
    // Template method: defines algorithm skeleton
    public final void process(String inputFile) {
        String data = readFile(inputFile);
        String processed = processData(data);
        String validated = validateData(processed);
        writeOutput(validated);
    }
    
    // Common step: same for all subclasses
    protected String readFile(String filename) {
        System.out.println("Reading file: " + filename);
        return "file contents";
    }
    
    // Common step: same for all subclasses
    protected void writeOutput(String data) {
        System.out.println("Writing output");
    }
    
    // Variable steps: subclasses override these
    protected abstract String processData(String data);
    protected abstract String validateData(String data);
}

public class CSVProcessor extends DataProcessor {
    protected String processData(String data) {
        return data.replaceAll(",", "|");  // CSV to pipe-delimited
    }
    
    protected String validateData(String data) {
        // CSV-specific validation
        return data;
    }
}

public class JSONProcessor extends DataProcessor {
    protected String processData(String data) {
        // Parse and format as JSON
        return "{}";
    }
    
    protected String validateData(String data) {
        // JSON-specific validation
        return data;
    }
}

// Usage: Algorithm structure is clear and enforced
DataProcessor processor = new CSVProcessor();
processor.process("data.csv");
```

---

### Pattern 12: Command Pattern

**Purpose:** Encapsulate requests as objects

**When to Use:**
- Need to parameterize objects with operations
- Queue operations for later execution
- Support undo/redo
- Log operations
- Schedule deferred execution

**When NOT to Use:**
- Simple function calls sufficient
- No need for operation history

**Implementation:**

```java
// ✅ Command pattern for undo/redo
public interface ICommand {
    void execute();
    void undo();
}

public class BankAccount {
    private int balance = 0;
    
    public void deposit(int amount) {
        balance += amount;
        System.out.println("Deposited: " + amount + ", Balance: " + balance);
    }
    
    public void withdraw(int amount) {
        balance -= amount;
        System.out.println("Withdrew: " + amount + ", Balance: " + balance);
    }
    
    public int getBalance() { return balance; }
}

public class DepositCommand implements ICommand {
    private BankAccount account;
    private int amount;
    
    public DepositCommand(BankAccount account, int amount) {
        this.account = account;
        this.amount = amount;
    }
    
    public void execute() {
        account.deposit(amount);
    }
    
    public void undo() {
        account.withdraw(amount);
    }
}

public class WithdrawCommand implements ICommand {
    private BankAccount account;
    private int amount;
    
    public WithdrawCommand(BankAccount account, int amount) {
        this.account = account;
        this.amount = amount;
    }
    
    public void execute() {
        account.withdraw(amount);
    }
    
    public void undo() {
        account.deposit(amount);
    }
}

public class TransactionHistory {
    private List<ICommand> history = new ArrayList<>();
    
    public void execute(ICommand command) {
        command.execute();
        history.add(command);
    }
    
    public void undo() {
        if (!history.isEmpty()) {
            ICommand last = history.remove(history.size() - 1);
            last.undo();
        }
    }
}

// Usage: Full undo/redo support
var account = new BankAccount();
var history = new TransactionHistory();

history.execute(new DepositCommand(account, 100));   // Balance: 100
history.execute(new DepositCommand(account, 50));    // Balance: 150
history.execute(new WithdrawCommand(account, 30));   // Balance: 120

history.undo();  // Balance: 150
history.undo();  // Balance: 100
```

---

### Pattern 13: Chain of Responsibility Pattern

**Purpose:** Pass requests through chain of handlers until one processes it

**When to Use:**
- Multiple objects might handle a request
- Handler isn't known in advance
- Want to issue request without specifying receiver
- Logging, validation chains
- Event handling hierarchies

**When NOT to Use:**
- Guaranteed single handler (use simple dispatch)
- Performance critical (chain adds overhead)

**Implementation:**

```java
// ✅ Chain of Responsibility for request handling
public abstract class RequestHandler {
    protected RequestHandler nextHandler;
    
    public void setNextHandler(RequestHandler next) {
        this.nextHandler = next;
    }
    
    public final void handle(Request request) {
        if (canHandle(request)) {
            process(request);
        } else if (nextHandler != null) {
            nextHandler.handle(request);
        } else {
            System.out.println("No handler found for request: " + request.getType());
        }
    }
    
    protected abstract boolean canHandle(Request request);
    protected abstract void process(Request request);
}

public class AuthenticationHandler extends RequestHandler {
    protected boolean canHandle(Request request) {
        return request.getType() == RequestType.AUTHENTICATION;
    }
    
    protected void process(Request request) {
        System.out.println("Authenticating user...");
    }
}

public class AuthorizationHandler extends RequestHandler {
    protected boolean canHandle(Request request) {
        return request.getType() == RequestType.AUTHORIZATION;
    }
    
    protected void process(Request request) {
        System.out.println("Checking authorization...");
    }
}

public class BusinessLogicHandler extends RequestHandler {
    protected boolean canHandle(Request request) {
        return request.getType() == RequestType.BUSINESS;
    }
    
    protected void process(Request request) {
        System.out.println("Processing business logic...");
    }
}

// Setup chain
var auth = new AuthenticationHandler();
var authz = new AuthorizationHandler();
var business = new BusinessLogicHandler();

auth.setNextHandler(authz);
authz.setNextHandler(business);

// Usage: Request flows through chain
auth.handle(new Request(RequestType.BUSINESS));
```

---

## Anti-Patterns: When NOT to Use Patterns

### Anti-Pattern 1: Over-Engineering

```java
// ❌ AVOID: Using design patterns for trivial problems
public class SimpleCalculatorFactory {
    public static ICalculator create(CalculatorType type) {
        if (type == BASIC) return new BasicCalculator();
        throw new Exception();
    }
}

// ✅ INSTEAD: Just use the class directly
var calculator = new BasicCalculator();
```

### Anti-Pattern 2: Pattern Proliferation

```java
// ❌ AVOID: Too many patterns in single system
Factory → Builder → Decorator → Proxy → Strategy → Observer → State
// Results in: Over-complexity, hard to maintain

// ✅ INSTEAD: Use patterns where they solve real problems
```

### Anti-Pattern 3: Forcing Patterns

```java
// ❌ AVOID: Patterns that don't fit
public class SingletonList {
    private static List<String> items = new ArrayList<>();
    // Lists shouldn't be singletons!
}

// ✅ INSTEAD: Choose patterns based on requirements
```

---

## Pattern Selection Decision Tree

```
Is object creation complex?
├─ YES → Use Factory / Builder
└─ NO → Direct instantiation

Need to add behavior dynamically?
├─ YES → Use Decorator / Proxy
└─ NO → Direct composition

Need to decouple from implementations?
├─ YES → Use Strategy / Observer
└─ NO → Direct dependencies

Need to manage state transitions?
├─ YES → Use State / Chain of Responsibility
└─ NO → Direct logic

Need to simplify complex subsystem?
├─ YES → Use Facade / Adapter
└─ NO → Direct access
```

---

## Pattern Combination Examples

### Example 1: Spring Boot Dependency Injection

Combines: **Factory** + **Dependency Injection** + **Singleton**

```java
@Configuration
public class AppConfig {
    @Bean
    public IUserRepository userRepository() {  // Factory
        return new MySQLUserRepository();
    }
    
    @Bean
    public UserService userService(IUserRepository repo) {  // DI
        return new UserService(repo);  // Single instance (Singleton)
    }
}
```

### Example 2: Payment Processing Pipeline

Combines: **Strategy** + **Chain of Responsibility** + **Decorator**

```java
// Strategy: Select algorithm
IPaymentStrategy strategy = determinePaymentMethod(order);

// Chain: Validate → Process → Confirm
validator.validate(order);
processor.process(strategy, order);
confirmation.confirm(order);

// Decorator: Add logging/security
PaymentStrategy logged = new LoggingDecorator(strategy);
PaymentStrategy secured = new SecurityDecorator(logged);
```

---

## Quick Reference Table

| Pattern | Purpose | Complexity | Frequency |
|---------|---------|-----------|-----------|
| Factory | Abstract creation | Medium | Very Common |
| Builder | Complex construction | Medium | Common |
| Singleton | Single instance | Low | Common (use sparingly) |
| Adapter | Interface compatibility | Low | Common |
| Decorator | Add behavior dynamically | Medium | Common |
| Facade | Simplify complexity | Low | Common |
| Proxy | Control access | Medium | Moderate |
| Strategy | Runtime algorithm selection | Low | Very Common |
| Observer | Event notification | Medium | Very Common |
| State | State-dependent behavior | Medium | Moderate |
| Template Method | Algorithm skeleton | Low | Moderate |
| Command | Encapsulate requests | Medium | Moderate |
| Chain | Handler chain | Medium | Moderate |

---

## Conclusion

Design patterns are powerful tools for solving recurring architectural problems. Use them wisely:

✅ **When** patterns solve real problems  
❌ **Don't** force patterns into simple situations  
🎯 **Combine** patterns for complex systems  
📚 **Learn** each pattern's trade-offs deeply  
⚖️ **Balance** pattern usage with code simplicity
