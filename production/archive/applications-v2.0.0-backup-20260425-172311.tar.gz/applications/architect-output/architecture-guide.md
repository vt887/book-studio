# Architecture Guide: Object-Oriented Design Patterns & Principles

**Source:** Object-Oriented Thinking by Vaysfeld  
**Generated:** 2026-04-25  
**Role:** Architect  
**Total Concepts:** 12 core architectural concepts

---

## Executive Summary

This guide synthesizes 12 key architectural principles from Object-Oriented Thinking, providing architects with decision frameworks, trade-offs, and implementation strategies for building maintainable, scalable systems.

### Key Architectural Principles

1. **Abstraction** — Hide complexity behind clear interfaces
2. **Composition over Inheritance** — Favor flexible has-a over rigid is-a hierarchies
3. **Design Patterns** — Proven solutions to recurring architectural problems
4. **Encapsulation** — Control access to hide implementation details
5. **Inheritance Mechanisms** — Reuse behavior through class hierarchies (use cautiously)
6. **Polymorphism** — Enable flexible runtime behavior through common interfaces
7. **Class Hierarchies** — Design shallow, meaningful inheritance relationships
8. **SOLID Principles** — Foundation for maintainable, testable architecture
9. **Separation of Concerns** — Partition system into distinct, independent modules
10. **Interface Contracts** — Define clear behavioral boundaries
11. **Object Model Design** — Map domain concepts to objects and relationships
12. **Refactoring Strategies** — Continuously improve architecture without breaking functionality

### Critical Trade-offs

| Principle | Benefit | Cost | When to Use |
|-----------|---------|------|-----------|
| **Abstraction** | Reduces cognitive load, enables testing | May introduce unnecessary complexity | When hiding real complexity, not artificial layering |
| **Composition** | Flexibility, no fragile base class problem | More wiring, delegating code | For flexible, evolving systems |
| **Inheritance** | Code reuse, polymorphic hierarchies | Tight coupling, limited flexibility | Only for true is-a relationships |
| **Interfaces** | Loose coupling, testability | More types to maintain | For plugin architectures, external dependencies |
| **SOLID** | Long-term maintainability, team alignment | Initial design overhead | Essential for team codebases |
| **Encapsulation** | Correctness guarantees, information hiding | Performance overhead (getters/setters) | Always—it's free in well-designed systems |
| **Separation** | Testability, parallelization, deployment | More services to coordinate | For independent concerns |

---

## Architecture Decision Framework

### Question 1: Complexity Management
**Q:** How much complexity needs to be hidden from consumers?  
**A:** Use **Abstraction** and **Interfaces**. Define clear contracts that expose only what's necessary.

### Question 2: Code Reuse Strategy
**Q:** Should we reuse code through inheritance or composition?  
**A:** Prefer **Composition over Inheritance**. Inheritance creates fragile hierarchies; composition is more flexible.

**When inheritance is acceptable:**
- True is-a relationships (e.g., `Manager is-a Employee`)
- Shallow hierarchies (≤2 levels deep)
- Clear liskov substitution principle compliance

### Question 3: Extensibility Requirements
**Q:** Must the system support new behavior without modification?  
**A:** Use **Design Patterns** (Strategy, Factory, Observer, etc.) + **Interfaces** to build plugin architectures.

### Question 4: Boundary Definition
**Q:** Where should we draw service/module boundaries?  
**A:** Apply **Separation of Concerns**: Each module should handle one reason to change.

### Question 5: Object Structure
**Q:** What real-world concepts should become objects?  
**A:** Use **Object Model Design**: Domain-driven design, ubiquitous language, value objects.

---

## Architectural Anti-Patterns to Avoid

### 🚫 Anti-Pattern 1: The God Class
**Problem:** Single class responsible for too many concerns  
**Solution:** Apply **Single Responsibility Principle** (from SOLID)
```
BEFORE: UserService (auth, email, logging, persistence, validation)
AFTER:  UserService (orchestration)
        + AuthService (authentication)
        + EmailService (notifications)
        + UserRepository (persistence)
        + UserValidator (validation)
```

### 🚫 Anti-Pattern 2: Deep Inheritance Hierarchies
**Problem:** 3+ levels of inheritance lead to fragility
```
BEFORE: Animal → Mammal → Dog → PoliceDog
AFTER:  Dog (Breed enum) + Role (PoliceDog is-a Role)
```

### 🚫 Anti-Pattern 3: Tight Coupling to Concrete Classes
**Problem:** Direct dependencies on implementations, not abstractions
```
BEFORE: PaymentProcessor depends on PayPalGateway
AFTER:  PaymentProcessor depends on IPaymentGateway interface
```

### 🚫 Anti-Pattern 4: Missing Encapsulation
**Problem:** Direct access to internal state breaks invariants
```
BEFORE: account.balance = -1000  // Bug!
AFTER:  account.deposit(1000) // Validated
```

### 🚫 Anti-Pattern 5: Circular Dependencies
**Problem:** Module A depends on B, B depends on A
```
BEFORE: OrderService ↔ PaymentService
AFTER:  OrderService → IPaymentService (OrderService → IEventBus ← PaymentService)
```

---

## Layered Architecture Pattern

Based on OOP principles, here's a recommended system structure:

```
┌─────────────────────────────────────┐
│      Presentation Layer             │
│  (Controllers, Views, DTOs)         │
├─────────────────────────────────────┤
│      Application Layer              │
│  (Orchestration, Use Cases)         │
├─────────────────────────────────────┤
│      Domain Layer                   │
│  (Business Logic, Domain Objects)   │
├─────────────────────────────────────┤
│      Infrastructure Layer           │
│  (Database, External APIs, Config)  │
└─────────────────────────────────────┘
```

### Layer Responsibilities

**Presentation:** Request/response handling, validation, formatting
- Use **Encapsulation** to hide domain details from UI
- Implement **Separation of Concerns** between UI and logic

**Application:** Orchestration, transaction management, security
- Use **SOLID** principles for use case handlers
- Apply **Interfaces** for plugin architectures

**Domain:** Business rules, state management, transactions
- Build meaningful **Object Models** reflecting business concepts
- Enforce **Encapsulation** and invariants rigorously

**Infrastructure:** Technical concerns, external systems
- Use **Abstraction** via interfaces to isolate domain from technology
- Implement **Repository Pattern** for data access

---

## Design Pattern Quick Reference

### Creational Patterns
- **Factory:** Abstract object creation for flexibility
- **Builder:** Complex object construction in steps
- **Singleton:** Single shared instance (use sparingly)

### Structural Patterns
- **Adapter:** Bridge incompatible interfaces
- **Decorator:** Add behavior to objects dynamically
- **Facade:** Simplify complex subsystem access
- **Proxy:** Control access to objects

### Behavioral Patterns
- **Strategy:** Encapsulate algorithms for runtime selection
- **Observer:** Decouple event sources from listeners
- **State:** Encapsulate state-dependent behavior
- **Template Method:** Define algorithm skeleton, let subclasses fill details

---

## Architecture Review Checklist

### Before Building
- [ ] Have we modeled the domain with clear objects and relationships?
- [ ] Are service boundaries aligned with Separation of Concerns?
- [ ] Do we have clear abstraction layers between technology and business logic?
- [ ] Are external dependencies (APIs, databases) behind interfaces?

### During Design Review
- [ ] Is each class/service responsible for one reason to change? (SRP)
- [ ] Are we using composition over inheritance?
- [ ] Are there circular dependencies?
- [ ] Are invariants documented and enforced via Encapsulation?
- [ ] Can we test each component in isolation?

### Before Deployment
- [ ] Have we applied the Open/Closed Principle (open for extension, closed for modification)?
- [ ] Are we inverting dependencies on abstractions, not implementations?
- [ ] Is error handling consistent and secure?
- [ ] Can we extend with new behavior without modifying existing code?

---

## Refactoring Path for Legacy Systems

### Phase 1: Identify God Classes
Extract from monolithic classes using **Separation of Concerns**:
- Logging → LogService
- Validation → ValidatorService
- Persistence → Repository
- Email → NotificationService

### Phase 2: Introduce Interfaces
Replace concrete dependencies with **Interfaces**:
```java
// BEFORE: PaymentProcessor depends on PayPalGateway
private PayPalGateway gateway;

// AFTER: PaymentProcessor depends on abstraction
private IPaymentGateway gateway;  // Can be PayPal, Stripe, Square, etc.
```

### Phase 3: Break Inheritance Hierarchies
Use **Composition over Inheritance**:
```java
// BEFORE: Rectangle extends Shape, Circle extends Shape, Square extends Rectangle
// AFTER:  All shapes have-a ShapeProperties, implement IShape interface
```

### Phase 4: Enforce Encapsulation
Make internal state private, provide validated accessors:
```java
// BEFORE: public Account { public int balance; }
// AFTER:  public Account {
//           private int balance;
//           public void deposit(int amount) { ... validate ... }
//         }
```

---

## Risk Register

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|-----------|
| **Premature abstraction** | High | Medium | Only abstract when you have 3+ usages or clear extension points |
| **Over-engineered design** | High | High | Follow YAGNI (You Aren't Gonna Need It) principle |
| **Tight coupling to frameworks** | Medium | High | Use interfaces to abstract away framework dependencies |
| **Cyclic dependencies** | Medium | High | Design dependency graphs, use dependency inversion |
| **God classes emerge** | High | Medium | Monitor class size, apply SRP during reviews |
| **Inheritance hell** | Medium | High | Prefer composition, limit inheritance to 2 levels max |
| **Missing encapsulation** | Low | High | Code reviews, automated invariant checking |
| **Testability issues** | Medium | High | Design for testability from the start, use interfaces |

---

## Next Steps

1. **Read ADRs** (adr-decisions.md) — 12 Architectural Decision Records with context and consequences
2. **Review Patterns** (design-patterns.md) — Detailed design pattern implementation guide
3. **Design Framework** (system-design-framework.md) — Step-by-step approach to system design
4. **Run Checklist** (This document) — Use before/during/after architecture reviews

---

## References

- Vaysfeld - Object-Oriented Thinking (Concepts Foundation)
- SOLID Principles - Robert Martin
- Design Patterns - Gang of Four
- Clean Architecture - Robert Martin
- Domain-Driven Design - Eric Evans
