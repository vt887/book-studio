# Architecture Risk Register

**Source:** Object-Oriented Thinking by Vaysfeld  
**Purpose:** Identify and mitigate common architecture pitfalls  
**Date:** 2026-04-25

---

## Risk Assessment Matrix

```
Impact
  │
  │  HIGH    ┌────────────────────────────┐
  │          │  CRITICAL RISKS (Act Now) │
  │          └────────────────────────────┘
  │
  │  MEDIUM  ┌────────────────────────────┐
  │          │  MAJOR RISKS (Plan Soon)  │
  │          └────────────────────────────┘
  │
  │  LOW     ┌────────────────────────────┐
  │          │  MINOR RISKS (Monitor)    │
  │          └────────────────────────────┘
  │
  └─────────────────────────────────────────
    LOW    MEDIUM    HIGH
    Probability
```

---

## CRITICAL RISKS (High Probability × High Impact)

### Risk 1: God Class Syndrome

**Description:** Single class responsible for too many concerns

**Probability:** HIGH (Very common in growing systems)  
**Impact:** HIGH (Cascade failures, hard to test, hard to maintain)

**Example:**
```java
// ❌ GOD CLASS: 3000+ lines doing everything
public class UserService {
    public void createUser(String name, String email) { /* 50 lines */ }
    public void validateEmail(String email) { /* 30 lines */ }
    public void sendWelcomeEmail(User user) { /* 40 lines */ }
    public void persistToDatabase(User user) { /* 30 lines */ }
    public void sendSMSConfirmation(User user) { /* 30 lines */ }
    public void generateAuthToken(User user) { /* 40 lines */ }
    public void logActivity(String userId, String action) { /* 20 lines */ }
    public void calculateUserScore(User user) { /* 60 lines */ }
    public void generateReport(List<User> users) { /* 100 lines */ }
    // ... 50+ more methods
}
```

**Consequences:**
- ❌ Hard to test (50 dependencies needed)
- ❌ Slow to test (all methods run during tests)
- ❌ Hard to change (any change risks multiple parts)
- ❌ Hard to understand (requires learning 3000 lines)
- ❌ Impossible to reuse (can't take one piece)

**Mitigation Strategy:**

**Step 1: Identify concerns**
```
UserService concerns:
1. User creation/validation
2. Email notifications
3. SMS notifications
4. Authentication
5. Activity logging
6. Reporting
7. Persistence
```

**Step 2: Extract into separate classes**
```java
public class UserFactory {
    public User createUser(String name, String email) {
        validator.validateEmail(email);
        return new User(name, email);
    }
}

public class UserValidator {
    public void validateEmail(String email) { /* */ }
}

public class EmailNotificationService {
    public void sendWelcomeEmail(User user) { /* */ }
}

public class SMSNotificationService {
    public void sendConfirmation(User user) { /* */ }
}

public class AuthenticationService {
    public String generateAuthToken(User user) { /* */ }
}

public class ActivityLogger {
    public void log(String userId, String action) { /* */ }
}

public class UserReportGenerator {
    public Report generateReport(List<User> users) { /* */ }
}

public class UserRepository implements IUserRepository {
    public void save(User user) { /* */ }
}
```

**Step 3: Refactored orchestrator**
```java
public class UserService {
    private UserFactory factory;
    private UserValidator validator;
    private EmailNotificationService emailService;
    private UserRepository repository;
    
    public void createNewUser(String name, String email) {
        var user = factory.createUser(name, email);
        repository.save(user);
        emailService.sendWelcomeEmail(user);
    }
}
```

**Prevention:**
- [ ] Monitor class size during code reviews (max 300 LOC)
- [ ] Apply Single Responsibility Principle rigorously
- [ ] Extract classes every 100 lines
- [ ] Monitor cyclomatic complexity (max 10)

---

### Risk 2: Tight Coupling to Concrete Implementations

**Description:** High-level code depends on low-level concrete classes

**Probability:** HIGH (Natural when not paying attention)  
**Impact:** HIGH (Cascading changes, hard to test, hard to extend)

**Example:**
```java
// ❌ TIGHTLY COUPLED: PaymentProcessor depends on concrete classes
public class PaymentProcessor {
    private PayPalGateway paypal = new PayPalGateway("api_key");
    private MySQLOrderRepository db = new MySQLOrderRepository("connection_string");
    private SMTPEmailService email = new SMTPEmailService("smtp.gmail.com");
    
    public void processOrder(Order order) {
        paypal.charge(order.total);  // Direct dependency on PayPal
        db.save(order);               // Direct dependency on MySQL
        email.send(order.customer.email, "Order confirmed");  // Direct SMTP
    }
}

// Problem:
// - Want to add Stripe? Modify PaymentProcessor
// - Want to use MongoDB? Modify PaymentProcessor
// - Want to use different email service? Modify PaymentProcessor
// - Hard to test: Need real PayPal, MySQL, email service
```

**Consequences:**
- ❌ Can't test without real external systems
- ❌ Changes to PayPal, MySQL, or email require code changes
- ❌ Can't swap implementations
- ❌ Adds latency (real API calls during tests)
- ❌ Brittle (external system failure breaks tests)

**Mitigation Strategy:**

**Apply Dependency Inversion Principle:**
```java
// ✅ LOOSELY COUPLED: Depends on abstractions
public interface IPaymentGateway {
    PaymentResult charge(Money amount);
}

public interface IOrderRepository {
    void save(Order order);
}

public interface IEmailService {
    void send(String recipient, String message);
}

public class PaymentProcessor {
    private IPaymentGateway gateway;
    private IOrderRepository repository;
    private IEmailService emailService;
    
    public PaymentProcessor(IPaymentGateway gateway, 
                           IOrderRepository repo,
                           IEmailService email) {
        this.gateway = gateway;
        this.repository = repo;
        this.emailService = email;
    }
    
    public void processOrder(Order order) {
        gateway.charge(order.total);           // Abstraction
        repository.save(order);                // Abstraction
        emailService.send(order.customer.email, "Order confirmed");  // Abstraction
    }
}

// Now we can swap implementations without changing PaymentProcessor:
new PaymentProcessor(
    new PayPalGateway(),        // or StripeGateway, SquareGateway
    new MySQLOrderRepository(), // or MongoOrderRepository
    new SMTPEmailService()      // or SendGridEmailService
);

// For testing: use mocks
new PaymentProcessor(
    new MockPaymentGateway(),   // No real API calls
    new InMemoryOrderRepository(), // No database
    new MockEmailService()      // No emails
);
```

**Prevention:**
- [ ] Identify external dependencies early
- [ ] Create interfaces for external systems
- [ ] Use constructor injection (not `new` in methods)
- [ ] Code review: scan for `new` outside factories

---

### Risk 3: Deep Inheritance Hierarchies

**Description:** 3+ levels of inheritance create fragile, hard-to-understand structures

**Probability:** HIGH (Common mistake)  
**Impact:** HIGH (Cascading changes, Liskov violations, brittle)

**Example:**
```java
// ❌ TOO DEEP: 4 levels
public abstract class Animal { }
public abstract class Mammal extends Animal { }
public abstract class Carnivore extends Mammal { }
public class Lion extends Carnivore { }

// Problems when adding "Bird":
public class Bird extends Animal { }  // Can't reuse Mammal features
public class Eagle extends Bird { }   // Doesn't fit hierarchy

// Changing Mammal affects Lion, Tiger, Elephant, Human, etc.
// Hard to understand what's inherited from where
```

**Consequences:**
- ❌ Hard to understand (need to trace through 3+ classes)
- ❌ Fragile (changes to parent break children)
- ❌ Violates Liskov Substitution Principle
- ❌ Can't model multiple characteristics
- ❌ Painful to refactor

**Mitigation Strategy:**

**Apply Composition Over Inheritance:**
```java
// ✅ FLAT with composition: 2 levels max
public interface IAnimal {
    void move();
    void eat();
}

public class Mammal implements IAnimal {
    private WarmBloodedBehavior temperature;  // Has-a
    private FurTexture fur;                    // Has-a
    private ReproductiveSystem reproduction;  // Has-a
    
    public void move() { /* Mammal movement */ }
    public void eat() { /* Mammal diet */ }
}

public class Bird implements IAnimal {
    private WarmBloodedBehavior temperature;  // Has-a
    private FeatherTexture feathers;          // Has-a
    private WingBehavior wings;               // Has-a
    
    public void move() { /* Bird movement */ }
    public void eat() { /* Bird diet */ }
}

// Each type has only features it needs
// Easy to add new characteristics
// Easy to model different behavior combinations
```

**Prevention:**
- [ ] Limit inheritance depth to 2 levels
- [ ] Question every inheritance: "Is this truly is-a?"
- [ ] Code review: flag 3+ level hierarchies
- [ ] Prefer composition for behavior sharing

---

## MAJOR RISKS (High Probability × Medium Impact)

### Risk 4: Missing Encapsulation

**Description:** Public access to internal state allows invariant violations

**Example:**
```java
// ❌ NO ENCAPSULATION: Direct access to state
public class BankAccount {
    public int balance = 0;
    public String accountNumber = "";
}

var account = new BankAccount();
account.balance = -1000;  // BUG: Invalid state!
account.accountNumber = null;  // BUG: Invalid state!

// ✅ ENCAPSULATED: Validation enforced
public class BankAccount {
    private int balance;
    private String accountNumber;
    
    public BankAccount(String accountNumber, int initialBalance) {
        setBalance(initialBalance);
        setAccountNumber(accountNumber);
    }
    
    public void setBalance(int balance) {
        if (balance < 0) throw new IllegalArgumentException();
        this.balance = balance;
    }
    
    public void setAccountNumber(String accountNumber) {
        if (accountNumber == null || accountNumber.isEmpty()) {
            throw new IllegalArgumentException();
        }
        this.accountNumber = accountNumber;
    }
}
```

**Mitigation:**
- [ ] Make all mutable fields private
- [ ] Provide validated accessors (getters/setters)
- [ ] Validate in constructor
- [ ] Code review: scan for `public` fields

---

### Risk 5: Circular Dependencies

**Description:** Module A depends on B, B depends on A (breaks modular design)

**Example:**
```java
// ❌ CIRCULAR: OrderService ↔ PaymentService
public class OrderService {
    private PaymentService payment;  // depends on PaymentService
    
    public void processOrder(Order order) {
        payment.charge(order.total);
    }
}

public class PaymentService {
    private OrderService orders;  // depends on OrderService
    
    public void charge(Money amount) {
        Order order = orders.getLastOrder();  // Circular!
    }
}

// ✅ FIXED: Invert dependency
public interface IEventBus {
    void publish(Event event);
}

public class OrderService {
    private IEventBus eventBus;
    
    public void processOrder(Order order) {
        eventBus.publish(new PaymentRequiredEvent(order));
    }
}

public class PaymentService {
    private IEventBus eventBus;
    
    public PaymentService(IEventBus eventBus) {
        this.eventBus = eventBus;
        eventBus.subscribe(PaymentRequiredEvent.class, this::onPaymentRequired);
    }
    
    private void onPaymentRequired(PaymentRequiredEvent event) {
        charge(event.getAmount());
    }
}
```

**Mitigation:**
- [ ] Use dependency analysis tools
- [ ] Design dependency graph explicitly
- [ ] Use event-driven architecture for decoupling
- [ ] Refactor: extract shared dependency

---

### Risk 6: Insufficient Encapsulation (Too Many Public Methods)

**Description:** Exposing too many implementation details violates information hiding

**Example:**
```java
// ❌ TOO PUBLIC: Exposes internals
public class User {
    public String getName() { }
    public void setName(String name) { }
    public String getPassword() { }
    public void setPassword(String password) { }
    public List<String> getPermissions() { }
    public void addPermission(String perm) { }
    public void removePermission(String perm) { }
    public Date getLastLogin() { }
    public void setLastLogin(Date date) { }
    public void validatePassword(String pwd) { }
    public void hashPassword(String pwd) { }
    public void logActivity(String action) { }
    // ... 30 more public methods
}

// ✅ BETTER: Hide implementation, expose behavior
public class User {
    private String name;
    private String passwordHash;
    private Permissions permissions;
    
    public void authenticate(String password) {
        if (!validatePassword(password)) {
            throw new AuthenticationFailedException();
        }
        recordLogin();
    }
    
    public boolean canAccess(String resource) {
        return permissions.allows(resource);
    }
    
    public void grantPermission(String resource) {
        permissions.grant(resource);
    }
    
    // Private implementation details hidden
    private boolean validatePassword(String password) { }
    private void recordLogin() { }
}
```

**Mitigation:**
- [ ] Expose behavior, not state
- [ ] Hide implementation details
- [ ] Code review: audit public methods for necessity

---

## MINOR RISKS (Medium-Low Probability, Lower Impact)

### Risk 7: Over-Abstraction

**Description:** Creating abstractions where they're not needed

**Example:**
```java
// ❌ OVER-ENGINEERED: Abstraction overkill
public interface ISimpleCalculator {
    int add(int a, int b);
}

public class SimpleCalculator implements ISimpleCalculator {
    public int add(int a, int b) {
        return a + b;
    }
}

// ✅ SIMPLER: Direct use
public class SimpleCalculator {
    public int add(int a, int b) {
        return a + b;
    }
}
```

**Rule of 3:** Only abstract when you have 3+ usages or one future-extension need.

**Mitigation:**
- [ ] Don't abstract until necessary
- [ ] Ask: "Would I need 2 implementations?"
- [ ] Prefer YAGNI (You Aren't Gonna Need It)

---

### Risk 8: Premature Optimization

**Description:** Optimizing before measuring, causing complex code

**Example:**
```java
// ❌ PREMATURE: Complex optimization without measurements
public class CachedUserService {
    private Map<String, CachedUser> cache;
    private LRUEvictionPolicy eviction;
    private ReentrantReadWriteLock lock;
    private ExecutorService executor;
    // 200 lines of caching logic
}

// ✅ MEASURED: Optimize after profiling shows need
public class UserService {
    private IUserRepository repository;
    
    public User getUser(String id) {
        return repository.findById(id);
    }
}

// If profiling shows 70% of time in findById:
// Then add caching with measurement
```

**Mitigation:**
- [ ] Profile before optimizing
- [ ] Optimize only where measurements show need
- [ ] Keep it simple until proven necessary

---

## Risk Monitoring Dashboard

| Risk | Probability | Impact | Mitigation Status | Monitoring |
|------|-------------|--------|-------------------|-----------|
| God Class | HIGH | HIGH | Extract into services | Monitor class size (< 300 LOC) |
| Tight Coupling | HIGH | HIGH | Use DIP + interfaces | Code review checklist |
| Deep Inheritance | HIGH | HIGH | Composition + 2-level limit | Static analysis |
| Missing Encapsulation | MEDIUM | HIGH | Private fields + validation | Code review |
| Circular Dependencies | MEDIUM | HIGH | Event-driven architecture | Dependency graph analysis |
| Too Public | MEDIUM | MEDIUM | Hide implementation | API surface review |
| Over-Abstraction | MEDIUM | LOW | Rule of 3 | Design review |
| Premature Optimization | MEDIUM | MEDIUM | Profile first | Performance reviews |

---

## Risk Response Plan

### When Risk Identified

1. **Assess Severity**
   - How many places affected?
   - How hard is refactoring?
   - What's the business impact?

2. **Plan Refactoring**
   - Break into small tasks
   - Estimate effort
   - Prioritize by severity

3. **Execute Safely**
   - Write tests first
   - Make incremental changes
   - Get code review
   - Merge to main branch

4. **Monitor Resolution**
   - Verify tests pass
   - Measure improvement
   - Update monitoring

---

## Architecture Health Checklist

Review quarterly:

**Design Quality:**
- [ ] No class > 300 LOC
- [ ] All mutable state private
- [ ] Inheritance depth ≤ 2
- [ ] No circular dependencies
- [ ] High cohesion, low coupling

**Test Coverage:**
- [ ] > 80% code coverage
- [ ] All public APIs tested
- [ ] Edge cases covered
- [ ] Integration tests for boundaries

**Documentation:**
- [ ] Architecture decisions recorded (ADRs)
- [ ] Data flow diagrams current
- [ ] Interfaces documented
- [ ] Onboarding guide maintained

**Process:**
- [ ] Code reviews happening (< 4 hours turnaround)
- [ ] Technical debt tracked
- [ ] Refactoring time budgeted (10-20% of sprint)
- [ ] Architecture reviews scheduled

---

## Escalation Path

**For identified risks:**

1. **GREEN (Low):** Monitor in quarterly review
2. **YELLOW (Medium):** Plan refactoring in next sprint
3. **RED (High):** Stop feature work, refactor immediately
4. **CRITICAL:** Escalate to tech lead, may require rewrite

---

## References

- ADR-002: Composition Over Inheritance
- ADR-003: Design Patterns
- ADR-004: Encapsulation
- ADR-006: Separation of Concerns
- ADR-012: Dependency Inversion
- System Design Framework: Phase 5 (Implementation Strategy)
