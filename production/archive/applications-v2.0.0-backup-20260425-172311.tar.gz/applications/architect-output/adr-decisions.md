# Architectural Decision Records (ADRs)

**Source:** Object-Oriented Thinking by Vaysfeld  
**Format:** RFC 3986 ADR  
**Total ADRs:** 12

---

## ADR-001: Abstraction as Primary Design Tool

**Status:** ACCEPTED  
**Date:** 2026-04-25

### Context

Modern systems must balance **hiding implementation complexity** with **exposing necessary interfaces**. Without clear abstraction, consumers depend on internal details, making systems brittle and difficult to change.

In OOP, abstraction is the cornerstone—defining what clients need to know vs. what's internal.

### Decision

We will use **Abstraction** as the primary architectural tool for:
1. Hiding technical complexity (databases, APIs, frameworks)
2. Defining system boundaries
3. Creating plugin points for extensions
4. Reducing cognitive load on consumers

### Rationale

Abstraction enables:
- **Testability**: Mock abstractions instead of real implementations
- **Maintainability**: Change internals without affecting consumers
- **Flexibility**: Swap implementations without changing contracts
- **Team collaboration**: Clear contracts reduce coordination overhead

### Consequences

**Positive:**
- ✅ Consumers depend on stable abstractions, not volatile implementations
- ✅ New implementations can be added without changing existing code
- ✅ Easier to test in isolation via mocking
- ✅ Clear boundaries reduce cognitive load

**Negative:**
- ❌ May introduce unnecessary layers if over-applied
- ❌ Indirection makes code harder to trace (tools help)
- ❌ Performance overhead from virtual dispatch (usually negligible)

### Implementation Examples

**Example 1: Abstracting Database Access**
```java
// ❌ Without abstraction: tightly coupled to SQL
public class UserService {
    public User getUser(int id) {
        return new SqlConnection()
            .query("SELECT * FROM users WHERE id = ?", id)
            .toUser();
    }
}

// ✅ With abstraction: decoupled from storage
public interface IUserRepository {
    User getById(int id);
}

public class UserService {
    private IUserRepository repository;
    public UserService(IUserRepository repo) { this.repository = repo; }
    
    public User getUser(int id) {
        return repository.getById(id);
    }
}

// Multiple implementations: SQL, MongoDB, In-Memory for testing
```

**Example 2: Abstracting External APIs**
```java
// ❌ Without abstraction: tightly coupled to PayPal
public class PaymentProcessor {
    private PayPalAPI paypalAPI;
    
    public void processPayment(Order order) {
        paypalAPI.charge(order.amount);
    }
}

// ✅ With abstraction: can support any payment provider
public interface IPaymentGateway {
    TransactionResult charge(Money amount);
}

public class PaymentProcessor {
    private IPaymentGateway gateway;  // PayPal, Stripe, Square, etc.
    
    public void processPayment(Order order) {
        gateway.charge(order.amount);
    }
}
```

### When NOT to Abstract

❌ **Premature abstraction:** Don't abstract until you have 3+ usages or a clear extension point  
❌ **Artificial abstraction:** Don't add layers that don't hide real complexity

### Review Questions

- [ ] Is this abstraction hiding real complexity?
- [ ] Do consumers depend on stable interface or volatile implementation?
- [ ] Can we test with 2+ implementations (real + mock)?

---

## ADR-002: Composition Over Inheritance

**Status:** ACCEPTED  
**Date:** 2026-04-25

### Context

Inheritance creates **is-a** relationships; composition creates **has-a** relationships. Inheritance hierarchies are rigid—changing parent classes affects all children. Composition is flexible—we can change component implementations independently.

### Decision

We will **prefer composition over inheritance** as the default strategy for code reuse. Inheritance is used only for true **is-a** relationships in shallow hierarchies (≤2 levels).

### Rationale

Composition addresses fundamental inheritance problems:
- **Fragile Base Class Problem:** Changing base class breaks subclasses
- **Rigid hierarchies:** Hard to model multiple characteristics
- **Limited reuse:** Can't easily mix behaviors
- **Liskov Substitution Principle violations:** Subclasses often violate base contracts

### Consequences

**Positive:**
- ✅ No fragile base class problem
- ✅ Easy to swap implementations (DIP)
- ✅ Flexible behavior combination
- ✅ Each class focused on one concern

**Negative:**
- ❌ More classes to maintain
- ❌ More wiring (though frameworks help)
- ❌ Requires discipline to avoid delegation hell

### Implementation Examples

**Example 1: Employee Hierarchy Anti-Pattern**
```java
// ❌ BEFORE: Brittle inheritance hierarchy
abstract class Employee {
    protected String name;
    protected int salary;
    public abstract void calculateBonus();  // Subclasses forced to implement
}

class Manager extends Employee {
    public void calculateBonus() { return salary * 0.2; }
}

class Developer extends Employee {
    public void calculateBonus() { return salary * 0.1; }
}

class Intern extends Employee {
    // Inherits from Employee but interns have no bonus?
    // Forced to override even though no bonus
}

// ✅ AFTER: Flexible composition
public interface IBonusCalculator {
    int calculate(int salary);
}

public class ManagerBonusCalculator implements IBonusCalculator {
    public int calculate(int salary) { return salary * 0.2; }
}

public class DeveloperBonusCalculator implements IBonusCalculator {
    public int calculate(int salary) { return salary * 0.1; }
}

public class Employee {
    private String name;
    private int salary;
    private IBonusCalculator bonusCalculator;  // HAS-A
    
    public Employee(String name, int salary, IBonusCalculator calc) {
        this.name = name;
        this.salary = salary;
        this.bonusCalculator = calc;
    }
    
    public int getBonus() {
        return bonusCalculator.calculate(salary);
    }
}

// Usage: Flexible, no forced inheritance
var manager = new Employee("Alice", 100000, new ManagerBonusCalculator());
var developer = new Employee("Bob", 80000, new DeveloperBonusCalculator());
var intern = new Employee("Charlie", 20000, (s) -> 0);  // Lambda bonus calc
```

**Example 2: Bird Hierarchy Anti-Pattern**
```java
// ❌ BEFORE: Famous inheritance problem
class Bird {
    public void fly() { }
}

class Penguin extends Bird {  // Penguins don't fly!
    public void fly() {
        throw new UnsupportedOperationException("Penguins can't fly");
    }
}

// ✅ AFTER: Composition with proper interfaces
public interface IFlyer {
    void fly();
}

public interface ISwimmer {
    void swim();
}

public class Bird {
    private String species;
    private IFlyer flyer;
    private ISwimmer swimmer;
    
    // Different birds have different flying/swimming abilities
}

public class Eagle implements IFlyer, ISwimmer {
    public void fly() { System.out.println("Soaring"); }
    public void swim() { System.out.println("Fishing"); }
}

public class Penguin implements ISwimmer {
    public void swim() { System.out.println("Diving"); }
    // No IFlyer interface—penguin doesn't claim to fly
}
```

### When Inheritance Is Acceptable

✅ **True is-a relationships** (Manager IS-A Employee, not composition)  
✅ **Polymorphic type systems** (Exception hierarchy, Shape hierarchy)  
✅ **Framework requirements** (extending HttpServlet)  
✅ **Shallow hierarchies only** (≤2 levels deep)

### Inheritance Checklist

- [ ] Is this a true **is-a** relationship?
- [ ] Can child be substituted everywhere parent is used? (Liskov)
- [ ] Is hierarchy ≤2 levels deep?
- [ ] Would composition solve the same problem more flexibly?

---

## ADR-003: Design Patterns as Architectural Language

**Status:** ACCEPTED  
**Date:** 2026-04-25

### Context

Design patterns are **proven solutions to recurring problems**. They provide vocabulary for architects to communicate solutions across teams. Patterns embody SOLID principles and OOP best practices.

### Decision

We will use **Design Patterns** as the primary architectural vocabulary. Key patterns include:
- **Creational:** Factory, Builder, Singleton
- **Structural:** Adapter, Decorator, Facade, Proxy
- **Behavioral:** Strategy, Observer, State, Template Method, Command

### Rationale

Design patterns:
- Solve problems that have been solved thousands of times
- Communicate architecture across teams efficiently
- Encapsulate complex interactions in recognizable structures
- Reduce reinvention and bikeshedding

### Consequences

**Positive:**
- ✅ Team quickly recognizes architecture
- ✅ New developers onboard faster
- ✅ Reduces design meetings ("Use Strategy Pattern")
- ✅ Battle-tested solutions

**Negative:**
- ❌ Not every pattern fits every situation
- ❌ Over-application ("Everything is a Factory")
- ❌ Patterns can add complexity if misused

### Key Patterns by Use Case

| Use Case | Pattern | Example |
|----------|---------|---------|
| Runtime algorithm selection | **Strategy** | Multiple sorting algorithms, payment providers |
| Event handling | **Observer** | Pub-sub, event listeners |
| Complex object creation | **Builder** | Request object with many optional fields |
| Incompatible interfaces | **Adapter** | Legacy system integration |
| Subsystem simplification | **Facade** | Complex payment system behind simple API |
| Deferred creation | **Factory** | DataSource factory for different databases |
| Resource cleanup | **Proxy** | Lazy initialization, resource management |
| State-dependent behavior | **State** | Order lifecycle (New → Confirmed → Shipped → Delivered) |
| Algorithm skeleton | **Template Method** | Common algorithm with customizable steps |

### Example: Strategy Pattern for Payment Processing

```java
// Strategy interface: contract for payment processors
public interface IPaymentStrategy {
    TransactionResult process(Payment payment);
    boolean supports(PaymentMethod method);
}

// Multiple concrete strategies
public class CreditCardStrategy implements IPaymentStrategy {
    public TransactionResult process(Payment p) {
        // Credit card specific logic
    }
    public boolean supports(PaymentMethod m) {
        return m == PaymentMethod.CREDIT_CARD;
    }
}

public class CryptoStrategy implements IPaymentStrategy {
    public TransactionResult process(Payment p) {
        // Blockchain logic
    }
    public boolean supports(PaymentMethod m) {
        return m == PaymentMethod.CRYPTOCURRENCY;
    }
}

// Context: uses strategies polymorphically
public class PaymentProcessor {
    private List<IPaymentStrategy> strategies;
    
    public TransactionResult process(Payment payment) {
        IPaymentStrategy strategy = strategies.stream()
            .filter(s -> s.supports(payment.method))
            .findFirst()
            .orElseThrow(() -> new UnsupportedMethodException());
        return strategy.process(payment);
    }
}

// Easy to extend: just add new strategy, no processor changes
```

### Anti-Pattern: Over-Application

```java
// ❌ DON'T DO THIS: Everything is a Factory
public class UserFactoryFactory {
    private RepositoryFactory repositoryFactory;
    
    public IUserFactory create() {
        return new UserFactory(repositoryFactory.create());
    }
}

// ✅ INSTEAD: Use patterns where they solve real problems
```

---

## ADR-004: Encapsulation as Invariant Protection

**Status:** ACCEPTED  
**Date:** 2026-04-25

### Context

Objects have **invariants**—conditions that must always be true. Example: `BankAccount.balance ≥ 0`. Without encapsulation, external code can violate these invariants directly.

### Decision

We will enforce **Encapsulation** rigorously: 
- All mutable state is private
- Access through validated methods
- Invariants checked at every mutation point

### Rationale

Encapsulation:
- **Prevents bugs** by validating state changes
- **Enables refactoring** (change internals without affecting consumers)
- **Centralizes validation** (business rules in one place)
- **Thread-safety** (easier to synchronize private state)

### Consequences

**Positive:**
- ✅ Invariants always maintained
- ✅ Bugs caught early (validation layer)
- ✅ Can refactor internals without changing contracts
- ✅ Self-documenting intent

**Negative:**
- ❌ Performance overhead from validation (usually negligible)
- ❌ Boilerplate getters/setters (frameworks mitigate)
- ❌ Requires discipline to maintain

### Implementation Examples

**Example 1: Bank Account Invariants**
```java
// ❌ BEFORE: No encapsulation, invariants violated
public class BankAccount {
    public int balance = 0;  // PUBLIC: Anyone can set!
}

var account = new BankAccount();
account.balance = -1000;  // BUG: Invalid state!

// ✅ AFTER: Encapsulated, invariants protected
public class BankAccount {
    private int balance;
    private List<Transaction> transactions;
    
    public BankAccount(int initialBalance) {
        if (initialBalance < 0) {
            throw new IllegalArgumentException("Initial balance must be ≥ 0");
        }
        this.balance = initialBalance;
        this.transactions = new ArrayList<>();
    }
    
    // Invariant: balance ≥ 0, enforced by every mutation
    public void deposit(int amount) {
        if (amount <= 0) throw new IllegalArgumentException("Amount must be > 0");
        balance += amount;
        transactions.add(new Transaction("deposit", amount));
    }
    
    public void withdraw(int amount) {
        if (amount <= 0) throw new IllegalArgumentException("Amount must be > 0");
        if (balance - amount < 0) throw new InsufficientFundsException();
        balance -= amount;
        transactions.add(new Transaction("withdraw", amount));
    }
    
    public int getBalance() {
        return balance;
    }
}

// Usage: invariants always maintained
var account = new BankAccount(1000);
account.withdraw(500);  // ✅ OK: balance = 500
account.withdraw(600);  // ❌ EXCEPTION: Would violate invariant
```

**Example 2: Email Validation Invariant**
```java
// ❌ BEFORE: No encapsulation
public class User {
    public String email = "";
}

user.email = "not-an-email";  // BUG: Invalid email!

// ✅ AFTER: Encapsulated with validation
public class User {
    private String email;
    
    public User(String email) {
        setEmail(email);  // Validate in constructor
    }
    
    public void setEmail(String email) {
        if (!isValidEmail(email)) {
            throw new IllegalArgumentException("Invalid email format");
        }
        this.email = email;
    }
    
    public String getEmail() {
        return email;
    }
    
    private boolean isValidEmail(String email) {
        return email.matches("^[A-Za-z0-9+_.-]+@(.+)$");
    }
}

// Usage: email format always valid
var user = new User("alice@example.com");  // ✅ OK
var user = new User("invalid-email");      // ❌ EXCEPTION
```

### Encapsulation Levels

| Level | Scope | Example |
|-------|-------|---------|
| **private** | Class only | Internal implementation |
| **protected** | Class + Subclasses | For inheritance extension |
| **package** | Same package | Internal collaboration |
| **public** | Everywhere | Published API |

### Encapsulation Checklist

- [ ] Are mutable fields private?
- [ ] Are invariants checked before every mutation?
- [ ] Can we refactor internals without changing the public API?
- [ ] Are validation error messages clear?

---

## ADR-005: Polymorphism for Extensibility

**Status:** ACCEPTED  
**Date:** 2026-04-25

### Context

Systems must support new behavior without modification. Polymorphism enables this: defining common interfaces that multiple implementations can fulfill.

### Decision

We will use **Polymorphism** to:
1. Define contracts via interfaces
2. Enable runtime behavior selection
3. Build plugin architectures
4. Support multiple implementations

### Rationale

Polymorphism:
- **Open/Closed Principle**: Open for extension (new implementations), closed for modification
- **Testability**: Mock implementations for unit tests
- **Flexibility**: Swap implementations at runtime
- **Extensibility**: Third parties can add implementations

### Consequences

**Positive:**
- ✅ Can add new behavior without modifying existing code
- ✅ Can test with mock implementations
- ✅ Plugin architecture becomes natural
- ✅ Each implementation focuses on one concern

**Negative:**
- ❌ Indirection makes debugging harder (tools help)
- ❌ More types to maintain
- ❌ Performance overhead from virtual dispatch (negligible)

### Implementation Examples

**Example 1: Notification System**
```java
// ✅ Polymorphic notification interface
public interface INotificationChannel {
    void send(User recipient, String message);
}

// Multiple implementations
public class EmailNotificationChannel implements INotificationChannel {
    public void send(User recipient, String message) {
        // Send via SMTP
    }
}

public class SMSNotificationChannel implements INotificationChannel {
    public void send(User recipient, String message) {
        // Send via Twilio
    }
}

public class SlackNotificationChannel implements INotificationChannel {
    public void send(User recipient, String message) {
        // Send via Slack API
    }
}

// Orchestrator: Works with any implementation
public class NotificationService {
    private List<INotificationChannel> channels;
    
    public void notifyUser(User user, String message) {
        channels.forEach(channel -> {
            try {
                channel.send(user, message);
            } catch (Exception e) {
                logger.error("Notification failed: " + channel.getClass().getName());
            }
        });
    }
}

// Easy to extend: add new notification channel without modifying NotificationService
public class PushNotificationChannel implements INotificationChannel {
    public void send(User recipient, String message) {
        // Send via FCM
    }
}
```

**Example 2: Data Export Format**
```java
// ✅ Polymorphic export interface
public interface IReportExporter {
    String export(Report report);
}

public class CSVExporter implements IReportExporter {
    public String export(Report report) {
        return report.rows.stream()
            .map(row -> String.join(",", row))
            .collect(Collectors.joining("\n"));
    }
}

public class JSONExporter implements IReportExporter {
    public String export(Report report) {
        return new Gson().toJson(report);
    }
}

public class ExcelExporter implements IReportExporter {
    public String export(Report report) {
        // Excel format
        return null;  // implementation
    }
}

// Orchestrator
public class ReportGenerator {
    private IReportExporter exporter;
    
    public String generateReport(ReportRequest request) {
        Report report = buildReport(request);
        return exporter.export(report);
    }
}
```

---

## ADR-006: Separation of Concerns for Maintainability

**Status:** ACCEPTED  
**Date:** 2026-04-25

### Context

Complex systems must be partitioned into independent, manageable pieces. When concerns mix (business logic + persistence + validation + logging), understanding and changing code becomes exponentially harder.

### Decision

We will **separate concerns** into distinct layers/modules:
- **Presentation Layer**: HTTP requests, validation, formatting
- **Application Layer**: Orchestration, use cases, security
- **Domain Layer**: Business logic, rules, entities
- **Infrastructure Layer**: Persistence, external APIs, configuration

Each layer depends on layers below, never upward (dependency inversion).

### Rationale

Separation of concerns:
- **Testability**: Test business logic without HTTP/database
- **Maintainability**: Change one concern without affecting others
- **Parallelization**: Teams work on different layers independently
- **Reusability**: Domain logic can be used by multiple presentation layers (web, CLI, API)

### Consequences

**Positive:**
- ✅ Business logic testable in isolation
- ✅ Easy to add new presentation layers (web, mobile, CLI)
- ✅ Infrastructure changes don't affect business logic
- ✅ Teams can work independently

**Negative:**
- ❌ More layers to navigate
- ❌ Boilerplate DTOs between layers
- ❌ More complex data flow

### Layered Architecture Example

```java
// ============ PRESENTATION LAYER ============
@RestController
@RequestMapping("/accounts")
public class AccountController {
    private AccountService service;
    
    @PostMapping
    public AccountDTO create(@RequestBody CreateAccountRequest request) {
        Account account = service.createAccount(
            request.getCustomerName(),
            request.getInitialBalance()
        );
        return mapToDTO(account);
    }
}

// ============ APPLICATION LAYER ============
@Service
public class AccountService {
    private IAccountRepository repository;
    private IEventPublisher events;
    
    public Account createAccount(String customerName, int balance) {
        // Orchestration: coordinate business logic + persistence
        var account = new Account(customerName, balance);
        repository.save(account);
        events.publish(new AccountCreatedEvent(account.id));
        return account;
    }
}

// ============ DOMAIN LAYER ============
public class Account {
    private String id;
    private String customerName;
    private int balance;
    
    public Account(String customerName, int balance) {
        if (balance < 0) throw new IllegalArgumentException();
        this.id = UUID.randomUUID().toString();
        this.customerName = customerName;
        this.balance = balance;
    }
    
    public void deposit(int amount) {
        if (amount <= 0) throw new IllegalArgumentException();
        balance += amount;
    }
    
    public void withdraw(int amount) {
        if (amount <= 0) throw new IllegalArgumentException();
        if (balance - amount < 0) throw new InsufficientFundsException();
        balance -= amount;
    }
}

// ============ INFRASTRUCTURE LAYER ============
@Repository
public class SqlAccountRepository implements IAccountRepository {
    private JdbcTemplate jdbc;
    
    @Override
    public void save(Account account) {
        jdbc.update(
            "INSERT INTO accounts (id, customer_name, balance) VALUES (?, ?, ?)",
            account.id, account.customerName, account.balance
        );
    }
    
    @Override
    public Account findById(String id) {
        // Map from SQL to domain object
        return jdbc.queryForObject(
            "SELECT * FROM accounts WHERE id = ?",
            (rs, rowNum) -> new Account(/* mapped */),
            id
        );
    }
}
```

### Cross-Cutting Concerns (Logging, Security, Validation)

Use **Decorator Pattern** or **Aspect-Oriented Programming** to avoid mixing concerns:

```java
// ✅ Decorator pattern: wrap service with logging/security
public class LoggedAccountService implements AccountService {
    private AccountService delegate;
    private Logger logger;
    
    public Account createAccount(String name, int balance) {
        logger.info("Creating account: " + name);
        try {
            var account = delegate.createAccount(name, balance);
            logger.info("Account created: " + account.id);
            return account;
        } catch (Exception e) {
            logger.error("Account creation failed", e);
            throw e;
        }
    }
}

// Usage: Compose concerns via decoration
var service = new LoggedAccountService(
    new SecuredAccountService(
        new RealAccountService()
    )
);
```

---

## ADR-007: Interface Contracts for Loose Coupling

**Status:** ACCEPTED  
**Date:** 2026-04-25

### Context

Consumers depending on concrete implementations create tight coupling. When implementations change, consumers must change. Interfaces provide **contracts** that don't change even if implementations do.

### Decision

We will define **Interfaces** for:
- External systems (APIs, databases)
- Alternate implementations (mock, real)
- Plugin points (extensibility)
- Cross-module boundaries

### Rationale

Interface contracts:
- **Decouple** consumers from implementations
- **Enable testing** with mocks/stubs
- **Document** expected behavior
- **Allow refactoring** without affecting consumers

### Consequences

**Positive:**
- ✅ Consumers depend on stable contracts
- ✅ Multiple implementations possible
- ✅ Easy to test with mocks
- ✅ Change implementations without affecting consumers

**Negative:**
- ❌ More types to understand
- ❌ Indirection in code flow
- ❌ Interface bloat if over-applied

### Interface Design Guidelines

```java
// ✅ GOOD: Clear, focused contract
public interface IUserRepository {
    User findById(String id);
    void save(User user);
    List<User> findByEmail(String email);
}

// ❌ BAD: Too many methods, unclear purpose
public interface IUserService {
    User findById(String id);
    void save(User user);
    void sendEmail(User user);  // Why is email in repository?
    void calculateBonus(User user);  // And bonus calculation?
    void logActivity(User user);  // And logging?
}

// ✅ GOOD: Segregated interfaces
public interface IUserRepository {
    User findById(String id);
    void save(User user);
}

public interface IEmailService {
    void sendWelcomeEmail(User user);
}

public interface IBonusCalculator {
    int calculateBonus(User user);
}
```

### Common Interface Patterns

| Pattern | Purpose | Example |
|---------|---------|---------|
| **Repository** | Persist/retrieve domain objects | IUserRepository, IOrderRepository |
| **Service** | Orchestrate use cases | IUserService, IPaymentService |
| **Gateway** | External system integration | IPaymentGateway, IEmailGateway |
| **Converter** | Transform between types | IUserToDTOConverter |
| **Validator** | Check business rules | IOrderValidator |
| **Factory** | Create objects | IUserFactory |

---

## ADR-008: SOLID Principles as Quality Foundation

**Status:** ACCEPTED  
**Date:** 2026-04-25

### Context

Not all code is created equal. SOLID principles identify characteristics of high-quality, maintainable code. They guide design decisions and code review standards.

### Decision

We will apply **SOLID principles** to guide architecture:

1. **S**ingle Responsibility: One reason to change
2. **O**pen/Closed: Open for extension, closed for modification
3. **L**iskov Substitution: Subclasses fully substitute parents
4. **I**nterface Segregation: Many specific interfaces vs. one general
5. **D**ependency Inversion: Depend on abstractions, not concretions

### Rationale

SOLID principles:
- Reduce coupling between modules
- Improve testability and maintainability
- Enable extensibility without modification
- Guide team standards

### Consequences

**Positive:**
- ✅ More maintainable code over time
- ✅ Easier to test and refactor
- ✅ New team members understand patterns
- ✅ Reduces design discussions

**Negative:**
- ❌ Initial design takes longer
- ❌ Boilerplate can feel excessive
- ❌ Requires team discipline

### SOLID in Practice

```java
// ❌ VIOLATES ALL OF SOLID
public class OrderService {  // Too many reasons to change
    public void createOrder(Order order) {
        // Business logic: validate order
        if (order.total <= 0) throw new Exception();
        
        // Persistence: save to database
        var conn = DriverManager.getConnection("jdbc:mysql://...");
        var stmt = conn.createStatement();
        stmt.execute("INSERT INTO orders ...");
        
        // Email: send confirmation
        var smtpClient = new SmtpClient("smtp.gmail.com");
        smtpClient.send(order.customerEmail, "Order confirmed");
        
        // Logging: write to file
        FileWriter fw = new FileWriter("orders.log");
        fw.write("Order created: " + order.id);
        fw.close();
    }
}

// ✅ RESPECTS SOLID PRINCIPLES
// Single Responsibility: OrderService only orchestrates
public class OrderService {
    private IOrderValidator validator;
    private IOrderRepository repository;
    private IOrderNotifier notifier;
    private IOrderLogger logger;
    
    public void createOrder(Order order) {
        validator.validate(order);  // Validation concern
        repository.save(order);     // Persistence concern
        notifier.sendConfirmation(order);  // Notification concern
        logger.logOrderCreated(order);     // Logging concern
    }
}

// Open/Closed: Can add new validators without changing OrderService
public interface IOrderValidator {
    void validate(Order order);
}

public class OrderAmountValidator implements IOrderValidator {
    public void validate(Order order) {
        if (order.total <= 0) throw new Exception("Invalid amount");
    }
}

public class CustomerCreditValidator implements IOrderValidator {
    public void validate(Order order) {
        if (!customer.hasCredit(order.total)) throw new Exception("Insufficient credit");
    }
}

// Liskov Substitution: All validators can replace IOrderValidator
List<IOrderValidator> validators = List.of(
    new OrderAmountValidator(),
    new CustomerCreditValidator(),
    new InventoryValidator()
);
validators.forEach(v -> v.validate(order));  // All work identically

// Interface Segregation: Specific interfaces, not one mega-interface
public interface IOrderNotifier {
    void sendConfirmation(Order order);
}

public interface IOrderLogger {
    void logOrderCreated(Order order);
}

// Dependency Inversion: Depend on interfaces, not concrete classes
public class OrderService {
    private IOrderRepository repo;  // Depends on abstraction
    private IOrderNotifier notifier;  // Depends on abstraction
    
    // Constructor injection: externally managed
    public OrderService(IOrderRepository repo, IOrderNotifier notifier) {
        this.repo = repo;
        this.notifier = notifier;
    }
}
```

---

## ADR-009: Class Hierarchies Must Be Shallow and Meaningful

**Status:** ACCEPTED  
**Date:** 2026-04-25

### Context

Deep inheritance hierarchies (3+ levels) are fragile and difficult to understand. Each level adds complexity; changes to parents break children.

### Decision

We will enforce:
1. **Shallow hierarchies**: Maximum 2 levels deep
2. **Meaningful relationships**: Reflect domain concepts (not implementation tricks)
3. **Clear contracts**: Each level has distinct responsibility

### Rationale

Shallow hierarchies:
- **Easier to understand**: Less to learn about parent behavior
- **Safer to refactor**: Changes affect fewer classes
- **Clear responsibilities**: Each level has clear role
- **Natural modeling**: Reflects real-world relationships

### Consequences

**Positive:**
- ✅ Easier to understand inheritance
- ✅ Safer to refactor
- ✅ Better reflection of domain

**Negative:**
- ❌ May require composition instead
- ❌ More types to maintain
- ❌ Requires design discipline

### Hierarchy Examples

```java
// ❌ TOO DEEP: 4 levels
abstract class LivingThing { }
abstract class Animal extends LivingThing { }
abstract class Mammal extends Animal { }
class Dog extends Mammal { }

// ✅ CORRECT: 2 levels with clear meaning
interface IAnimal {
    void eat();
    void sleep();
}

class Dog implements IAnimal {
    private Breed breed;  // Composition: Dog HAS-A breed
    private Diet diet;    // Composition: Dog HAS-A diet
    
    public void eat() { diet.feed(); }
    public void sleep() { /* */ }
}

class Cat implements IAnimal {
    private Breed breed;
    private Diet diet;
    
    public void eat() { diet.feed(); }
    public void sleep() { /* */ }
}
```

### Hierarchy Design Checklist

- [ ] Is this truly an **is-a** relationship?
- [ ] Is the hierarchy ≤2 levels deep?
- [ ] Do all children satisfy Liskov Substitution Principle?
- [ ] Would composition solve this more flexibly?

---

## ADR-010: Object Model Design Reflects Domain

**Status:** ACCEPTED  
**Date:** 2026-04-25

### Context

Objects should model real-world concepts from the domain, not implementation details. A well-designed object model is self-documenting and reflects business understanding.

### Decision

We will design **Object Models** that:
1. Reflect domain concepts (Ubiquitous Language)
2. Capture relationships explicitly (has-a, is-a, depends-on)
3. Enforce invariants (business rules)
4. Use Value Objects for identity-less concepts

### Rationale

Good object models:
- **Self-documenting**: Code reads like requirements
- **Maintainable**: Changes to business map to code changes clearly
- **Testable**: Domain logic isolated from infrastructure
- **Communicative**: Non-technical stakeholders understand structure

### Consequences

**Positive:**
- ✅ Code reflects business requirements
- ✅ Easier to catch bugs (logic visible)
- ✅ Better communication with business
- ✅ Stable as business grows

**Negative:**
- ❌ Design phase takes longer
- ❌ More classes to maintain
- ❌ Requires domain knowledge

### Banking Domain Model Example

```java
// ✅ VALUE OBJECTS: Identity-less concepts
public class Money {
    private final BigDecimal amount;
    private final Currency currency;
    
    public Money(BigDecimal amount, Currency currency) {
        if (amount.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Money cannot be negative");
        }
        this.amount = amount;
        this.currency = currency;
    }
    
    public Money add(Money other) {
        if (!this.currency.equals(other.currency)) {
            throw new IllegalArgumentException("Cannot add different currencies");
        }
        return new Money(this.amount.add(other.amount), currency);
    }
}

// ✅ ENTITIES: Have identity, mutable state
public class Account {
    private String id;
    private Customer owner;
    private Money balance;
    private List<Transaction> transactions;
    
    public Account(String id, Customer owner, Money initialBalance) {
        this.id = id;
        this.owner = owner;
        this.balance = initialBalance;
        this.transactions = new ArrayList<>();
    }
    
    public void deposit(Money amount) {
        if (amount.getAmount().compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Deposit amount must be positive");
        }
        this.balance = balance.add(amount);
        this.transactions.add(new Transaction("deposit", amount));
    }
    
    public void withdraw(Money amount) {
        if (this.balance.getAmount().compareTo(amount.getAmount()) < 0) {
            throw new InsufficientFundsException();
        }
        this.balance = balance.subtract(amount);
        this.transactions.add(new Transaction("withdraw", amount));
    }
}

// ✅ RELATIONSHIPS: Explicit, constrained
public class Customer {
    private String id;
    private String name;
    private List<Account> accounts;  // HAS-MANY
}

// ✅ AGGREGATES: Boundaries for consistency
public class Order {
    private String id;
    private Customer customer;
    private List<OrderItem> items;  // Aggregate: items can't exist without order
    private Money totalAmount;
    
    public void addItem(Product product, int quantity) {
        if (quantity <= 0) throw new IllegalArgumentException();
        items.add(new OrderItem(product, quantity));
        updateTotal();
    }
    
    private void updateTotal() {
        totalAmount = items.stream()
            .map(item -> item.getPrice().multiply(item.getQuantity()))
            .reduce(Money.ZERO, Money::add);
    }
}
```

---

## ADR-011: Refactoring as Continuous Architecture Improvement

**Status:** ACCEPTED  
**Date:** 2026-04-25

### Context

Code doesn't degrade from poor design to failure instantly. It decays gradually: small violations accumulate, becoming technical debt. Continuous refactoring prevents this decay.

### Decision

We will establish a **Refactoring Culture** where:
1. Every PR includes refactoring opportunities
2. Technical debt is tracked and prioritized
3. Safe refactoring techniques are standard
4. Tests enable refactoring confidence

### Rationale

Continuous refactoring:
- **Prevents technical debt accumulation**: Small, frequent fixes
- **Enables architecture evolution**: System can improve without rewrite
- **Maintains team velocity**: Debt doesn't slow future changes
- **Shares knowledge**: Reviews discuss why changes matter

### Consequences

**Positive:**
- ✅ System improves incrementally
- ✅ Team maintains high velocity
- ✅ New developers learn system through refactoring
- ✅ Prevents large technical debt

**Negative:**
- ❌ Requires discipline and time budgeting
- ❌ Can introduce bugs if not careful
- ❌ Needs good test coverage

### Safe Refactoring Techniques

```java
// TECHNIQUE 1: Extract Class (God Class to Multiple Classes)
// ❌ BEFORE: UserService does too much
public class UserService {
    public void createUser(String name, String email) { /* */ }
    public void sendWelcomeEmail(User user) { /* */ }
    public void persistToDatabase(User user) { /* */ }
    public void validateEmail(String email) { /* */ }
}

// ✅ AFTER: Responsibilities extracted
public class UserFactory {
    public User createUser(String name, String email) {
        new UserValidator().validateEmail(email);
        return new User(name, email);
    }
}

public class UserRepository {
    public void save(User user) { /* persist */ }
}

public class UserNotificationService {
    public void sendWelcomeEmail(User user) { /* email */ }
}

// TECHNIQUE 2: Replace Inheritance with Composition
// ❌ BEFORE: Deep hierarchy
public class Report extends BaseReport extends BaseDocument { }

// ✅ AFTER: Composition
public class Report {
    private ReportFormatter formatter;
    private ReportRepository repository;
}

// TECHNIQUE 3: Extract Interface for Dependency Inversion
// ❌ BEFORE: Direct dependency
public class PaymentProcessor {
    private PayPalGateway gateway = new PayPalGateway();
}

// ✅ AFTER: Interface dependency
public interface IPaymentGateway { }
public class PaymentProcessor {
    private IPaymentGateway gateway;
    public PaymentProcessor(IPaymentGateway gateway) {
        this.gateway = gateway;
    }
}

// TECHNIQUE 4: Extract Method for Clarity
// ❌ BEFORE: Complex method
public void processOrder(Order order) {
    // 50 lines of complex logic
}

// ✅ AFTER: Clear intent
public void processOrder(Order order) {
    validateOrder(order);
    capturePayment(order);
    reserveInventory(order);
    sendConfirmation(order);
}

private void validateOrder(Order order) { /* */ }
private void capturePayment(Order order) { /* */ }
private void reserveInventory(Order order) { /* */ }
private void sendConfirmation(Order order) { /* */ }
```

### Refactoring Checklist

- [ ] Does change improve clarity?
- [ ] Are tests still passing?
- [ ] Have I broken the change into small commits?
- [ ] Did I document why this refactoring matters?

---

## ADR-012: Dependency Inversion for Architectural Flexibility

**Status:** ACCEPTED  
**Date:** 2026-04-25

### Context

When high-level business logic depends on low-level technical details (database, APIs), changes to those details ripple through the system. Dependency Inversion flips this relationship.

### Decision

We will apply **Dependency Inversion**:
- High-level modules define abstractions (interfaces)
- Low-level modules implement those abstractions
- Both depend on abstractions, not concretions

### Rationale

Dependency Inversion:
- **Stable system**: Changes to implementations don't affect business logic
- **Flexible infrastructure**: Swap database, API, cache without code changes
- **Testable**: Mock low-level dependencies easily
- **Modular**: Each layer evolves independently

### Consequences

**Positive:**
- ✅ Business logic independent of infrastructure
- ✅ Easy to test with mocks
- ✅ Can swap implementations (database, payment provider, etc.)
- ✅ Reduces cascading changes

**Negative:**
- ❌ More abstractions to maintain
- ❌ Initial design overhead
- ❌ Indirection makes debugging harder

### Dependency Inversion Example: Payment Processing

```java
// ❌ WITHOUT INVERSION: Business logic depends on concrete infrastructure
public class OrderProcessor {
    private PayPalGateway paypal = new PayPalGateway("api_key");  // ← DIRECT DEPENDENCY
    private MySQLOrderRepository db = new MySQLOrderRepository("connection_string");  // ← DIRECT
    
    public void processOrder(Order order) {
        // Business logic mixed with infrastructure
        paypal.charge(order.total);
        db.save(order);
    }
}

// If we want to support Stripe instead of PayPal, we must change OrderProcessor
// If we want to use MongoDB instead of MySQL, we must change OrderProcessor
// PROBLEM: High-level business logic depends on low-level infrastructure

// ✅ WITH INVERSION: Business logic depends on abstractions
public interface IPaymentGateway {
    PaymentResult charge(Money amount);
}

public interface IOrderRepository {
    void save(Order order);
}

// High-level business logic: defines what it needs
public class OrderProcessor {
    private IPaymentGateway gateway;     // ← DEPENDS ON ABSTRACTION
    private IOrderRepository repository;  // ← DEPENDS ON ABSTRACTION
    
    // Dependencies injected: OrderProcessor doesn't create them
    public OrderProcessor(IPaymentGateway gateway, IOrderRepository repository) {
        this.gateway = gateway;
        this.repository = repository;
    }
    
    public void processOrder(Order order) {
        gateway.charge(order.total);
        repository.save(order);
    }
}

// Low-level implementations: depend on abstraction too
public class PayPalGateway implements IPaymentGateway {
    public PaymentResult charge(Money amount) {
        // PayPal specific logic
    }
}

public class StripeGateway implements IPaymentGateway {
    public PaymentResult charge(Money amount) {
        // Stripe specific logic
    }
}

public class MySQLOrderRepository implements IOrderRepository {
    public void save(Order order) {
        // MySQL specific logic
    }
}

public class MongoOrderRepository implements IOrderRepository {
    public void save(Order order) {
        // MongoDB specific logic
    }
}

// Usage: OrderProcessor works with ANY implementation
var processor = new OrderProcessor(
    new PayPalGateway(),      // Can swap for StripeGateway
    new MySQLOrderRepository()  // Can swap for MongoOrderRepository
);

// TESTING: Use mock implementations
var processor = new OrderProcessor(
    new MockPaymentGateway(),   // No real API calls
    new InMemoryOrderRepository() // No database access
);
```

### Dependency Flow Diagram

```
WITHOUT INVERSION (Wrong):
OrderProcessor (high-level)
    ↓
PayPalGateway (low-level) ← Changes affect OrderProcessor!

WITH INVERSION (Correct):
OrderProcessor (high-level)
    ↓ depends on
IPaymentGateway (abstraction)
    ↑ implemented by
PayPalGateway (low-level) ← Changes don't affect OrderProcessor!
```

### Dependency Injection Patterns

| Pattern | Implementation | Use Case |
|---------|-----------------|----------|
| **Constructor Injection** | Pass dependencies via constructor | Most common, explicit |
| **Setter Injection** | Pass dependencies via setters | Optional dependencies |
| **Interface Injection** | Dedicated setter interface | Framework-driven |
| **Service Locator** | Central registry (use sparingly) | Last resort only |

---

## Summary: 12 ADRs for Architectural Decisions

All 12 ADRs follow the same structure:
1. **Status**: ACCEPTED (approved) or PROPOSED
2. **Context**: Why this matters
3. **Decision**: What we decided
4. **Rationale**: Why this decision
5. **Consequences**: Positive/negative trade-offs
6. **Examples**: Real code samples
7. **Checklist**: Review criteria

These ADRs form the foundation for all architectural decisions in systems based on Object-Oriented Thinking principles.
