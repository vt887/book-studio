# System Design Framework

**Source:** Object-Oriented Thinking by Vaysfeld  
**Purpose:** Step-by-step approach to OOP-based system architecture  
**Target Audience:** Architects, Tech Leads, Senior Developers

---

## Table of Contents

1. **Discovery Phase**
2. **Domain Modeling Phase**
3. **Architecture Design Phase**
4. **Detailed Design Phase**
5. **Implementation Strategy**
6. **Quality Assurance Phase**
7. **Evolution Strategy**

---

## Phase 1: Discovery & Requirements

### Step 1.1: Define System Boundaries

**Questions to Answer:**
- What is in scope? What is out of scope?
- Who are the users/consumers?
- What are the primary use cases?
- What are the non-functional requirements? (performance, availability, scale)

**Artifacts:**
```
System Context Diagram:
┌─────────────────────────────┐
│   External System A         │
└──────────┬──────────────────┘
           │
           ├─ API calls
           │
┌──────────▼──────────────────┐
│   OUR SYSTEM                │
│  ┌──────────────────────┐   │
│  │  Core Domain         │   │
│  │  (Business Logic)    │   │
│  └──────────────────────┘   │
└──────────┬──────────────────┘
           │
           ├─ API calls
           │
┌──────────▼──────────────────┐
│   External System B         │
└─────────────────────────────┘
```

### Step 1.2: Gather Use Cases

**Template:**
```
Use Case: Transfer Money
Actors: Customer, Bank
Preconditions: Customer has active account with sufficient funds
Main Flow:
  1. Customer selects transfer destination
  2. Customer enters amount
  3. System validates account has sufficient funds
  4. System creates transaction record
  5. System deducts from source, adds to destination
  6. System sends confirmation
Postconditions: Money transferred, audit log created
```

### Step 1.3: Identify Non-Functional Requirements

| Requirement | Target | Implication |
|-------------|--------|-------------|
| **Performance** | 95% of requests < 100ms | Need caching, optimization |
| **Availability** | 99.9% uptime | Need redundancy, failover |
| **Scalability** | Support 10,000 concurrent users | Need load balancing |
| **Security** | PCI-DSS compliance | Encryption, audit trails |
| **Maintainability** | Deploy weekly | Need CI/CD, automated tests |

---

## Phase 2: Domain Modeling

### Step 2.1: Identify Core Entities

**Method:**
1. Read requirements carefully
2. Extract nouns (potential entities)
3. Group related concepts
4. Identify identity and lifecycle

**Example: Banking System**
```
Nouns: Customer, Account, Transaction, Money, Bank, Loan, Card, etc.

Entities:
├─ Customer (identity: customer_id)
├─ Account (identity: account_id, has-many Transaction)
├─ Transaction (identity: transaction_id, belongs-to Account)
└─ Card (identity: card_id, belongs-to Customer)

Value Objects:
├─ Money (no identity, immutable)
├─ Address (no identity, embedded)
└─ PhoneNumber (no identity, embedded)
```

### Step 2.2: Model Relationships

**Relationship Types:**

| Type | Notation | Example | Implementation |
|------|----------|---------|-----------------|
| **One-to-Many** | 1 → * | Customer has-many Accounts | List<Account> |
| **Many-to-Many** | * ← → * | Students take-many Courses | List<Course> |
| **One-to-One** | 1 → 1 | Person has-one Passport | Passport passport |
| **Aggregation** | ◇ | Department aggregates Employees | Department contains Employees |
| **Composition** | ◆ | Car owns Engine | Engine lifecycle tied to Car |

### Step 2.3: Define Invariants

**For each entity, list invariants (must always be true):**

```java
public class BankAccount {
    // Invariants:
    // 1. balance >= 0
    // 2. account_number is unique
    // 3. customer_id is not null
    // 4. account_type in (CHECKING, SAVINGS, CREDIT)
    // 5. created_date <= current_date
}

public class Transaction {
    // Invariants:
    // 1. amount > 0
    // 2. source_account != destination_account
    // 3. timestamp is in the past
    // 4. status in (PENDING, COMPLETED, FAILED)
}
```

### Step 2.4: Create Domain Model Diagram

```
BANKING DOMAIN MODEL

┌─────────────────┐
│   Customer      │
├─────────────────┤
│ -id: String     │
│ -name: String   │
│ -email: Email   │
└────────┬────────┘
         │ has-many
         │
    ┌────▼─────────────┐
    │   Account        │
    ├──────────────────┤
    │ -id: String      │
    │ -balance: Money  │
    │ -type: String    │
    └────┬──────────────┘
         │ has-many
         │
    ┌────▼──────────────┐
    │  Transaction      │
    ├───────────────────┤
    │ -id: String       │
    │ -amount: Money    │
    │ -timestamp: Date  │
    │ -type: String     │
    └───────────────────┘
```

---

## Phase 3: Architecture Design

### Step 3.1: Define Layers

```
LAYERED ARCHITECTURE

┌─────────────────────────────────────────────────┐
│  PRESENTATION LAYER                             │
│  (HTTP Controllers, REST endpoints, DTOs)       │
├─────────────────────────────────────────────────┤
│  APPLICATION LAYER                              │
│  (Orchestration, Use Cases, Services)           │
├─────────────────────────────────────────────────┤
│  DOMAIN LAYER                                   │
│  (Business Logic, Entities, Value Objects)      │
├─────────────────────────────────────────────────┤
│  INFRASTRUCTURE LAYER                           │
│  (Persistence, External APIs, Configuration)    │
└─────────────────────────────────────────────────┘

DEPENDENCY RULE: Dependencies only go DOWN (or into abstraction)
Presentation depends on Application
Application depends on Domain
Infrastructure depends on Domain (via Repository interface)
```

### Step 3.2: Define Service Boundaries

**Question:** What should each service be responsible for?

**Guide: Separation of Concerns**

```
BANKING SYSTEM SERVICES

1. AccountService (manage accounts)
   - createAccount()
   - closeAccount()
   - updateAccountHolder()

2. TransactionService (process transactions)
   - transfer()
   - deposit()
   - withdraw()

3. NotificationService (notify customers)
   - sendTransactionConfirmation()
   - sendMonthlyStatement()

4. ReportingService (generate reports)
   - generateAccountStatement()
   - generateTransactionHistory()

5. SecurityService (authentication/authorization)
   - authenticateCustomer()
   - authorizeTransaction()
```

### Step 3.3: Define Service Interfaces

```java
// ABSTRACTION LAYER: Define contracts
public interface IAccountRepository {
    Account findById(String accountId);
    void save(Account account);
}

public interface ITransactionRepository {
    List<Transaction> findByAccount(String accountId);
    void save(Transaction transaction);
}

public interface INotificationService {
    void sendConfirmation(Transaction transaction);
}

// IMPLEMENTATION LAYER: Multiple implementations possible
public class MySQLAccountRepository implements IAccountRepository {
    // SQL-specific implementation
}

public class MongoAccountRepository implements IAccountRepository {
    // MongoDB-specific implementation
}
```

### Step 3.4: Identify Cross-Cutting Concerns

These apply across multiple layers:

| Concern | Typical Location | Implementation |
|---------|------------------|-----------------|
| **Authentication** | Entry point | Filters, interceptors |
| **Authorization** | Application layer | Decorators, AOP |
| **Logging** | Throughout | Decorators, AOP |
| **Error Handling** | All layers | Exception hierarchy |
| **Transaction Management** | Application layer | Decorators, AOP |
| **Caching** | Infrastructure | Decorators, proxies |
| **Validation** | Input & domain | Validators |

---

## Phase 4: Detailed Design

### Step 4.1: Create Detailed Sequence Diagrams

```
Transfer Money Use Case:

Client
  │
  ├─POST /accounts/transfer
  │
  ▼
TransferController
  │
  ├─ validate request
  │
  ▼
TransferService
  │
  ├─ get source account
  │ (from IAccountRepository)
  │
  ├─ validate: source.balance >= amount
  │
  ├─ get destination account
  │
  ├─ create Transaction object
  │
  ├─ save transaction
  │ (to ITransactionRepository)
  │
  ├─ notify customer
  │ (via INotificationService)
  │
  ▼
Response: {success: true, transactionId: "123"}
```

### Step 4.2: Design Class Hierarchies

**Remember ADR-002: Composition over Inheritance**

**CORRECT (using composition):**
```java
public class Employee {
    private String name;
    private Role role;           // Composition
    private Salary salary;       // Composition
    private Permissions permissions;  // Composition
}

public enum Role { DEVELOPER, MANAGER, DESIGNER }
public class Salary { private Money amount; }
public class Permissions { private List<String> allowed; }
```

**AVOID (deep inheritance):**
```java
// ❌ DON'T DO THIS
public abstract class Employee { }
public class Manager extends Employee { }
public class Developer extends Employee { }
public class SeniorDeveloper extends Developer { }  // Too deep!
```

### Step 4.3: Design Exception Hierarchy

```java
// Custom exceptions following domain concepts
public abstract class BankingException extends RuntimeException { }

public class InsufficientFundsException extends BankingException { }
public class AccountNotFoundException extends BankingException { }
public class InvalidTransactionException extends BankingException { }
public class AuthorizationFailedException extends BankingException { }

// Usage: Specific, catchable exceptions
try {
    account.withdraw(amount);
} catch (InsufficientFundsException e) {
    handleInsufficientFunds();
} catch (BankingException e) {
    handleGenericBankingError();
}
```

### Step 4.4: Design Configuration

```java
// Configuration objects (immutable, encapsulate defaults)
public class BankingConfiguration {
    private final int dailyWithdrawalLimit;
    private final BigDecimal minimumBalance;
    private final Duration transactionTimeout;
    
    public BankingConfiguration() {
        this.dailyWithdrawalLimit = 5000;
        this.minimumBalance = BigDecimal.ZERO;
        this.transactionTimeout = Duration.ofSeconds(30);
    }
}

// Inject configuration
public class WithdrawalService {
    private BankingConfiguration config;
    
    public void withdraw(Account account, Money amount) {
        if (amount.compareTo(config.getDailyWithdrawalLimit()) > 0) {
            throw new DailyLimitExceededException();
        }
    }
}
```

---

## Phase 5: Implementation Strategy

### Step 5.1: Establish Coding Standards

```java
// Enforce naming conventions
✅ Services: *Service
✅ Repositories: *Repository
✅ Controllers: *Controller
✅ Entities: domain-driven names (no "Entity" suffix)
✅ DTOs: *DTO or *Request/*Response
✅ Interfaces: I* prefix or *Interface

// Example structure
com.banking
├── domain
│   ├── Account.java
│   ├── Transaction.java
│   ├── Money.java
│   └── repository
│       ├── IAccountRepository.java
│       └── ITransactionRepository.java
├── application
│   ├── TransferService.java
│   ├── WithdrawalService.java
│   └── dto
│       ├── TransferRequest.java
│       └── TransactionResponse.java
├── infrastructure
│   ├── repository
│   │   ├── MySQLAccountRepository.java
│   │   └── MySQLTransactionRepository.java
│   └── config
│       └── DatabaseConfig.java
└── presentation
    ├── controller
    │   ├── AccountController.java
    │   └── TransactionController.java
    └── filter
        └── AuthenticationFilter.java
```

### Step 5.2: Implement Domain Layer First

```java
// 1. Start with entities and value objects
public class Account {
    private String id;
    private Money balance;
    
    public Account(String id, Money initialBalance) {
        this.id = id;
        this.balance = initialBalance;
    }
    
    public void deposit(Money amount) {
        if (amount.isNegative()) throw new IllegalArgumentException();
        this.balance = balance.add(amount);
    }
    
    public void withdraw(Money amount) {
        if (this.balance.lessThan(amount)) {
            throw new InsufficientFundsException();
        }
        this.balance = balance.subtract(amount);
    }
}

// 2. Then application services
public class TransferService {
    private IAccountRepository repository;
    
    public void transfer(String fromId, String toId, Money amount) {
        var from = repository.findById(fromId);
        var to = repository.findById(toId);
        
        from.withdraw(amount);
        to.deposit(amount);
        
        repository.save(from);
        repository.save(to);
    }
}

// 3. Write tests in isolation
@Test
void testTransferSuccess() {
    var from = new Account("1", Money.of(1000));
    var to = new Account("2", Money.of(0));
    
    from.withdraw(Money.of(100));
    to.deposit(Money.of(100));
    
    assertEquals(900, from.balance);
    assertEquals(100, to.balance);
}
```

### Step 5.3: Build Infrastructure Layer

```java
// Repository pattern: abstract data access
@Repository
public class MySQLAccountRepository implements IAccountRepository {
    private JdbcTemplate jdbc;
    
    @Override
    public Account findById(String id) {
        var row = jdbc.queryForMap(
            "SELECT * FROM accounts WHERE id = ?", id
        );
        return mapToAccount(row);
    }
    
    @Override
    public void save(Account account) {
        jdbc.update(
            "UPDATE accounts SET balance = ? WHERE id = ?",
            account.getBalance(), account.getId()
        );
    }
    
    private Account mapToAccount(Map<String, Object> row) {
        return new Account(
            (String) row.get("id"),
            Money.of((BigDecimal) row.get("balance"))
        );
    }
}
```

### Step 5.4: Connect Layers via Dependency Injection

```java
@Configuration
public class AppConfig {
    // Infrastructure beans
    @Bean
    public IAccountRepository accountRepository() {
        return new MySQLAccountRepository();
    }
    
    @Bean
    public ITransactionRepository transactionRepository() {
        return new MySQLTransactionRepository();
    }
    
    // Application beans
    @Bean
    public TransferService transferService(IAccountRepository repo) {
        return new TransferService(repo);
    }
    
    // Presentation beans
    @Bean
    public TransferController transferController(TransferService service) {
        return new TransferController(service);
    }
}
```

---

## Phase 6: Quality Assurance Strategy

### Step 6.1: Testing Pyramid

```
        ▲
       /│\
      / │ \      END-TO-END TESTS (10%)
     /  │  \     - Full system flow
    /───┼───\    - Integration tests
   /    │    \   - Database, APIs
  /─────┼─────\  INTEGRATION TESTS (30%)
 /      │      \ - Service collaboration
/───────┼───────\- Mock external systems
        │         UNIT TESTS (60%)
        │         - Single class/method
        │         - Fast, isolated
        │         - Mock dependencies
        ▼
```

### Step 6.2: Unit Test Strategy

```java
// Test domain logic in isolation
@Test
void testAccountCannotWithdrawMoreThanBalance() {
    var account = new Account("1", Money.of(100));
    
    assertThrows(InsufficientFundsException.class, () -> {
        account.withdraw(Money.of(200));
    });
}

// Test services with mocks
@Test
void testTransferCallsRepository() {
    var mockRepo = mock(IAccountRepository.class);
    var from = new Account("1", Money.of(1000));
    var to = new Account("2", Money.of(0));
    
    when(mockRepo.findById("1")).thenReturn(from);
    when(mockRepo.findById("2")).thenReturn(to);
    
    var service = new TransferService(mockRepo);
    service.transfer("1", "2", Money.of(100));
    
    verify(mockRepo, times(2)).save(any(Account.class));
}
```

### Step 6.3: Code Review Checklist

**Architecture Reviews:**
- [ ] Do classes follow Single Responsibility?
- [ ] Are interfaces used instead of concrete dependencies?
- [ ] Are invariants enforced via Encapsulation?
- [ ] Is Composition favored over Inheritance?
- [ ] Are cross-cutting concerns handled properly?
- [ ] Can each component be tested in isolation?

**Implementation Reviews:**
- [ ] Is the code self-documenting?
- [ ] Are error cases handled?
- [ ] Are there any code smells? (long methods, duplicate code)
- [ ] Are naming conventions followed?
- [ ] Is performance acceptable?

---

## Phase 7: Evolution Strategy

### Step 7.1: Track Architectural Decisions

Use ADRs (Architectural Decision Records) for all significant decisions:

```
ADR-XXX: Adding Caching Layer

Status: ACCEPTED
Date: 2026-04-25

Context:
  Requests are slow due to repeated database queries.

Decision:
  Introduce Redis caching layer with 1-hour TTL.
  Implement Cache-Aside pattern via Decorator.

Consequences:
  + Reduces database load by 70%
  + Improves response time to <50ms
  - Adds caching consistency complexity
  - Requires monitoring cache hits
```

### Step 7.2: Manage Technical Debt

```
Technical Debt Backlog:

1. [HIGH] Extract UserService (currently 3000 lines)
   - Estimate: 8 hours
   - Rationale: Violates SRP
   - Impact: Easier to test, maintain

2. [MEDIUM] Replace inheritance with composition in ReportGenerator
   - Estimate: 4 hours
   - Rationale: Current 3-level hierarchy
   - Impact: More flexible, safer to change

3. [LOW] Improve error messages
   - Estimate: 2 hours
   - Rationale: Current messages unhelpful
   - Impact: Better debugging
```

### Step 7.3: Plan Refactoring

```
Safe Refactoring Approach:

1. Create feature branch
2. Write tests for existing behavior
3. Make small, incremental changes
4. Run tests after each change
5. Commit frequently
6. Request code review
7. Merge to main
```

### Step 7.4: Monitor Architecture Health

**Metrics to Track:**

| Metric | Target | Red Flag |
|--------|--------|----------|
| **Test Coverage** | > 80% | < 50% |
| **Cyclomatic Complexity** | < 10 | > 20 |
| **Class Size** | < 300 LOC | > 1000 LOC |
| **Method Size** | < 20 LOC | > 50 LOC |
| **Coupling** | Low | High between layers |
| **Cohesion** | High | Unrelated concerns mixed |
| **Code Review Time** | < 1 hour | > 4 hours (signals complexity) |
| **Bug Escape Rate** | < 5% | > 20% (signals insufficient testing) |

---

## Complete System Design Example: Online Store

### Scenario
Design an e-commerce system supporting product browsing, cart management, and order processing.

### Phase 1: Discovery
```
Scope:
- Product catalog (browse, search, filter)
- Shopping cart (add, remove, checkout)
- Order processing (payment, fulfillment)
- Out of scope: Warehouse management, shipping

Use Cases:
- Browse products
- Add to cart
- Checkout and pay
- Track order status

Non-Functional:
- Handle 10,000 concurrent users
- 99.9% availability
- < 200ms response time
```

### Phase 2: Domain Model
```
Entities:
- Product
- ShoppingCart
- CartItem
- Order
- OrderItem
- Payment
- Customer

Value Objects:
- Money
- ProductId
- OrderId
- Address
```

### Phase 3: Architecture
```
Services:
- ProductService (catalog management)
- CartService (cart operations)
- OrderService (order processing)
- PaymentService (payment handling)
- NotificationService (emails)

Repositories:
- IProductRepository
- ICartRepository
- IOrderRepository
- ICustomerRepository
```

### Phase 4-7: Implement following the framework

---

## Summary: System Design Framework Steps

| Phase | Key Activities | Deliverables |
|-------|-----------------|--------------|
| **1. Discovery** | Define scope, use cases, requirements | Context diagram, requirements doc |
| **2. Domain Modeling** | Identify entities, relationships, invariants | Domain model, entity diagrams |
| **3. Architecture Design** | Design layers, services, boundaries | Architecture diagram, service specs |
| **4. Detailed Design** | Sequence diagrams, class hierarchies, exceptions | Detailed designs, standards |
| **5. Implementation** | Code, dependency injection, standards enforcement | Working code, tests |
| **6. Quality Assurance** | Testing strategy, code reviews, metrics | Test suites, code quality reports |
| **7. Evolution** | ADRs, technical debt tracking, refactoring | Living documentation |

This framework ensures systems are:
✅ Well-understood before coding starts
✅ Properly layered and decoupled
✅ Thoroughly tested
✅ Maintainable and evolvable
✅ Free from unnecessary complexity
